#! /bin/bash
#
# List "TODO" and "XXX" items in the given files, or throughout the source
# code.

set -Cue -o pipefail

# TODO: Make location-independent?
find_source() {
    echo configure.ac
    find . -name '*.[ch]xx' | sed -e 's|^\./||' | sort
    echo tools/*
}


FILES=${*:-$(find_source)}


# Search for "$1:" in files $2.
# (This function adds the colon.  That way, the search statement itself won't
# show up in the search.)
search_for() {
    local key="$1:"
    shift
    find_source | xargs grep "$key"
}


search_for XXX "$FILES" || true
search_for TODO "$FILES" || true
