#! /bin/bash
#
# Update the libpqxx copyright strings in the current directory.
#
# Usage: update-copyright.sh [year]
#
# Where "year" is the new copyright year.  Defaults to the current year.
#
# Assumes GNU grep and GNU sed.
set -Cue -o pipefail

# The regexes are a bit awkward because they must work in both grep and sed.
#
# F'rinstance, PREFIX can't include the dash because our replacement string in
# sed would have a backreference (e.g. "\3") immediately followed by a year
# (e.g. 2022), and there's no clear boundary between the backreference number
# and the year: "\32022".
PREFIX='Copyright (c),* 2000'
YEAR='20[0-9][0-9]'
NEW_YEAR="${1:-$(date '+%Y')}"
SUFFIX=',* \(.* and \)*Jeroen T\. Vermeulen'
grep -rIl "$PREFIX-$YEAR$SUFFIX" |
    xargs -r sed -i -e "s/\\($PREFIX\\)-$YEAR\\($SUFFIX\\)/\\1-$NEW_YEAR\\2/"

# This one is so different that I'd rather keep it a special case.
sed \
    -i \
    -e "s/\\(2000\\)-$YEAR\\(,* Jeroen T\\. Vermeulen\\)/\1-$NEW_YEAR\\2/" \
    doc/source/conf.py
