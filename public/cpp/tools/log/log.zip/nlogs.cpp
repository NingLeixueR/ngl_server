#include "actor_log.h"
#include "nlogs.h"


namespace ngl
{
	i64_actorid nlogs::actorid(ENUM_ACTOR aactortype, ELOG_TYPE alogtype)
	{
		return actor_log::actorid(aactortype, alogtype);
	}

	void nlogs::send(i64_actorid aactor, std::shared_ptr<np_actor_logitem>& pro)
	{
		// # ACTOR_TYPE # ELOG_TYPE
		actor_base::static_send_actor(aactor, nguid::make(), pro);
	}

	/*nlogs g_sysnlogs(ACTOR_NONE, ELOG_LOCAL);
	nlogs g_sysnetnlogs(ACTOR_NONE, ELOG_NETWORK);
	nlogs& log(const std::source_location& asource = std::source_location::current())
	{
		g_sysnlogs.set_source(asource);
		return g_sysnlogs;
	}

	nlogs& lognet(const std::source_location& asource = std::source_location::current())
	{
		g_sysnetnlogs.set_source(asource);
		return g_sysnetnlogs;
	}*/
}