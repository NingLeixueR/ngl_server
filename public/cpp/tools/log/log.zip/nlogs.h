#pragma once

#include "logprintf.h"
#include "sysconfig.h"

#include <sstream>
#include <string>
#include <format>
#include <deque>



namespace ngl
{
	struct nlogsstruct
	{
		std::string m_src;
		std::string m_data;
	};

	class nlogs
	{
		ENUM_ACTOR	m_actortype;
		ELOG_TYPE	m_logtype;
		std::string m_src;
	public:
		nlogs(ENUM_ACTOR aactortype, ELOG_TYPE alogtype) :
			m_actortype(aactortype),
			m_logtype(alogtype)
		{
		}

		void set_source(const std::source_location& asource)
		{
			std::string_view str = asource.file_name();
			auto pos = str.rfind("/");
			if (pos != std::string_view::npos)
			{
				m_src = str.substr(pos + 1);
			}
			else
			{
				m_src = str;
			}
		}
	private:
		static i64_actorid actorid(ENUM_ACTOR aactortype, ELOG_TYPE alogtype);

		static void send(i64_actorid aactor, std::shared_ptr<np_actor_logitem>& pro);

		template <typename ...ARGS>
		void print(ELOG alevel, const std::format_string<ARGS...>& aformat, const ARGS&... aargs)
		{
			if (alevel >= ngl::sysconfig::loglevel())
			{
				std::string ldata = std::vformat(aformat.get(), std::make_format_args(aargs...));
				if (sysconfig::logconsole())
				{
					std::cout << m_src << "\t" << ldata << std::endl;
				}
				if (sysconfig::logiswrite() == false)
					return;

				auto pro = std::make_shared<np_actor_logitem>();
				logitem& llogitem = pro->m_data;
				llogitem.m_loglevel = alevel;
				llogitem.m_serverid = nconfig::m_nodeid;
				llogitem.m_src.swap(m_src);
				llogitem.m_data.swap(ldata);
				
				// # ACTOR_TYPE # ELOG_TYPE
				send(actorid(m_actortype, m_logtype), pro);
			}
		}
	public:
		template <typename ...ARGS>
		void error(const std::format_string<ARGS...> aformat, const ARGS&... aargs, const std::source_location& asource = std::source_location::current())
		{
			print(ELOG_ERROR, aformat, aargs..., asource);
		}

		template <typename ...ARGS>
		void warn(const std::format_string<ARGS...> aformat, const ARGS&... aargs, const std::source_location& asource = std::source_location::current())
		{
			print(ELOG_WARN, aformat, aargs..., asource);
		}

		template <typename ...ARGS>
		void info(const std::format_string<ARGS...> aformat, const ARGS&... aargs, const std::source_location& asource = std::source_location::current())
		{
			print(ELOG_INFO, aformat, aargs..., asource);
		}

		template <typename ...ARGS>
		void debug(const std::format_string<ARGS...> aformat, const ARGS&... aargs, const std::source_location& asource = std::source_location::current())
		{
			print(ELOG_DEBUG, aformat, aargs..., asource);
		}
	};


	nlogs& log(const std::source_location& asource = std::source_location::current());
	nlogs& lognet(const std::source_location& asource = std::source_location::current());
}
