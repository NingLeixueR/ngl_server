#include "actor_role.h"
//#include "countgroup.h"
//#include "bag.h"
#include "mail.h"
#include "actor_register.h"
#include "gateway_game_forward.h"
#include "net.pb.h"

namespace ngl
{
	void actor_role::actor_register()
	{
		// ��ʱ��
		actor<actor_role>::register_timer();
		
		register_actor<EPROTOCOL_TYPE_CUSTOM, actor_role>(
			true,
			//null<actor_gmother<actor_del_role_item>>::get(),
			null<actor_disconnect_close>::get()
			);
		register_actor<EPROTOCOL_TYPE_PROTOCOLBUFF, actor_role>(
			true,
			null<PB::PROBUFF_LOGIC_GET_TIME>::get()
			);


		// Э��ע��
		gateway_game_forward::client2game();
	}

	void actor_role::loaddb_finish(bool adbishave)
	{
		LogLocalError("actor_role###loaddb_finish#[%]", actor_guid(id_guid()));
		sync_data_client();
		//std::shared_ptr<actor_chatroleinfo> pro(new actor_chatroleinfo());
		//pro->m_roleitem.m_lastspeakutc = 0;
		//pro->m_roleitem.m_roleid = id_guid();
		////pro->m_roleitem.m_rolename = m_info.get()->const_mm_name();
		//pro->m_roleitem.m_gatewayid = get_getwayserverid();
		//send_actor(actor_guid::make(ACTOR_CHAT), pro);

		//// ## �ǩ��
		//std::shared_ptr<actor_everydaysign> prosign(new actor_everydaysign());
		//send_actor(actor_guid::make_nonearea(ACTOR_ACTIVITY, enum_activity_everydaysign), prosign);
	}

	bool actor_role::timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata)
	{
		return true;
	}
}