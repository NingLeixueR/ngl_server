#include "actor_role.h"

namespace ngl
{
	bool actor_role::handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_CMD& adata)
	{
		LogInfo("cmd num[%] parm[%]", adata.m_cmdnum, adata.m_parmstr);

		switch (adata.m_cmdnum)
		{
		case CMD_GET_TIME:
		{
			LOGIC_GET_TIME pro;
			handle(0, nullptr, pro);
		}
		break;
		case CMD_SET_ROLENAME:
		{
			if (adata.m_parmstr.size() > 0)
			{
				//DB_ROLE* role = m_info.db();
				//role->mm_name() = adata.m_parmstr[0];
				sync_data_client();
			}
		}
		break;
		case CMD_ADD_ROLELV:
		{
			if (adata.m_parmstr.size() > 0)
			{
				//DB_ROLE* role = m_info.db();
				//role->mm_lv() = boost::lexical_cast<int>(adata.m_parmstr[0]);
				sync_data_client();
			}			
		}
		break;
		case CMD_CHAT_CHAT:
		{
			// c 3 0 channelid			// ��ȡ���������¼
			// c 3 1 channelid "xxxx"	// ���췢��			
			/*if (adata.m_parmstr.size() >= 2)
			{
				LOGIC_CHAT pro;
				pro.m_type = (enum_logic_chat)boost::lexical_cast<int>(adata.m_parmstr[0]);
				pro.m_channelid = boost::lexical_cast<int>(adata.m_parmstr[1]);
				if (pro.m_type == chat_speak)
				{
					if (adata.m_parmstr.size() < 3)
					{
						return true;
					}
					pro.m_content = adata.m_parmstr[2];
				}
				handle(0, nullptr, pro);
			}*/
		}
		break;
		/*case CMD_SWITCH_GAME:
		{
			LOGIC_SWITCH_LINE pro;
			auto& lmap = nconfig::get_idbyline();
			for (auto& [_line, _id] : lmap)
			{
				if (_id != nconfig::m_nodeid)
				{
					pro.m_line = _line;
					handle(0, nullptr, pro);
					break;
				}
			}
		}
		break;*/
		}
		return true;
	}
}