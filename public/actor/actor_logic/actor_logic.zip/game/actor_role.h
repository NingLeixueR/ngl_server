#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
//#include "actor_protocol_gm.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"
#include "net.pb.h"

#include <boost/shared_ptr.hpp>

//#include "bag.h"
//#include "mail.h"
//#include "drop.h"
//#include "countgroup.h"
//#include "attribute.h"
//#include "roleinfo.h"
//#include "coolddown.h"

namespace ngl
{
	class actor_manage_role;
	class actor_role : public actor<actor_role>
	{
	public:
		//roleinfo m_info;
		//bag m_bag;
		//countgroup m_countgroup;
		//coolddown m_coolddown;
		//attribute_module m_attribute;
		uint32_t m_gatewayid;
	public:
		actor_role(i16_area aarea, i32_actordataid aroleid, void* adata) :
			actor<actor_role>(
				actorparm
				{
					.m_parm{.m_type = ACTOR_ROLE,.m_area = aarea, .m_id = aroleid,.m_manage_dbclient = true},
					.m_weight = 0x7fffffff,
				}),
			m_gatewayid(((actor_switch_process_role*)(adata))->m_gatewayid)
		{
		}

		virtual i32_serverid get_getwayserverid()
		{
			return m_gatewayid;
		}

		virtual void init()
		{
			//m_info.set(this);
			//m_bag.set(this);
			//m_mail.set(this);
			//m_countgroup.set(this);
			//m_triggertime.set(this);
			//m_periodtime.set(this);
			//m_coolddown.set(this);
		}
		static void actor_register();

		virtual ~actor_role() {}

		virtual void loaddb_finish(bool adbishave);

		enum { ACTOR_TYPE = ACTOR_ROLE };

		int roleid()
		{
			return 0;
			//return m_info.db()->const_mm_id();
		}

		void sync_data_client()
		{
			//LOGIC_ROLE_SYNC pro;
			//pro.m_role = *m_info.db();
			//pro.m_bag = *m_bag.db();
			//pro.m_countgroup = *m_countgroup.db();
			//pro.m_triggertime = *m_triggertime.db();
			//pro.m_mail = *m_mail.db();
			//pro.m_coolddown = *m_coolddown.db();
			
			//send_client(pro);
		}

		// �����ʼ�
		//void send_mail(const DB_MAIL& amail)
		//{
		//	std::shared_ptr<actor_addmail> promail(new actor_addmail{ .m_mail = amail });
		//	send_actor(actor_guid::make(ACTOR_MAIL), promail);
		//}


		///// CMD Э��
		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_CMD& adata);

		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_GET_TIME& adata)
		//{
		//	//LOGIC_GET_TIME_RESPONSE pro = { .m_utc = localtime::gettime() };
		//	LOGIC_GET_TIME_RESPONSE pro;
		//	pro.m_utc = localtime::gettime();
		//	send_client(pro);
		//	//LogLocalError("######Get Server Time##[%][%]", m_info.id(), m_info.db()->name());
		//	return true;
		//}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, PB::PROBUFF_LOGIC_GET_TIME& adata)
		{
			PB::PROBUFF_LOGIC_GET_TIME_RESPONSE pro;
			pro.set_m_utc(localtime::gettime());
			send_client(pro);
			//LogLocalError("######Get Server Time##[%][%]", m_info.id(), m_info.db()->name());
			return true;
		}

		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_ROLE_CREATE& adata)
		{
			DB_ROLE* lpdata = m_info.db();
			if (lpdata == nullptr)
				return false;

			lpdata->mm_name() = adata.m_rolename;
			sync_data_client();
			return true;
		}*/

		//PROTOCOLNUM_LOGIC_SWITCH_LINE,								// �л���·(�����л�����)
		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_SWITCH_LINE& adata)
		//{
		//	uint32_t lserverid = nconfig::idbyline(adata.m_line);
		//	if (lserverid == (uint32_t)(-1) || lserverid == nconfig::m_nodeid)
		//		return false;
		//	i32_sessionid lsession = pserver->get_sessionid(lserverid);
		//	if (lsession == -1)
		//	{
		//		LogLocalError("LOGIC_SWITCH_LINE Error line[%] severid[%]", adata.m_line, lserverid);
		//		return false;
		//	}
		//	actor_switch_process_role pro;
		//	pro.m_create = false;
		//	pro.m_gatewayid = m_gatewayid;
		//	actor_switchprocess::switch_process(id_guid(), nconfig::m_nodeid, lserverid, pro);
		//	//LogLocalError("######Switch Line##[%][%]", m_info.id(), m_info.db()->name());
		//	//crossprocess<actor_role>(lserverid);
		//	
		//	return true;
		//}

		template <typename T>
		void send2other(const actor_guid& aguid, T& apro)
		{
			using type = actor_module_forward<T>;
			std::shared_ptr<type> pro(new type(get_getwayserverid(), apro));
			send_actor(aguid, pro);
		}

		//PROTOCOLNUM_LOGIC_NOTICE_LIST,	// ��ȡ�����б�
		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_NOTICE_LIST& adata)
		{
			send2other<LOGIC_NOTICE_LIST>(actor_guid::make(ACTOR_NOTICE), adata);
			return true;
		}*/

		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_del_role_item>& adata)
		{
			m_bag.delitem(adata.m_data.m_itemid, adata.m_data.m_itemcount);
			return true;
		}*/

		//actor_get_role_item
		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_get_role_item>& adata)
		{
			std::shared_ptr<actor_gmother<actor_get_role_item_response>> pro(new actor_gmother<actor_get_role_item_response>(adata.m_socket));
			const std::map<int32_t, Item>& lamp = m_bag.db()->const_mm_data();
			for (auto& ipair : lamp)
			{
				pro->m_data.m_data.push_back(ipair.second);
			}
			send_actor(actor_guid::make(ACTOR_GM), pro);
			return true;
		}*/

		//actor_send_item
		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_send_item& adata)
		{
			delay_fun ldelay = m_bag.set_itemsrc(adata.m_src, EItemConsumeNoraml);
			return m_bag.additem(adata.m_item);
		}*/

		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_CHAT& adata)
		//{
		//	if (adata.m_type == chat_speak)
		//	{
		//		std::shared_ptr<actor_chatspeak> pro(new actor_chatspeak
		//			{
		//				.m_channelid = adata.m_channelid,
		//				.m_chatitem = chat
		//					{
		//						.m_roleid = id_guid(),
		//						.m_content = adata.m_content,
		//						.m_utc = (int)localtime::gettime()
		//					}
		//			});
		//		send_actor(actor_guid::make(ACTOR_CHAT), pro);
		//		//if (m_info.db() != nullptr)
		//		//{
		//		////	LogLocalError("[%] LOGIC_CHAT chat_speak", m_info.db()->const_mm_name());
		//		//}
		//		//else
		//		//{
		//		//	LogLocalError("TEST#");
		//		//}
		//	}
		//	else if (adata.m_type == get_chat_list)
		//	{
		//		std::shared_ptr<actor_chatget> pro(new actor_chatget{ .m_channelid = adata.m_channelid, });
		//		send_actor(actor_guid::make(ACTOR_CHAT), pro);
		//	}

		//	return true;
		//}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_disconnect_close& adata)
		{
			erase_actor_byid();
			return true;
		}
		
		// ��ʱ��
		bool timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata);

	private:
	};

	
}

