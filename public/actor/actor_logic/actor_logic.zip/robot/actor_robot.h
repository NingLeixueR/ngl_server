#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
#include "net.pb.h"

#include <boost/shared_ptr.hpp>

namespace ngl
{
	class actor_robot : public actor<actor_robot>
	{
		// ----- Data Begin -----
		//LOGIC_ROLE_SYNC m_data;
		// ----- Data End   -----
	public:
		actor_robot(i16_area aarea, i32_actordataid arobotid, void*) :
			actor<actor_robot>(
				actorparm
				{
					.m_parm{.m_type = ACTOR_ROBOT,.m_area = aarea, .m_id = arobotid, .m_manage_dbclient = true},
				})
		{
		}

		virtual void init()
		{
		}

		virtual ~actor_robot() {}

		static void actor_register();

		enum { ACTOR_TYPE = ACTOR_ROBOT};

		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_ROLE_SYNC& adata)
		//{
		//	Try
		//	{
		//		std::cout << "---------------[LOGIC_ROLE_SYNC:"<< adata.m_role.const_mm_name() << "]---------------" << std::endl;
		//		//LogLocalInfo("LOGIC_ROLE_SYNC = [%]", adata);
		//		m_data = adata;

		//		/*std::cout << "---------------[CHANGE LINE]---------------" << std::endl;
		//		{
		//			LOGIC_SWITCH_LINE pro;
		//			pro.m_line = 2;
		//			net::sendtoserver(ngl::configxml_node::gateway_serverid(), pro);
		//		}*/
		//		/*boost::this_thread::sleep(boost::posix_time::seconds(10));
		//		std::cout << "---------------[GET TIME]---------------" << std::endl;
		//		{
		//			LOGIC_GET_TIME pro;
		//			net::sendtoserver(ngl::configxml_node::gateway_serverid(), pro);
		//		}*/


		//	}Catch;			
		//	return true;
		//}

		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_GET_TIME_RESPONSE& adata)
		{
			char lbuff[1024] = { 0 };
			ngl::localtime::time2str(lbuff, 1024, adata.m_utc, "%y/%m/%d %H:%M:%S");
			std::cout << "---------------[" << m_data.m_role.const_mm_name() << "][" << lbuff << "]-------------- - " << std::endl;
			return true;
		}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, PB::PROBUFF_LOGIC_GET_TIME_RESPONSE& adata)
		{
			char lbuff[1024] = { 0 };
			ngl::localtime::time2str(lbuff, 1024, adata.m_utc(), "%y/%m/%d %H:%M:%S");
			std::cout << "---------------[" << m_data.m_role.const_mm_name() << "][" << lbuff << "]-------------- - " << std::endl;
			return true;
		}*/

		//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_CHAT_RESPONSE& adata)
		//{
		//	/*if (adata.m_type == get_chat_list)
		//	{
		//		char lbuff[1024] = { 0 };
		//		for (auto& item : adata.m_chat_list)
		//		{
		//			ngl::localtime::time2str(lbuff, 1024, item.m_utc, "%y/%m/%d %H:%M:%S");
		//			LogLocalError("[%][%] %", lbuff, item.m_rolename, item.m_content);
		//		}
		//	}
		//	else if (adata.m_type == chat_speak)
		//	{
		//		LogLocalError("%", (adata.m_stat ? "[���Գɹ�]" : "[����ʧ��] "));
		//	}
		//	else if (adata.m_type == updata_speck)
		//	{
		//		char lbuff[1024] = { 0 };
		//		for (auto& item : adata.m_chat_list)
		//		{
		//			ngl::localtime::time2str(lbuff, 1024, item.m_utc, "%y/%m/%d %H:%M:%S");
		//			LogLocalError("[%][%] %", lbuff, item.m_rolename, item.m_content);
		//		}
		//	}
		//	*/
		//	
		//	return true;
		//}
		

		/*LOGIC_ROLE_SYNC& get()
		{
			return m_data;
		}*/
	private:
	};

	class actor_manage_robot : public actor<actor_manage_robot>
	{

		actor_manage_robot() :
			actor<actor_manage_robot>(
				actorparm
				{
					.m_parm{.m_type = ACTOR_MANAGE_ROBOT, .m_id = nconfig::m_nodeid, .m_manage_dbclient = false},
				})
		{
		}
	public:
		struct _robot
		{
			i32_sessionid m_session;
			std::string m_account;
			actor_robot* m_robot;
			i64_actorid m_actor_roleid;
			_robot() :
				m_session(-1),
				m_robot(nullptr),
				m_actor_roleid(actor_guid::moreactor())
			{}
		};
		std::map<std::string, _robot> m_maprobot;


		friend class actor_instance<actor_manage_robot>;
		static actor_manage_robot& getInstance() 
		{ 
			return actor_instance<actor_manage_robot>::instance();
		}

		actor_robot* create(i16_area aarea, i32_actordataid aroleid)
		{
			return (actor_robot*)actor_base::create(ENUM_ACTOR::ACTOR_ROBOT, aarea, aroleid, nullptr);
		}

		static void login(const std::string& aaccount, const std::string& apasswold)
		{
			//LOGIC_ACOUNT_LOGIN pro;
			//pro.m_account = aaccount;
			//pro.m_password = apasswold;
			//pserver->sendtoserver(ngl::xmlnode::login_serverid(), pro, actor_guid::moreactor(), getInstance().id_guid());
		}

		virtual ~actor_manage_robot() {}

		static void actor_register();

		enum { ACTOR_TYPE = ACTOR_MANAGE_ROBOT};

		void connect(i32_serverid aserverid, const std::function<void(i32_sessionid)>& afun)
		{
			ngl::xmlinfo* linfo = ngl::xmlnode::get_server(aserverid);
			i32_serverid lserverid = 0;
			assert(linfo->id(lserverid));
			std::string lip;
			assert(linfo->ip(lip));
			i16_port lport = 0;
			assert(linfo->port(lport));
			pserver->connect(aserverid, lip, lport, afun, true);
		}


		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, LOGIC_ACOUNT_LOGIN_RESPONSE& adata)
		{
			std::cout << "#############["<< adata.m_account <<"]��¼�ɹ�#############" << std::endl;
			_robot& lrobot = m_maprobot[adata.m_account];
			lrobot.m_robot = create(adata.m_area, actor_guid::actordataid(adata.m_roleid));
			lrobot.m_account = adata.m_account;
			lrobot.m_actor_roleid = actor_guid::make_type(lrobot.m_robot->id_guid(), ACTOR_ROLE);

			connect(adata.m_gatewayid, [adata, &lrobot, this](int asession)
				{
					std::cout << "#############[" << adata.m_account << "]������[GateWay]["<< asession <<"]#############" << std::endl;
					lrobot.m_session = asession;

					LOGIC_ROLE_LOGIN pro;
					pro.m_roleid = adata.m_roleid;
					pro.m_session = adata.m_session;
					pro.m_area = adata.m_area;
					pro.m_iscreate = false;
					pserver->send(asession, pro, actor_guid::moreactor(), this->id_guid());
				});
			
			return true;
		}*/

	public:

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, robot_pram& adata)
		{
			if (adata.m_parm[0] == "logins" || adata.m_parm[0] == "LOGINS")
			{
				create_robots(adata.m_parm[1], boost::lexical_cast<int>(adata.m_parm[2]), boost::lexical_cast<int>(adata.m_parm[3]));
			}
			else if (adata.m_parm[0] == "login" || adata.m_parm[0] == "LOGIN")
			{
				create_robot(adata.m_parm[1]);
			}
			else if (adata.m_parm[0] == "c")
			{//c libo1 1
				/*LOGIC_CMD pro;
				pro.m_cmdnum = (ELOGIC_CMD)boost::lexical_cast<int>(adata.m_parm[2]);
				for (int i = 3; i < adata.m_parm.size(); ++i)
				{
					pro.m_parmstr.push_back(adata.m_parm[i]);
				}
				send(get_robot(adata.m_parm[1]), pro);*/
			}
			else if (adata.m_parm[0] == "C")
			{//C 1
				/*LOGIC_CMD pro;
				pro.m_cmdnum = (ELOGIC_CMD)boost::lexical_cast<int>(adata.m_parm[1]);
				for (int i = 2; i < adata.m_parm.size(); ++i)
				{
					pro.m_parmstr.push_back(adata.m_parm[i]);
				}
				foreach([&pro, this](actor_manage_robot::_robot& arobot) 
					{
						send(&arobot, pro);
						return true;
					});*/
			}
			else if (adata.m_parm[0] == "X")
			{

				PB::PROBUFF_LOGIC_GET_TIME pro;
				foreach([&pro, this](actor_manage_robot::_robot& arobot)
					{
						send(&arobot, pro);
						return true;
					});			
			}
			return true;
		}
		
		void create_robots(std::string& arobotname, int abeg, int aend)
		{
			for (int i = abeg; i <= aend; ++i)
			{
				std::string lname(arobotname);
				lname += "";
				lname += boost::lexical_cast<std::string>(i);
				ngl::actor_manage_robot::login(lname, "123456");
			}
		}

		void create_robot(std::string& arobotname)
		{
			ngl::actor_manage_robot::login(arobotname, "123456");
		}

		void foreach(const std::function<bool(_robot&)>& afun)
		{
			for (auto& item : m_maprobot)
				afun(item.second);
		}

		_robot* get_robot(std::string aacount)
		{
			auto itor = m_maprobot.find(aacount);
			if (itor == m_maprobot.end())
				return nullptr;
			return &itor->second;
		}

		template <typename T>
		void send(_robot* arobot, const T& adata)
		{
			pserver->send(arobot->m_session, adata, actor_guid::moreactor(), arobot->m_actor_roleid);
		}

		bool getdata(_robot* arobot)
		{
			if (arobot == nullptr)
				return false;
			//LogLocalInfo("[%]## [%]", arobot->m_account, arobot->m_robot->get());
			return true;
		}

		bool switchline(_robot* arobot, int aline)
		{
			//LOGIC_SWITCH_LINE pro;
			//pro.m_line = aline;
			//pserver->send(arobot->m_session, pro, actor_guid::moreactor(), id_guid());
			return true;
		}
	};
}
	
