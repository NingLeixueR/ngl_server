#include "actor_map.h"


namespace ngl
{
	void actor_map::actor_register()
	{
		// ��ʱ��
		actor<actor_map>::register_timer();

	}

	void actor_map::loaddb_finish(bool adbishave)
	{
	}

	bool actor_map::timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata)
	{
		time_wheel& lwheel = m_aoimap.timer();
		for (std::shared_ptr<wheel_node> lpnode = lwheel.pop_node(); lpnode != nullptr; lpnode = lwheel.pop_node())
		{
			if (lpnode->m_remove != true)
				lpnode->m_parm.m_fun(lpnode.get());
		}
		return true;
	}
}