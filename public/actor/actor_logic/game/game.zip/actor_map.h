#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"

#include "map.h"


namespace ngl
{
	class actor_map : public actor<actor_map>
	{
	public:
		aoimap m_aoimap;
	public:
		static int32_t create_mapid(int16_t amaptid, int16_t aid)
		{
			int32_t ltemp;
			((int16_t*)(&ltemp))[0] = amaptid;
			((int16_t*)(&ltemp))[1] = aid;
			return ltemp;
		}

		int16_t map_tid()
		{
			int32_t lid = id();
			return ((int16_t*)(&lid))[0];
		}

		int16_t map_number(int32_t aid)
		{
			int32_t lid = id();
			return ((int16_t*)(&lid))[1];
		}
		
		actor_map(i16_area aarea, int16_t amaptid, int16_t anumber, void* adata) :
			actor<actor_map>(
				actorparm
				{
					.m_parm{.m_type = ACTOR_MAP, .m_area = aarea, .m_id = create_mapid(amaptid, anumber),.m_manage_dbclient = true,},
					.m_weight = 0x7fffffff,
					.m_broadcast = true,
				})
		{
		}

		virtual void init()
		{
		}

		static void actor_register();

		virtual ~actor_map() {}

		virtual void loaddb_finish(bool adbishave);

		enum { ACTOR_TYPE = ACTOR_MAP};

		// ��ʱ��
		bool timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata);

	private:
	};
}