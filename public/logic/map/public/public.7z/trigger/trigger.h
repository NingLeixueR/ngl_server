#pragma once

#include <vector>
#include <list>
#include "manage_csv.h"
#include "effect.h"
#include "localtime.h"
#include "time_wheel.h"


namespace ngl
{
	struct buffinfo
	{
		int64_t m_begtimems; // buff��ʼʱ��

		buffinfo(int64_t atimems) :
			m_begtimems(atimems)
		{}
	};

	class trigger;

	class world;

	// ### ������
	class trigger
	{
		TriggerTab* m_tab;
		buffinfo m_buffinfo;
		i64_actorid m_entityid;			// ������
		std::list<effect*> m_effect;
		std::vector<int32_t> m_tslice;
		em_trigger m_type;
		world* m_world;
	public:
		trigger(world* amap);

		void push_effect(effect* aeffect);

		bool init(i64_actorid aunit, buffinfo& ainfo, int32_t atabid);

		void post_timer(int32_t atimeslice, const std::function<void(wheel_node*)>& afun);
		void foreach_timer(std::vector<int32_t>& atimeslice, const std::function<void(wheel_node*)>& afun);

		bool check_tslice();
		bool check_hurt(int32_t ahurt);
		void effect_active(const trigger_parm& aparm);
		void effect_passive();

		static trigger* create(world* amap, i64_actorid aunit, buffinfo& ainfo, int32_t atabid);
	};

}