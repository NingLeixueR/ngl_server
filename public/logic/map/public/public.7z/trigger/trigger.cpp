#include "trigger.h"
#include "manage_buff.h"
#include "map.h"


namespace ngl
{
	trigger::trigger(world* aworld) :
		m_tab(nullptr),
		m_entityid(0),
		m_type(em_trigger_null),
		m_buffinfo(0),
		m_world(aworld)
	{}

	void trigger::push_effect(effect* aeffect)
	{
		m_effect.push_back(aeffect);
	}

	void trigger::post_timer(int32_t atimeslice, const std::function<void(wheel_node*)>& afun)
	{
		wheel_node::parm lparm
		{
			.m_ms = atimeslice,
			.m_intervalms = atimeslice,
			.m_count = 1,
			.m_fun = afun
		};
		m_world->timer().addtimer(lparm);
	}

	void trigger::foreach_timer(std::vector<int32_t>& atimeslice, const std::function<void(wheel_node*)>& afun)
	{
		for (int32_t i = 0; i < atimeslice.size(); ++i)
		{
			post_timer(atimeslice[i], afun);			
		}
	}

	bool trigger::init(i64_actorid aunit, buffinfo& ainfo, int32_t atabid)
	{
		unit* lpunit = m_world->find_unit(aunit);
		if (lpunit == nullptr)
			return false;
		m_buffinfo = ainfo;
		m_tab = allcsv::tab<TriggerTab>(atabid);
		if (m_tab == nullptr)
			return false;
		TriggerTimeslice& lTriggerTimeslice = m_tab->m_tslice;
		if (lTriggerTimeslice.m_timeslicecount.empty() == false)
		{
			int32_t lsize = lTriggerTimeslice.m_timeslicecount.size();
			if (lTriggerTimeslice.m_timeslice.size() != lsize + 1)
				return false;
			m_tslice.resize(lsize);
			if (m_type == em_trigger_timer)
			{
				foreach_timer(lTriggerTimeslice.m_timeslice, [this, aunit, atabid](wheel_node* ap)
					{
						trigger_parm lparm;
						lparm.m_type = em_trigger_timer;
						lparm.m_triggertid = atabid;
						manage_buff::trigger_active(m_world, aunit, lparm);
					});
			}
		}
		else if (m_type == em_trigger_timer)
		{
			return false;
		}

		// ## ����uregion
		for (auto& item : m_tab->m_region)
		{
			uregion* luregionptr = uregion_create::create(m_world, item);
			if (luregionptr == nullptr)
				continue;
			switch (item.m_regionpos)
			{
			case em_trigger_region_relative_position:
			{
				if (item.m_pos == nullptr)
					return false;
				int32_t lx = lpunit->m_pos.x;
				int32_t ly = lpunit->m_pos.y;
				lx += item.m_pos->x;
				ly += item.m_pos->y;
				m_world->enter(luregionptr, lx, ly);
			}
			break;
			}

			i64_actorid luregion = luregionptr->id();
			if (item.m_regionpos == em_trigger_region_move_rand)
			{
				foreach_timer(item.m_regionmove_randtime->m_timeslice, [this, luregion](wheel_node* ap)
					{
						unit* lunit = m_world->find_unit(luregion);
						int lx = lunit->m_pos.x + rand() % 100;
						int ly = lunit->m_pos.y + rand() % 100;
						m_world->move(lunit, lx, ly);
					});				
			}

			if (item.m_regionpos == em_trigger_region_move_regular)
			{
				std::vector<VECTOR>& lvec = item.m_regionmove_regularmove->m_pos;
				for (int timeslice : item.m_regionmove_regulartime->m_timeslice)
				{
					class tfunw
					{
					public:
						static void fun(int aindex, i64_actorid auregion, trigger* atrigger, const std::vector<VECTOR>& avec, wheel_node* ap)
						{
							unit* lunit = atrigger->m_world->find_unit(auregion);
							int lx = lunit->m_pos.x + avec[aindex].x;
							int ly = lunit->m_pos.y + avec[aindex].y;
							atrigger->m_world->move(lunit, lx, ly);
						}
					};
					for (int i = 0; i < lvec.size(); ++i)
					{
						std::function<void(wheel_node*)> lfun = std::bind(&tfunw::fun, i, luregion, this, std::cref(lvec), std::placeholders::_1);
						post_timer(timeslice, lfun);
					}
					
				}
			}
		}
		
		return true;
	}

	bool trigger::check_tslice()
	{
		if (m_tslice.empty() == false)
		{
			int32_t lnow = localtime::gettime();
			int32_t ltemp = lnow - m_buffinfo.m_begtimems;
			int32_t lindex = 0;
			for (; lindex < m_tab->m_tslice.m_timeslice.size(); ++lindex)
			{
				if (ltemp < m_tab->m_tslice.m_timeslice[lindex])
				{
					if (ltemp == 0)
						return false;
				}
			}
			++m_tslice[lindex];
			if (m_tslice[lindex] > m_tab->m_tslice.m_timeslicecount[lindex])
				return false;
		}
		return true;
	}

	bool trigger::check_hurt(int32_t ahurt)
	{
		TriggerHurt* lphurt = m_tab->m_hurt;
		if (lphurt != nullptr)
		{
			if (lphurt->m_less == true && ahurt > lphurt->m_value)
				return true;
			if (lphurt->m_less == false && ahurt < lphurt->m_value)
				return true;
			return false;
		}
		return true;
	}

	void trigger::effect_active(const trigger_parm& aparm)
	{
		if (m_type != aparm.m_type)
			return;
		if (check_tslice() == false)
			return;

		if (check_hurt(aparm.m_hurt) == false)
			return;

		for (effect* item : m_effect)
		{
			if (m_tab->m_target == em_effect_target_oneself)
				item->effect_active(m_entityid, aparm);
			else if (m_tab->m_target == em_effect_target_target)
			{
				if (aparm.m_beattackid.size() == 1 && aparm.m_beattackid[0] == m_entityid)
				{
					item->effect_active(aparm.m_attackid, aparm);
				}
				else if (m_entityid == aparm.m_attackid)
				{
					for (i64_actorid beattackid : aparm.m_beattackid)
						item->effect_active(beattackid, aparm);
				}
			}
			else if (m_tab->m_target == em_effect_target_oneself2target)
			{
				item->effect_active(m_entityid, aparm);
				if (aparm.m_attackid != 0 && m_entityid != aparm.m_attackid)
					item->effect_active(aparm.m_attackid, aparm);
				for (i64_actorid beattackid : aparm.m_beattackid)
				{
					if (beattackid != m_entityid)
						item->effect_active(beattackid, aparm);
				}
			}
		}
	}

	void trigger::effect_passive()
	{
		for (effect* item : m_effect)
		{
			item->effect_passive();
		}
	}

	trigger* trigger::create(world* aworld, i64_actorid aunit, buffinfo& ainfo, int32_t atabid)
	{
		trigger* lptr = new trigger(aworld);
		lptr->init(aunit, ainfo, atabid);
		return lptr;
	}
}