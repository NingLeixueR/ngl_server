#include "unitbase.h"
#include "buff.h"

namespace ngl
{
	void unit::trytrigger(i64_actorid aattackid, em_trigger atrigger)
	{
		for (auto& item : m_buff)
		{
			trigger_parm lparm;
			lparm.m_type = atrigger;
			lparm.m_attackid = aattackid;
			lparm.m_beattackid.push_back(m_entityid);
			item.second->trigger_active(lparm);
		}
	}
}