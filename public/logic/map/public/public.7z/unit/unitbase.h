#pragma once

#include "attribute.h"
#include "csvtable.h"
#include "type.h"
#include "actor_base.h"
#include <stdint.h>

namespace ngl
{
	class urole;
	class umonster;
	class uregion;
	class unit_carelist;
	class buff;
	class unit;
	class unit_attribute;

	class unit
	{
		ENUM_UNIT m_type;
	public:
		unit(ENUM_UNIT atype, i64_actorid aentityid)
			:m_type(atype), m_entityid(aentityid), m_buffstat(em_buffstat_null)
		{
			clear_unitstat();
		}

		i64_actorid m_entityid;
		VECTOR3 m_pos;						// ��ǰλ�� 
		VECTOR3 m_orientation;				// ��ǰ����
		std::string m_name;
		int32_t m_lastmovetime;			// �ϴ�moveʱ��

		//// ### buff start  ###
		std::map<int32_t, buff*> m_buff;
		int32_t m_buffstat;//em_buffstat
		// #### �������״̬  
		time_t m_unitstat[em_unitstat_count];
		//// ### buff finish ###

		// �Ƿ�����ƶ�
		bool is_move() 
		{ 
			check_unitstat();
			return (m_buffstat & em_buffstat_unable_move) == 0; 
		}
		// �Ƿ�����ͷż���
		bool is_releaseskills() 
		{ 
			check_unitstat();
			return (m_buffstat & em_buffstat_unable_release_skills) == 0; 
		}
		// �Ƿ�����չ�
		bool is_attack() 
		{ 
			check_unitstat();
			return (m_buffstat & em_buffstat_unable_attack) == 0; 
		}

		bool check_unitstat()
		{
			time_t ltime = localtime::getms();
			for (int i = 0; i < em_unitstat_count; ++i)
			{
				if (ltime < m_unitstat[i])
					set_unitstat((em_unitstat)i);
			}
			return true;
		}

		bool set_unitstat(em_unitstat aunitstat)
		{
			switch (aunitstat)
			{
			case em_unitstat_vertigo:
			case em_unitstat_frozen:
				m_buffstat |= em_buffstat_unable_move | em_buffstat_unable_release_skills | em_buffstat_unable_attack;
				break;
			case em_unitstat_immobility:
				m_buffstat |= em_buffstat_unable_move;
				break;
			case em_unitstat_silent:
				m_buffstat |= em_buffstat_unable_release_skills;
				break;
			}
			return true;
		}

		bool set_unitstat(em_unitstat aunitstat, time_t ams)
		{
			time_t ltime = localtime::getms() + ams;
			if (ltime > m_unitstat[aunitstat])
			{
				m_unitstat[aunitstat] = ltime;
				return true;
			}
			return false;
		}

		//ams ����ʱ��
		void set_control(em_unitstat aunitstat, i64_actorid aattackid, time_t ams)
		{
			if (set_unitstat(aunitstat, ams) == false)
				return;
			set_unitstat(aunitstat);
			trytrigger(aattackid, (em_trigger)(aunitstat+1));
		}

		void clear_unitstat()
		{
			m_buffstat = em_buffstat_null;
			memset(m_unitstat, 0x0, sizeof(time_t) * em_unitstat_count);
		}
		
		void trytrigger(i64_actorid aattackid, em_trigger atrigger);

		void entity(ENTITY& adata)
		{
			adata.m_type = (int32_t)m_type;
			adata.m_entityid = m_entityid;
			adata.m_pos = m_pos;
			adata.m_orientation = m_orientation;
			adata.m_name = m_name;
			get_entity(adata);
		}

		virtual void get_entity(ENTITY& adata)
		{
		}

		ENUM_UNIT type()
		{
			return m_type;
		}

		i64_actorid id()
		{
			return m_entityid;
		}

		int32_t lastmovetime()
		{
			return m_lastmovetime;
		}

		urole* role()
		{
			return m_type == ROLE_UNIT ? (urole*)this : nullptr;
		}

		umonster* monster()
		{
			return m_type == MONSTER_UNIT ? (umonster*)this : nullptr;
		}

		uregion* region()
		{
			return m_type == REGION_UNIT ? (uregion*)this : nullptr;
		}

		virtual unit_attribute* get_unit_attribute()
		{
			return nullptr;
		}

		virtual unit_carelist* get_carelist()
		{
			return nullptr;
		}

		virtual attribute* get_attribute()
		{
			return nullptr;
		}

	};

	class unit_attribute : public unit
	{
		attribute m_attribute;
	public:
		unit_attribute(ENUM_UNIT atype, i64_actorid aentityid, const attribute& aattribute) :
			unit(atype, aentityid),
			m_attribute(aattribute)
		{}

		virtual void get_entity(ENTITY& adata) final
		{
			adata.m_movespeed = speed();
			//ATTRIBUTE lATTRIBUTE;
			//lATTRIBUTE.mm_attribute() = m_attribute.fight_all_attribute();
			//lATTRIBUTE.mm_fight() = m_attribute.fight();
			//adata.mm_attribute() = lATTRIBUTE;
		}

		virtual attribute* get_attribute()
		{
			return &m_attribute;
		}

		int32_t module_attribute(enum_attribute aenum, enum_module_attribute amodule = em_attribute_root)
		{
			return m_attribute.fight_attribute(attribute_attack, amodule);
		}

		//### ����
		// [����]
		int32_t attack()
		{
			return module_attribute(attribute_attack);
		}
		// [����]
		int32_t defense()
		{
			return module_attribute(attribute_defense);
		}
		// [Ѫ��]
		int32_t hp()
		{
			return module_attribute(attribute_hp);
		}
		// [ŭ��]
		int32_t anger()
		{
			return module_attribute(attribute_anger);
		}
		// [�ٶ�]
		int32_t speed()
		{
			return module_attribute(attribute_speed);
		}

		virtual unit_attribute* get_unit_attribute()
		{
			return this;
		}
	};

	class ucarelist
	{
		std::set<i64_actorid> m_carelist;
		int32_t m_corelistmaxcount;
	public:
		ucarelist(int32_t acorelistmaxcount) :
			m_corelistmaxcount(acorelistmaxcount)
		{}

		ucarelist()
		{}

		void init(int32_t acorelistmaxcount)
		{
			m_corelistmaxcount = acorelistmaxcount;
		}

		const std::set<i64_actorid>& carelist()
		{
			return m_carelist;
		}

		// ### �Ƿ񻹿�����corelist������
		bool ispushcorelist()
		{
			return m_carelist.size() < m_corelistmaxcount;
		}

		int32_t corelistmax()
		{
			return m_corelistmaxcount;
		}

		int32_t corelistcount()
		{
			return m_carelist.size();
		}

		bool push_corelist(i64_actorid acoreid)
		{
			if(ispushcorelist())
				return m_carelist.insert(acoreid).second;
			return false;
		}

		bool remove_corelist(i64_actorid acoreid)
		{
			m_carelist.erase(acoreid);
			return true;
		}

		bool clear_corelist()
		{
			m_carelist.clear();
			return true;
		}
	};

	class unit_carelist
	{
		std::map<ENUM_UNIT, ucarelist> m_carelist;
	public:
		unit_carelist(
			const std::map<ENUM_UNIT, int32_t>& amap = 
			{ 
				{ROLE_UNIT,unit_corelist_role_maxcount},
				{MONSTER_UNIT,unit_corelist_monster_maxcount},
				{REGION_UNIT,unit_corelist_region_maxcount},
			}
		)
		{
			for (auto& [key, value] : amap)
			{
				m_carelist.insert(std::make_pair(key, ucarelist(value)));
			}
		}
	private:
		ucarelist* clist(ENUM_UNIT atype)
		{
			auto itor = m_carelist.find(atype);
			if (itor == m_carelist.end())
				return nullptr;
			return &itor->second;
		}
	public:
		const std::set<i64_actorid>* carelist(ENUM_UNIT atype)
		{
			ucarelist* lpclist = clist(atype);
			if (lpclist == nullptr)
				return nullptr;
			return &lpclist->carelist();
		}

		bool ispushcorelist(unit* aunit)
		{
			if (check_region(aunit) == false)
				return false;
			ucarelist* lpcls = clist(aunit->type());
			if (lpcls == nullptr)
				return false;
			return lpcls->ispushcorelist();
		}

		bool push_corelist(unit* aunit)
		{
			ucarelist* lpcls = clist(aunit->type());
			if (lpcls == nullptr)
				return false;
			if (lpcls->push_corelist(aunit->id()) == false)
				return false;
			add_carelist(aunit);
			return true;
		}

		bool remove_corelist(unit* aunit)
		{
			ucarelist* lpcls = clist(aunit->type());
			if (lpcls == nullptr)
				return false;
			if (lpcls->remove_corelist(aunit->id()) == false)
				return false;
			remove_carelist(aunit);
			return true;
		}

		bool clear_corelist(ENUM_UNIT atype)
		{
			ucarelist* lpcls = clist(atype);
			if (lpcls == nullptr)
				return false;
			return lpcls->clear_corelist();
		}

		virtual bool check_region(unit* aunit)
		{
			return true;
		}

		virtual unit_carelist* get_carelist()
		{
			return this;
		}

		virtual void add_carelist(unit* aunit)
		{

		}

		virtual void remove_carelist(unit* aunit)
		{

		}
	};
}