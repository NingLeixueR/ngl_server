#pragma once

#include "unitbase.h"


namespace ngl
{
	// #### �����ս����λ����
	class umonster : public unit_attribute, public unit_carelist
	{
	public:
		umonster(i64_actorid aentityid, const attribute& aattribute) :
			unit_attribute(MONSTER_UNIT, aentityid, aattribute),
			unit_carelist()
		{}
	};
}