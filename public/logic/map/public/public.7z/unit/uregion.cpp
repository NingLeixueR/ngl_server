#include "uregion.h"
#include "map.h"


namespace ngl
{
	uregion* uregion_create::create(world* amap, const TriggerRegion& aregion)
	{
		uregion* luregion = new uregion(amap->entityid());
		eregion* lp = nullptr;
		
		
		switch (aregion.m_type)
		{
		case eregion_circular:
			if (aregion.m_circular == nullptr)
				return nullptr;
			lp = new region_circular(&luregion->m_pos, aregion.m_circular->m_radius);
			break;
		case eregion_rect:
			if (aregion.m_rect == nullptr)
				return nullptr;
			lp = new region_rect(&luregion->m_pos, aregion.m_rect->m_wide, aregion.m_rect->m_high);
			break;
		case eregion_annular:
			if (aregion.m_annular == nullptr)
				return nullptr;
			lp = new region_annular(&luregion->m_pos, aregion.m_annular->m_inner_radius, aregion.m_annular->m_outer_radius);
			break;
		default:
			return nullptr;
		}
		lp->m_id = amap->entityid();
		lp->set_activation(true);
		luregion->init(lp);
		return luregion;
	}
}