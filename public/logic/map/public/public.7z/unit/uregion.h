#pragma once

#include "unitbase.h"
#include "region.h"
#include "aoi_notify.h"


namespace ngl
{
	// ����
	class uregion : public unit, public unit_carelist
	{
		eregion* m_region;
	public:
		uregion(i64_actorid aentityid) :
			unit(REGION_UNIT, aentityid),
			unit_carelist(
				{ 
					{ROLE_UNIT, 0x7fffffff},
					{MONSTER_UNIT, unit_corelist_monster_maxcount}, 
				}),
				m_region(nullptr)
		{}

		void init(eregion* aregion)
		{
			m_region = aregion;
		}
		
		virtual bool check_region(unit* aunit)
		{
			return m_region->check(aunit->m_pos);
		}

		virtual void add_carelist(unit* aunit)
		{
			notify_parm_enter_region lparm;
			lparm.m_region = m_region->m_id;
			lparm.m_actor = aunit->id();
			notify<notify_parm_enter_region>::execute(lparm);
		}

		virtual void remove_carelist(unit* aunit)
		{
			notify_parm_leave_region lparm;
			lparm.m_region = m_region->m_id;
			lparm.m_actor = aunit->id();
			notify<notify_parm_leave_region>::execute(lparm);
		}

	};

	class world;
	class uregion_create
	{
	public:
		static uregion* create(world* amap, const TriggerRegion& aregion);
	};
}