#pragma once

#include "unitbase.h"


namespace ngl
{
	// #### ��ҵ�ս����λ����
	class urole : public unit_attribute, public unit_carelist
	{
		i32_gatewayid m_gateway;
	public:
		urole(i64_actorid aentityid, int32_t agateway, const attribute& aattribute) :
			unit_carelist(),
			unit_attribute(ROLE_UNIT, aentityid, aattribute),
			m_gateway(agateway)
		{}

		i32_gatewayid gateway()
		{
			return m_gateway;
		}

		template <typename T>
		void send_client(T& adata)
		{
			if (m_gateway != 0)
				actor_base::send_client(m_gateway, actor_guid::make(), adata);
		}

	};
}