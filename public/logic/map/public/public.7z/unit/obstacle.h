#pragma once

#include "unitbase.h"


namespace ngl
{
	// #### �ϰ���
	class unitobstacle : public unit
	{
	public:
		unitobstacle(i64_actorid aentityid) :
			unit(OBSTACLE_UNIT, aentityid)
		{}
	};
}