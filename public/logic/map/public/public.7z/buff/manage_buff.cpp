#include "manage_buff.h"
#include "world.h"

namespace ngl
{
	void manage_buff::trigger_active(world* aworld, i64_actorid aunit, const trigger_parm& aparm)
	{
		unit* lpunit = aworld->find_unit(aunit);
		if (lpunit == nullptr)
			return;
		for (auto& [key, item] : lpunit->m_buff)
			item->trigger_active(aparm);
	}

	void manage_buff::create(world* aworld, i64_actorid aunit, int32_t abuffid)
	{
		unit* lpunit = aworld->find_unit(aunit);
		if (lpunit == nullptr)
			return;
		buff* lpbuff = buff_create::create(aworld, aunit, abuffid);
		if (lpbuff == nullptr)
			return;
		lpbuff->start();
		lpunit->m_buff.insert(std::make_pair(lpbuff->id(), lpbuff));
	}

	void manage_buff::remove(world* aworld, i64_actorid aunit, int32_t abuffid)
	{
		unit* lpunit = aworld->find_unit(aunit);
		if (lpunit == nullptr)
			return;
		auto itor = lpunit->m_buff.find(abuffid);
		if (itor == lpunit->m_buff.end())
			return;
		itor->second->effect_passive();
		lpunit->m_buff.erase(itor);
	}
}