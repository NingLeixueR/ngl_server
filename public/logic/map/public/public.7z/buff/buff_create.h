#pragma once

#include "buff.h"

namespace ngl
{
	class world;
	class buff_create
	{
	public:
		static buff* create(world* amap, i64_actorid aunit, int32_t abufftab);
	};
}