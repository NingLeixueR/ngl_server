#pragma once

#include "buff.h"
#include "buff_create.h"

namespace ngl
{
	class manage_buff
	{
	public:
		static void trigger_active(world* amap, i64_actorid aunit, const trigger_parm& aparm);
		static void create(world* amap, i64_actorid aunit, int32_t abuffid);
		static void remove(world* amap, i64_actorid aunit, int32_t abuffid);
	};
}