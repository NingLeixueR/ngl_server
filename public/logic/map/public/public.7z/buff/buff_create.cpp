#include "buff_create.h"
#include "effect_create.h"
#include "time_wheel.h"
#include "world.h"


namespace ngl
{
	buff* buff_create::create(world* aworld, i64_actorid aunit, int32_t abufftab)
	{
		int32_t lid = aworld->number(aunit);
		if (lid == 0)
			lid = em_attribute_effectindex;
		BuffTab* ltab = allcsv::tab<BuffTab>(abufftab);
		if (ltab == nullptr)
			return nullptr;
		buff* lp = new buff(aworld, lid);
		buffinfo lbuffinfo(time_wheel::getms());
		for (int32_t effectid : ltab->m_effect)
		{
			EffectTab* lEffectTab = allcsv::tab<EffectTab>(effectid);
			if (lEffectTab == nullptr)
				continue;
			EffectTrigger& lEffectTrigger = lEffectTab->m_effecttrigger;
			int32_t ltriggerid = lEffectTrigger.m_triggerid;
			TriggerTab* lTriggerTab = allcsv::tab<TriggerTab>(ltriggerid);
			if (lTriggerTab == nullptr)
				continue;
			if (ltriggerid > 0)
			{
				trigger* lptrigger = trigger::create(aworld, aunit, lbuffinfo, ltriggerid);
				for (Effect& itemEffect : lEffectTrigger.m_effect)
				{
					effect* lptreffect = effect_create::create(aworld, aunit, itemEffect);
					lptrigger->push_effect(lptreffect);
				}
				if (lTriggerTab->m_type == em_trigger_timer)
				{
					lp->m_tidtrigger[ltriggerid] = lptrigger;
				}
				else
				{
					lp->m_eventtrigger[lTriggerTab->m_type].push_back(lptrigger);
				}
			}
		}
		return lp;
	}
}