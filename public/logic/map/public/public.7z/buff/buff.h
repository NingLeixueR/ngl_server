#pragma once

#include "nlog.h"
#include "notify.h"
#include "splite.h"
#include "manage_csv.h"
#include "localtime.h"
#include "effect.h"
#include "trigger.h"
#include "unitbase.h"

#include <cstdint>
#include <map>
#include <tuple>
#include <list>


namespace ngl
{
	class world;
	class buff_create;
	class buff
	{
		friend class buff_create;
		int32_t m_id;
		std::map<em_trigger, std::list<trigger*>> m_eventtrigger;		// �¼�����
		std::map<int32_t, trigger*> m_tidtrigger;						// em_trigger_timer key:������tid
		world* m_world;
	public:
		buff(world* aworld, int32_t aid) :
			m_id(aid),
			m_world(aworld)
		{}

		int32_t id()
		{
			return m_id;
		}

		world* get_world()
		{
			return m_world;
		}

		void start()
		{

		}

		void trigger_active(const trigger_parm& aparm)
		{
			if (aparm.m_type == em_trigger_timer)
			{
				if (aparm.m_triggertid == 0)
					return;
				trigger** lp = tools::findmap(m_tidtrigger, aparm.m_triggertid);
				if (lp == nullptr)
					return;
				(*lp)->effect_active(aparm);
			}
			else
			{
				std::list<trigger*>* lp = tools::findmap(m_eventtrigger, aparm.m_type);
				if (lp == nullptr)
					return;
				for (trigger* item : *lp)
				{
					item->effect_active(aparm);
				}
			}			
		}

		void effect_passive()
		{
			for (auto& [key, value] : m_eventtrigger)
			{
				for(trigger* item : value)
					item->effect_passive();
			}
		}
	};

	
}