#pragma once

#include <map>
#include "effect.h"

namespace ngl
{
	// Ч��[���Ӹ�������]
	class effect_attachedbuff : public effect
	{
		std::map<i64_actorid, int32_t> m_value;// �ۼƵ�ֵ
	public:
		effect_attachedbuff(world* aworld, int32_t aid);
	private:
		virtual bool init(Effect& aeffect);
		virtual void active(i64_actorid aunit, const trigger_parm& aparm);
		virtual void passive();
	};
}