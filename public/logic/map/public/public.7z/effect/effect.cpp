#include "effect.h"
#include "world.h"

namespace ngl
{
	/*effect::effect(world* aworld, int32_t aid, em_effect atype) :
		m_id(aid),
		m_active(false),
		m_type(atype),
		m_world(aworld)
	{}*/

	effect::effect(world* aworld, int32_t aid):
		m_id(aid),
		m_active(false),
		m_world(aworld)
	{}

	bool effect::effect_init(Effect& aeffect)
	{
		Try
		{
			m_effect = aeffect;
		}Catch;
		return init(aeffect);
	}

	void effect::effect_active(i64_actorid aunit, const trigger_parm& aparm)
	{
		m_active = true;
		active(aunit, aparm);
	}
	void effect::effect_passive()
	{
		if (m_active)
			passive();
	}
}