#include "effect_control.h"
#include "world.h"

namespace ngl
{
	effect_control::effect_control(world* aworld, int32_t aid) :
		effect(aworld, aid)
	{
	}

	bool effect_control::init(Effect& aeffect)
	{
		return true;
	}

	void effect_control::active(i64_actorid aunit, const trigger_parm& aparm)
	{
		if (m_effect.m_control == nullptr)
			return;
		for (i64_actorid id : aparm.m_beattackid)
		{
			unit* lunit = m_world->find_unit(id);
			if (lunit == nullptr)
				continue;
			
			lunit->set_control(m_effect.m_control->m_controlid, aparm.m_attackid, m_effect.m_control->m_ms);
		}
	}

	void effect_control::passive()
	{
		
	}
}