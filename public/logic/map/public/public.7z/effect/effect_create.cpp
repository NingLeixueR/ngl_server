#include "effect_create.h"
#include "effect_attachedattribute.h"
#include "effect_attachedbuff.h"
#include "effect_control.h"
#include "effect_purify.h"
#include "world.h"


namespace ngl
{
	effect* effect_create::create(world* aworld, i64_actorid aunit, Effect& aeffect)
	{
		int32_t lid = aworld->number(aunit);
		if (lid == 0)
			lid = em_attribute_effectindex;
		effect* lp = nullptr;
		switch (aeffect.m_effect)
		{
		case em_effect_attachedattribute:
			lp = new effect_attachedattribute(aworld, lid);
			break;
		case em_effect_attachedbuff:
			lp = new effect_attachedbuff(aworld, lid);
			break;
		case em_effect_vertigo:
		case em_effect_frozen:
		case em_effect_immobility:
		case em_effect_silent:
			lp = new effect_control(aworld, lid);
			break;
		case em_effect_purify:
			lp = new effect_purify(aworld, lid);
			break;
		default:
			return nullptr;
		}
		lp->effect_init(aeffect);
		return lp;
	}
}