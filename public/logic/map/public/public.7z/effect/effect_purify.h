#pragma once

#include <map>
#include "effect.h"

namespace ngl
{
	// Ч��[���Ӹ�������]
	class effect_purify : public effect
	{
	public:
		effect_purify(world* aworld, int32_t aid);
	private:
		virtual bool init(Effect& aeffect);
		virtual void active(i64_actorid aunit, const trigger_parm& aparm);
		virtual void passive();
	};
}