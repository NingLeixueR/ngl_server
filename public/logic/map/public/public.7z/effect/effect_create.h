#pragma once

#include <map>
#include <cstdint>
#include "type.h"
#include "effect.h"
#include "manage_csv.h"

namespace ngl
{
	class world;
	class effect_create
	{
	public:
		static effect* create(world* amap, i64_actorid aunit, Effect& aeffect);
	};
}