#pragma once

#include <vector>
#include "type.h"
#include "manage_csv.h"

namespace ngl
{
	// ��������
	struct trigger_parm
	{
		em_trigger m_type;
		int32_t m_triggertid;
		i64_actorid m_attackid;					// ������(ʩ����)
		std::vector<i64_actorid> m_beattackid;	// ��������(��ʩ����)
		int32_t m_hurt;							// ��ɵ��˺�

		trigger_parm() :
			m_type(em_trigger_null),
			m_triggertid(0),
			m_attackid(0),
			m_hurt(0)
		{}
	};
	class world;
	// Ч��
	struct effect
	{
		int32_t m_id;
		bool m_active;
		Effect m_effect;
		world* m_world;

		effect(world* aworld, int32_t aid);
		bool effect_init(Effect& aeffect);
		void effect_active(i64_actorid aunit, const trigger_parm& aparm);
		void effect_passive();
	private:
		virtual void active(i64_actorid aunit, const trigger_parm& aparm) = 0;
		virtual void passive() = 0;
		virtual bool init(Effect& aeffect) = 0;
	};


}