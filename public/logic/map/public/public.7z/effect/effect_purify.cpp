#include "effect_purify.h"
#include "world.h"

namespace ngl
{
	effect_purify::effect_purify(world* aworld, int32_t aid) :
		effect(aworld, aid)
	{
	}

	bool effect_purify::init(Effect& aeffect)
	{
		return true;
	}

	void effect_purify::active(i64_actorid aunit, const trigger_parm& aparm)
	{
		for (i64_actorid id : aparm.m_beattackid)
		{
			unit* lunit = m_world->find_unit(id);
			if (lunit == nullptr)
				continue;
			
			lunit->clear_unitstat();
		}
	}

	void effect_purify::passive()
	{
		
	}
}