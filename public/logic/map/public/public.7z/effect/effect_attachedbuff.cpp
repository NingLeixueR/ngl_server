#include "effect_attachedbuff.h"

namespace ngl
{
	effect_attachedbuff::effect_attachedbuff(world* aworld, int32_t aid) :
		effect(aworld, aid)
	{
	}

	bool effect_attachedbuff::init(Effect& aeffect)
	{
		return true;
	}

	void effect_attachedbuff::active(i64_actorid aunit, const trigger_parm& aparm)
	{
	}

	void effect_attachedbuff::passive()
	{
		
	}
}