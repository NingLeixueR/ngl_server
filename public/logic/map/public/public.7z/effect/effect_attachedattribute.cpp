#include "effect_attachedattribute.h"
#include "map.h"


namespace ngl
{
	effect_attachedattribute::effect_attachedattribute(world* aworld, int32_t aid) :
		effect(aworld, aid)
	{
	}

	bool effect_attachedattribute::init(Effect& aeffect)
	{
		return true;
	}

	void effect_attachedattribute::active(i64_actorid aunit, const trigger_parm& aparm)
	{
		unit* lpunit = m_world->find_unit(aunit);
		if (lpunit == nullptr)
			return;
		attribute* lattribute = lpunit->get_attribute();
		if (lattribute == nullptr)
			return;
		attribute_value lattributevalue;
		int32_t lvalues = 0;
		EffectAttachedAttribute* ltab = m_effect.m_eattachedattribute;
		switch (ltab->m_type)
		{
		case em_effect_attachedattribute_operator_hurt:// �����˺���������ֵ
			lvalues = aparm.m_hurt;
			if (ltab->m_ratio)
				lvalues *= ltab->m_ratioval;

			break;
		case em_effect_attachedattribute_operator_direct:// ֱ����������ֵ
			lvalues = ltab->m_val;
			break;
		}
		if (m_value[aunit] < ltab->m_maxval)
		{
			m_value[aunit] += lvalues;
			if (m_value[aunit] > ltab->m_maxval)
				m_value[aunit] = ltab->m_maxval;
			lattributevalue.insert(ltab->m_attr, m_value[aunit]);
			lattribute->updata((enum_module_attribute)(m_id), lattributevalue);
		}
	}

	void effect_attachedattribute::passive()
	{
		if (m_effect.m_eattachedattribute->m_inhibition == false)
			return;
		for (auto [key, value] : m_value)
		{
			unit* lpunit = m_world->find_unit(key);
			if (lpunit == nullptr)
				continue;
			attribute* lattribute = lpunit->get_attribute();
			if (lattribute == nullptr)
				continue;
			lattribute->remove((enum_module_attribute)(m_id));
		}
	}
}