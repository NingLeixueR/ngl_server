#include "map.h"


namespace ngl
{
	aoimap::aoimap()
	{}
}