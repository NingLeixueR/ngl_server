#pragma once

#include "aoi.h"
#include "game_shared.h"
#include "csvtable.h"

namespace ngl
{
	// ����
	class eregion
	{
		enum_region m_region;
		bool m_activation; // �Ƿ񼤻�
	public:
		i64_actorid m_id;

		eregion(enum_region eregion) :
			m_region(eregion),
			m_activation(false),
			m_id(0)
		{}

		void set_activation(bool aactivation)
		{
			m_activation = aactivation;
		}

		static bool check(eregion* areg, const VECTOR3& apos)
		{
			if (areg->m_activation == false)
				return false;
			return areg->check(apos);
		}
		// ## �����Ƿ���������
		virtual bool check(const VECTOR3&) = 0;
	};

	// ����:Բ��
	class region_circular : public eregion
	{
	public:
		VECTOR3* m_core; // ����
		float m_radius; // �뾶

		region_circular() :
			eregion(eregion_circular),
			m_radius(0.0f),
			m_core(nullptr)
		{
		}

		region_circular(VECTOR3* acore, float aradius) :
			eregion(eregion_circular),
			m_radius(aradius),
			m_core(acore)
		{
		}

	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR3& apos)
		{
			if (m_core == nullptr)
				return false;
			return !(m_radius < aoi::distance(*m_core, apos));
		}
	};

	// ����:����
	class region_rect : public eregion
	{
	public:
		VECTOR3* m_core;			// ����
		float m_wide;			// ��
		float m_high;			// ��

		region_rect() :
			eregion(eregion_rect),
			m_wide(0.0f),
			m_high(0.0f),
			m_core(nullptr)
		{
		}

		region_rect(VECTOR3* acore, float awide, float ahigh) :
			eregion(eregion_rect),
			m_wide(awide),
			m_high(ahigh),
			m_core(acore)
		{
		}
	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR3& apos)
		{
			if (m_core == nullptr)
				return false;
			VECTOR3 rightdown;
			rightdown.x = m_core->x + m_wide / 2;
			rightdown.y = m_core->y + m_high / 2;
			VECTOR3 lefttop;
			lefttop.x = m_core->x - m_wide / 2;
			lefttop.y = m_core->y - m_high / 2;

			if (apos.x < lefttop.x)
				return false;
			if (apos.y > lefttop.y)
				return false;
			if (apos.x > rightdown.x)
				return false;
			if (apos.y < rightdown.y)
				return false;
			return true;
		}
	};


	// ����:����
	class region_annular
		: public eregion
	{
	public:
		VECTOR3* m_core; // ����
		float m_inner_radius; // ��Ȧ�뾶
		float m_outer_radius; // ��Ȧ�뾶

		region_annular() :
			eregion(eregion_annular),
			m_inner_radius(0.0f),
			m_outer_radius(0.0f),
			m_core(nullptr)
		{
		}

		region_annular(VECTOR3* acore, float ainner_radius, float aouter_radius) :
			eregion(eregion_annular),
			m_inner_radius(ainner_radius),
			m_outer_radius(aouter_radius),
			m_core(acore)
		{
		}
	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR3& apos)
		{
			if (m_core == nullptr)
				return false;
			float ldistance = aoi::distance(*m_core, apos);
			if (ldistance < m_inner_radius)
				return false;
			if (ldistance > m_outer_radius)
				return false;
			return true;
		}
	};

}
