#include "world.h"


namespace ngl
{
	time_wheel_config gwc;
	world::world() :
		m_timer(gwc, false),
		m_entityid(0)
	{}
}