#pragma once

#include "unit.h"
#include "aoi.h"
#include "grid.h"
#include "tools.h"
#include "world.h"

namespace ngl
{


	class aoimap : public world
	{
		grids m_grids;			// ��Ұ����
		obstacles m_obstacles;		// Ѱ·����(��λС����)
		MapTab* m_tab;			// ��ͼ������������
		std::map<i64_actorid, urole*> m_roleunit;
		std::map<i64_actorid, umonster*> m_monster;
		std::map<i64_actorid, uregion*> m_region;

	public:
		aoimap();
		
		urole* find_role(i64_actorid aid)
		{
			urole** lp = tools::findmap(m_roleunit, aid);
			return lp == nullptr ? nullptr : *lp;
		}

		umonster* find_monster(i64_actorid aid)
		{
			umonster** lp = tools::findmap(m_monster, aid);
			return lp == nullptr ? nullptr : *lp;
		}

		uregion* find_region(i64_actorid aid)
		{
			uregion** lp = tools::findmap(m_region, aid);
			return lp == nullptr ? nullptr : *lp;
		}

		virtual unit* find_unit(i64_actorid aid)
		{
			unit* lpunit = find_role(aid);
			if (lpunit != nullptr)
				return lpunit;
			lpunit = find_monster(aid);
			if (lpunit != nullptr)
				return lpunit;
			lpunit = find_region(aid);
			if (lpunit != nullptr)
				return lpunit;
			return nullptr;
		}

		bool init_map(int32_t amapid)
		{
			m_tab = allcsv::tab<MapTab>(amapid);
			if (m_tab == nullptr)
			{
				LogLocalError("allcsv::tab<MapTab>(%) == nullptr", amapid);
				return false;
			}
			m_grids.init(m_tab->m_w, m_tab->m_l, m_tab->m_aoi_x_size, m_tab->m_aoi_y_size);
			m_obstacles.init(m_tab->m_w, m_tab->m_l, m_tab->m_obstacle_x_size, m_tab->m_obstacle_y_size);
			m_obstacles.set_obstacles(m_tab->m_obstacle);
			return true;
		}

		virtual bool enter(unit* aunit, uint32_t ax, uint32_t ay)
		{
			return enter(aunit, m_grids.id(ax, ay));
		}

		virtual bool enter(unit* aunit, uint32_t agid)
		{
			if (!m_grids.enter(aunit, agid))
			{
				LogLocalError("aoi_map::enter(tid=%,id=%,agid=%) fail", m_tab->id, aunit->id(), agid);
				return false;
			}
			urole* lprole = aunit->role();
			unit_carelist* lpucarelist = aunit->get_carelist();
			if (lpucarelist == nullptr)
				return false;

			grid* lgrid = nullptr;
			std::map<i32_gatewayid, std::vector<i64_actorid>> lmassset; // key GateWay Id

			std::set<int32_t> lgidset;
			m_grids.idaround_list(agid, lgidset);

			LOGIC_MAP_ENTITY_VIEW pro;
			ENTITY lentity;
			aunit->entity(lentity);
			pro.m_entitylist.push_back(lentity);

			LOGIC_MAP_ENTITY_VIEW proenterview;
			for (int32_t id : lgidset)
			{
				lgrid = m_grids.get_grid(id);
				if (lgrid == nullptr)
				{
					LogLocalError("m_grid.get_grid(tid=%,id=%,agid=%) fail", m_tab->id, aunit->id(), id);
					return false;
				}

				for (int i = 0; i < ENUM_UNIT_COUNT; ++i)
				{
					const std::set<i64_actorid>* ltempset = lgrid->get_unitlist((ENUM_UNIT)(i));
					for (i64_actorid id : *ltempset)
					{

						unit* lpitemunit = find_unit(id);
						urole* lpunit = lpitemunit->role();

						if (lpitemunit == nullptr)
							continue;

						if (lpucarelist->ispushcorelist(lpitemunit) == false)
							break;

						unit_carelist* lpitemucarelist = lpitemunit->get_carelist();
						if (lpitemucarelist->ispushcorelist(lprole) == false)
							continue;

						if (lpucarelist->push_corelist(lpitemunit) && lpitemucarelist->push_corelist(lprole))
						{
							// #### send to client
							if (lpunit != nullptr)
								lmassset[lpunit->gateway()].push_back(id);

							if (lprole != nullptr)
							{
								int lcount = proenterview.m_entitylist.size() + 1;
								proenterview.m_entitylist.resize(lcount);
								lpunit->entity(*proenterview.m_entitylist.rbegin());
							}
						}

					}
				}
			}

			if (lprole != nullptr)
				actor_base::send_client(lprole->gateway(), lprole->id(), proenterview);
			actor_base::send_client(lmassset, pro);

			return true;
		}

		virtual void leave(unit* aunit)
		{
			int lgrid = m_grids.id(aunit->m_pos.x, aunit->m_pos.y);
			m_grids.leave(aunit, lgrid);


			LOGIC_MAP_LEAVE_VIEW pro;
			pro.m_entitylist.push_back(aunit->m_entityid);

			std::map<i32_gatewayid, std::vector<i64_actorid>> lmassset; // key GateWay Id
			if (aunit != nullptr)
			{
				unit_carelist* lpcarelistbase = aunit->get_carelist();
				for (int i = 0; i < ENUM_UNIT_COUNT; ++i)
				{
					const std::set<i64_actorid>* lsetcarelist = lpcarelistbase->carelist((ENUM_UNIT)i);
					if (lsetcarelist != nullptr)
					{
						for (i64_actorid id : *lsetcarelist)
						{
							unit* lpunit = find_unit(id);
							if (lpunit == nullptr)
								continue;
							urole* lproleunit = lpunit->role();
							if(lproleunit != nullptr)
								lmassset[lproleunit->gateway()].push_back(id);
							enter(lpunit, lpunit->m_pos.x, lpunit->m_pos.y);
						}
						lpcarelistbase->clear_corelist((ENUM_UNIT)i);
					}
				}
			}
			actor_base::send_client(lmassset, pro);
		}

		virtual bool move(unit* aunit, int32_t ax, int32_t ay)
		{
			unit_attribute* uattribute = aunit->get_unit_attribute();
			if (uattribute == nullptr)
				return false;
			int32_t ldistance = aoi::distance(ax, ay, aunit->m_pos.x, aunit->m_pos.y);
			int32_t interval = localtime::gettime() - aunit->lastmovetime();
			if (ldistance > interval * uattribute->speed())
				return false;
			urole* lprole = (urole*)aunit;
			int32_t lgid = m_grids.id(ax, ay);
			int32_t loldgid = m_grids.id(aunit->m_pos.x, aunit->m_pos.y);
			lprole->m_pos.x = ax;
			lprole->m_pos.y = ay;

			if (lgid != loldgid)
			{
				std::set<int32_t> lgidset;
				std::set<int32_t> loldgidset;
				m_grids.idaround_list(lgid, lgidset);
				m_grids.idaround_list(loldgid, loldgidset);

				unit_carelist* lpcarelistbase = aunit->get_carelist();

				LOGIC_MAP_ENTITY_VIEW pro;
				ENTITY lentity;
				aunit->entity(lentity);
				pro.m_entitylist.push_back(lentity);

				std::map<i32_gatewayid, std::vector<int64_t>> lmassset; // key GateWay Id

				// leave
				std::set<unit*> llevelset;

				for (int i = 0; i < ENUM_UNIT_COUNT; ++i)
				{
					const std::set<i64_actorid>* lsetcarelist = lpcarelistbase->carelist((ENUM_UNIT)i);
					if (lsetcarelist == nullptr)
						continue;
					for (int64_t id : *lsetcarelist)
					{
						unit* lpunit = find_unit(id);
						if (lpunit == nullptr)
							continue;

						uint32_t lgid = m_grids.id(lpunit->m_pos.x, lpunit->m_pos.y);
						if (loldgidset.find(lgid) != loldgidset.end() && lgidset.find(id) == lgidset.end())
						{
							llevelset.insert(lpunit);

							lpunit->get_carelist()->remove_corelist(aunit);
							lpcarelistbase->remove_corelist(lpunit);

							if (lpunit->role() != nullptr)
								lmassset[lpunit->role()->gateway()].push_back(id);
						}
					}
				}


				enter(aunit, ax, ay);

				for (unit* lunit : llevelset)
				{
					enter(lunit, lunit->m_pos.x, lunit->m_pos.y);
				}

				actor_base::send_client(lmassset, pro);
			}
		}

	};
}