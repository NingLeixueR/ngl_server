#pragma once

#include "unit.h"
#include "time_wheel.h"
#include "type.h"


namespace ngl
{

	class world
	{
		time_wheel m_timer;
		std::map<i64_actorid, int32_t> m_number;
		i64_actorid m_entityid;
	public:
		world();

		int32_t number(i64_actorid aid)
		{
			return ++m_number[aid];
		}

		i64_actorid entityid()
		{
			return ++m_entityid;
		}

		time_wheel& timer()
		{
			return m_timer;
		}

		virtual unit* find_unit(i64_actorid aid) = 0;

		virtual bool enter(unit* aunit, uint32_t ax, uint32_t ay) = 0;
		virtual bool enter(unit* aunit, uint32_t agid) = 0;
		virtual void leave(unit* aunit) = 0;
		virtual bool move(unit* aunit, int32_t ax, int32_t ay) = 0;
	};
}