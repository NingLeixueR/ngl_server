#include "execute_event.h"


namespace ngl
{
	bool execute_event_callback::callback(execute_event* aevent, execute_parm* aparm)
	{
		EnumExecuteEvent ltype = aevent->event_type();
		if (ltype < EnumExecuteEventStart && ltype >= EnumExecuteEventCount)
			return false;
		return m_eventfun[ltype](aevent, aparm);
	}

}