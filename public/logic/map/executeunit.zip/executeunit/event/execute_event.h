#pragma once

#include <map>
#include <functional>
#include "csvtable.h"
#include "managecsv.h"

namespace ngl
{
	//######### ִ�е�Ԫ-�¼�
	class execute_event_callback
	{
	public:
		using event_callback = std::function<bool(execute_event*, execute_parm*)>;
		static std::array<event_callback, EnumExecuteEventCount> m_eventfun;
		// ע��������
		static void init();

		static bool callback(execute_event* aevent, execute_parm* aparm);
	};
	// �¼�����
	class execute_event
	{
		execute_event();
		EnumExecuteEvent m_type;
	public:
		execute_event(EnumExecuteEvent atype) :m_type(atype) {}

		EnumExecuteEvent event_type() { return m_type; }

		bool run_event(execute_parm* apram)
		{
			return execute_event_callback::callback(this, apram);
		}

		template <typename DERIVED>
		static void rfun()
		{
			m_eventfun[DERIVED().event_type()] = [](execute_event* ap, execute_parm* aparm)->bool
			{
				return ((DERIVED*)(ap))->run_event(aparm);
			};
		}

		// ע��������
		static void init();
	};
}