#pragma once

#include <map>
#include <list>
#include <boost/function.hpp>

#include "manage_csv.h"
#include "nlog.h"
#include "db_modular.h"
#include "actor_timer.h"
#include "splite.h"

namespace ngl
{
	class actor_role;

	struct triggertime_base_parm
	{
		int m_triggertimeid;
		triggertime_base_parm(int atriggertimeid) 
			:m_triggertimeid(atriggertimeid) {}
	};

	// �ɴ���n�εĴ���ʱ���
	class triggertime : public db_modular<ENUM_DB_TRIGGER_TIMENODE, DB_TRIGGER_TIMENODE, actor_role>
	{
	public:
	private:
		std::map<ENUM_TRIGGER_TIME, std::function<void(void*)>> m_fundata;
		std::map<int, std::set<int>> m_utcid;
		//std::function<bool(int, pack*, const triggertime_parm&)> m_triggerfun;
	public:
		triggertime();

		ngl::object_map<int32_t, TRIGGER_TIMENODE>& get() { return db()->m_triggertimenode; }
		actor_role* role() { return actor(); }

		// ע�ᴥ���ص�
		void register_fun(int atype, const std::function<void(void*)>& afun);
		TRIGGER_TIMENODE* get(int atriggerid);
		std::function<void(void*)> getfun(int atriggerid);
		bool triggerfun(const timerparm& aparm);
		bool triggertime_start(int atid, void* adata);
	};

}
