#pragma once

#include <boost/array.hpp>
#include <map>
#include <vector>
#include "managecsv.h"
#include "tools_split.h"
#include "net.h"
#include "game_logic.h"
////  aoi ��λ������ 

namespace ngl
{

	class attribute_tools
	{
		static std::vector<double> m_attributevec;
	public:
		static double fight(enum_attribute aindex);
		static int32_t initvalue(enum_attribute aindex);
	};

	template <typename T>
	using attribute_array = std::array<T, attribute_count>;

	template <typename T>
	using module_array = std::array<T, em_attribute_count>;


	struct attribute_value_module
	{
		// ### ���Ծ���ֵ 
		attribute_array<int32_t> m_attribute;
		//std::array<int32_t, attribute_count> m_attribute;
		
		struct ratio_attribute
		{
			// ### ��ֱ�����ֵ
			// ### m_ratio_attribute.first = ����ֵ
			// ### m_ratio_attribute.second.first = ��ֵ
			// ### m_ratio_attribute.second.second = ��ֱ�ֵ
			std::map<int32_t, std::list<std::pair<int32_t, int32_t>>> m_data;
		};
		module_array<ratio_attribute> m_ratio_attribute;
		//std::array<ratio_attribute, em_attribute_count> m_ratio_attribute;
		
		void clear()
		{
			m_attribute = {};
			m_ratio_attribute = {};
		}

		attribute_value_module()
		{}
	};

	class attribute_value
	{
	public:
		attribute_value_module m_value_module;
		std::vector<int32_t> m_proportion;
		// ### �ϲ��������
		std::vector<int32_t> m_fightdata;
		// ### ս��
		int64_t m_fightscore;

		attribute_value() 
			:m_fightscore(0) 
		{
			m_proportion.resize(attribute_count);
			m_fightdata.resize(attribute_count);
		}

		void clear()
		{
			m_fightscore = 0;
			memset(&m_value_module.m_attribute[0], 0x0, sizeof(int32_t) * attribute_count);
			memset(&m_fightdata[0], 0x0, sizeof(int32_t) * attribute_count);
			memset(&m_proportion[0], 0x0, sizeof(int32_t) * attribute_count);
			m_value_module.clear();
		}

		void set(attribute_value_module& avaluemodule)
		{
			clear();
			m_value_module = avaluemodule;
		}
		void update_fight()
		{
			m_fightscore = 0;
			for (int i = 0; i < attribute_count; ++i)
			{
				m_fightscore += m_fightdata[i] * attribute_tools::fight((enum_attribute)(i));
			}
		}

		void update_attribute_fight()
		{
			m_fightscore = 0;
			for (int i = 0; i < attribute_count; ++i)
			{
				m_fightdata[i] = m_value_module.m_attribute[i];
				auto itor = m_value_module.m_ratio_attribute.find(i);
				if (itor == m_value_module.m_ratio_attribute.end())
					continue;
				for (std::pair<int32_t, int32_t>& listitem : itor->second)
				{
					double ltemp = m_value_module.m_attribute[i] * listitem.second / one_attribute_ratio_value;
					if (listitem.first > 0)
						m_proportion[i] += ltemp > listitem.first ? listitem.first : ltemp;
					else
						m_proportion[i] += ltemp;
				}
				m_fightdata[i] += m_proportion[i];
				m_fightscore += m_fightdata[i] * attribute_tools::fight((enum_attribute)(i));
			}
		}

		int64_t fight()								{ return m_fightscore; }
		int32_t base(enum_attribute aenum)			{ return m_value_module.m_attribute[aenum]; }
		int32_t proportion(enum_attribute aenum)	{ return m_proportion[aenum]; }
		int32_t fight_attribute(enum_attribute aenum) { return m_fightdata[aenum]; }

	};

	class actor_role;

	class attribute_module
	{
		boost::array<attribute_value, em_attribute_count> m_moduledata;
	private:
		void remove_attribute(enum_module_attribute amoduleenum)
		{
			if (amoduleenum == em_attribute_all)
				return;
			attribute_value& attribute_all = m_moduledata[em_attribute_all];
			attribute_value& lvalue = m_moduledata[amoduleenum];
			for (int i = 0; i < em_attribute_count; ++i)
			{
				attribute_all.m_fightdata[i] -= lvalue.m_fightdata[i];
			}
		}
		void add_attribute(enum_module_attribute amoduleenum)
		{
			if (amoduleenum == em_attribute_all)
				return;
			attribute_value& attribute_all = m_moduledata[em_attribute_all];
			attribute_value& lvalue = m_moduledata[amoduleenum];
			for (int i = 0; i < em_attribute_count; ++i)
			{
				attribute_all.m_fightdata[i] += lvalue.m_fightdata[i];
			}
		}
		ENUM_UNIT m_type;
		actor_base* m_actor;
	public:
		attribute_module(ENUM_UNIT atype, actor_base* aactor);

		void set_attribute(enum_module_attribute amoduleenum, attribute_value_module& avaluemodule, bool aissync = true);

		void sync_attribute(enum_module_attribute amoduleenum = em_attribute_null);

		attribute_value& get(enum_module_attribute amoduleenum)
		{
			return m_moduledata[amoduleenum];
		}
	};

	void test_attribute();
}
