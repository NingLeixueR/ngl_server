#include "uint_attribute.h"
#include "actor_role.h"

namespace ngl
{
	double attribute_tools::fight(enum_attribute aindex)
	{
		AttributeTab* tab = manage_csv<AttributeTab>::get(aindex);
		return tab == NULL ? 0 : tab->m_fightcoefficient;
	}
	int32_t attribute_tools::initvalue(enum_attribute aindex)
	{
		AttributeTab* tab = manage_csv<AttributeTab>::get(aindex);
		return tab == NULL ? -1 : tab->m_initvalue;
	}

	attribute_module::attribute_module(ENUM_UNIT atype, actor_base* aactor) :
		m_type(atype),
		m_actor(aactor)
	{}

	void attribute_module::sync_attribute(enum_module_attribute amoduleenum /*= em_attribute_null*/)
	{
		LOGIC_ATTRIBUTE_RESPONSE pro;
		if (amoduleenum != em_attribute_null)
		{
			if (amoduleenum != em_attribute_all)
			{
				attribute_value& attribute_all = m_moduledata[em_attribute_all];
				pro.m_attribute[em_attribute_all].m_fight = attribute_all.fight();
				pro.m_attribute[em_attribute_all].m_attribute = attribute_all.m_fightdata;
			}
			pro.m_attribute[amoduleenum].m_fight = m_moduledata[amoduleenum].fight();
			pro.m_attribute[amoduleenum].m_attribute = m_moduledata[amoduleenum].m_fightdata;
		}
		else
		{
			for (int i = 0; i < em_attribute_count; ++i)
			{
				pro.m_attribute[(enum_module_attribute)i].m_fight = m_moduledata[i].fight();
				pro.m_attribute[(enum_module_attribute)i].m_attribute = m_moduledata[i].m_fightdata;
			}
		}
		if(m_type == ROLE_UNIT)
			((actor_role*)m_actor)->send_client(pro);
	}

	void attribute_module::set_attribute(
		enum_module_attribute amoduleenum, attribute_value_module& avaluemodule, bool aissync/* = true*/)
	{
		remove_attribute(amoduleenum);
		attribute_value& lvalue = m_moduledata[amoduleenum];
		int64_t oldfight = lvalue.fight();
		lvalue.set(avaluemodule);
		lvalue.update_attribute_fight();
		int64_t newfight = lvalue.fight();
		if (aissync && newfight != oldfight)
		{
			// ##### ս�������仯
			LOGIC_FIGHT_RESPONSE profight;
			profight.m_fight = newfight;
			profight.m_oldfight = oldfight;
			if (m_type == ROLE_UNIT)
				((actor_role*)m_actor)->send_client(profight);
		}
		add_attribute(amoduleenum);
		if (aissync)
		{
			LOGIC_ATTRIBUTE_RESPONSE pro;
			if (amoduleenum != em_attribute_all)
			{
				attribute_value& attribute_all = m_moduledata[em_attribute_all];
				attribute_all.update_fight();
				pro.m_attribute[em_attribute_all].m_fight = attribute_all.fight();
				pro.m_attribute[em_attribute_all].m_attribute = attribute_all.m_fightdata;
			}
			pro.m_attribute[amoduleenum].m_fight = m_moduledata[amoduleenum].fight();
			pro.m_attribute[amoduleenum].m_attribute = m_moduledata[amoduleenum].m_fightdata;
			if (m_type == ROLE_UNIT)
				((actor_role*)m_actor)->send_client(pro);
		}
	}


	void test_attribute()
	{
		attribute_module lattribute_module(ROLE_UNIT, NULL);
		for (int i = 0; i < em_attribute_count; ++i)
		{
			attribute_value_module lmodule;
			for (int j = 0; j < attribute_count; ++j)
			{
				lmodule.m_attribute[j] = rand() % 100;
				std::list<std::pair<int32_t, int32_t>> ls;
				for (int k = 0; k < attribute_count; ++k)
				{
					int lranknum = rand() % 5;
					for (int f = 0; f < lranknum; ++f)
					{
						ls.push_back(std::make_pair(rand() % 1000, rand() % 10000));
					}
				}
				lmodule.m_ratio_attribute.insert(std::make_pair(j, ls));
			}
			lattribute_module.set_attribute((enum_module_attribute)i, lmodule);
		}

		attribute_value_module lmodule2;
		for (int j = 0; j < attribute_count; ++j)
		{
			lmodule2.m_attribute[j] = rand() % 100;
			std::list<std::pair<int32_t, int32_t>> ls;
			for (int k = 0; k < attribute_count; ++k)
			{
				int lranknum = rand() % 5;
				for (int f = 0; f < lranknum; ++f)
				{
					ls.push_back(std::make_pair(rand() % 1000, rand() % 10000));
				}
			}
			lmodule2.m_ratio_attribute.insert(std::make_pair(j, ls));
		}
		lattribute_module.set_attribute((enum_module_attribute)1, lmodule2);
	}
}