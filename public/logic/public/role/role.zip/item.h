#pragma once

#include "csvtable.h"
#include "manage_csv.h"
#include "game_db.h"
#include <array>

namespace ngl
{

	class create_item
	{
		static std::array<create_item*, EItemTypeCount> m_data;
		virtual bool made(int tid, int count, std::vector<Item>& aitem) = 0;
	protected:
		create_item(EItemType atype) 
		{ 
			m_data[atype] = this; 
		}
	public:
		static bool create(int tid, int count, std::vector<Item>& aitem)
		{
			ItemTab* lptab = allcsv::tab<ItemTab>(tid);
			if (lptab == nullptr)
				return false;
			int lindex = (int)lptab->type;
			return m_data[lindex] != nullptr ? m_data[lindex]->made(tid, count, aitem) : m_data[ENoramlItem]->made(tid, count, aitem);
		}

		static bool create(std::map<int, int>& amap, std::vector<Item>& aitem)
		{
			for (auto [tid, count] : amap)
			{
				if (create(tid, count, aitem) == false)
					return false;
			}
			return true;
		}
	};

	// �ѵ���ʽ
	class item_stack
	{
	public:
		static int stack(int tid, int count, int& aitemcount)
		{
			ItemTab* lptab = allcsv::tab<ItemTab>(tid);
			if (lptab == nullptr)
				return -1;

			if (lptab->stack <= 0)
			{//���޶ѵ�
				aitemcount += count;
				return 0;
			}
			else
			{
				if (aitemcount >= lptab->stack)
				{
					return count;
				}
				else
				{
					int lcount = lptab->stack - aitemcount;
					if (count >= lcount)
					{
						aitemcount = lptab->stack;
						return count - lcount;
					}
					else
					{
						aitemcount += count;
						return 0;
					}
				}
			}
		}
		// ���ܶѵ�
		static int stack(int tid, int count, Item& aitem)
		{
			return stack(tid, count, aitem.mm_count());
		}

		// �Ƿ������ѵ�
		static bool is_stack(int tid)
		{
			ItemTab* lptab = allcsv::tab<ItemTab>(tid);
			if (lptab == nullptr)
				return false;
			return lptab->stack != 1;
		}

		static bool isstack(int tid)
		{
			ItemTab* lptab = allcsv::tab<ItemTab>(tid);
			if (lptab == nullptr)
				return false;
			if (lptab->stack <= 0)
			{//���޶ѵ�
				return true;
			}
			else
			{
				if (lptab->stack > 1)
				{// ���Զѵ�[lptab->stack]
					return true;
				}
			}
			return false;
		}


	};

	class item_noraml : public create_item
	{
		item_noraml() :
			create_item(ENoramlItem)
		{}
	public:
		static item_noraml& getInstance()
		{
			static item_noraml ltemp;
			return ltemp;
		}

		virtual bool made(int tid, int count, std::vector<Item>& aitem)
		{
			int lcount = count;
			while (lcount > 0)
			{
				Item lItem;
				lItem.mm_id() = -1;
				lItem.mm_tid() = tid;
				lItem.mm_count() = 0;
				lcount = item_stack::stack(tid, lcount, lItem);
				aitem.push_back(lItem);
			}
			return true;
		}
	};

}
