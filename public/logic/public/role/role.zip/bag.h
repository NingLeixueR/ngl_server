#pragma once

#include "csvtable.h"
#include "game_db.h"
#include "nlog.h"
#include "db_modular.h"
#include "manage_csv.h"
#include "delay_function.h"

#include <vector>

namespace ngl
{
	class item_change
	{
		// �����仯��Item
		std::map<int, Item> m_changeitem;
		std::list<int>		m_delitem;
	public:
		void change(Item& aitem)
		{
			m_changeitem[aitem.mm_id()] = aitem;
		}

		void remove(int aid)
		{
			m_changeitem.erase(aid);
			m_delitem.push_back(aid);
		}

		const std::map<int, Item>& change_map()
		{
			return m_changeitem;
		}

		const std::list<int>& remove_list()
		{
			return m_delitem;
		}

		void clear()
		{
			m_changeitem.clear();
			m_delitem.clear();
		}
	};


	class actor_role;
	class bag : public db_modular<ENUM_DB_BAG, DB_BAG, actor_role>
	{
		std::vector<Item*> m_itemindex;
		std::map<int, std::vector<Item*>> m_itemtid;		// key tid value item
		int m_maxitemid;

		item_change		m_ichange;
		EItemSrc		m_src;
		EItemConsume	m_consume;
	public:
		bag() :
			db_modular<ENUM_DB_BAG, DB_BAG, actor_role>()
			, m_maxitemid(0)
		{
		}

		virtual void init_data()
		{
			int lmaxindex = db()->const_mm_maxitemindex();
			m_itemindex.resize(lmaxindex);
			std::map<int32_t, Item>& lmap = db()->mm_data();
			for (auto& [id, data] : lmap)
			{
				ItemTab* lptab = allcsv::tab<ItemTab>(data.const_mm_tid());
				if (lptab == nullptr)
				{
					LogLocalError("bag::init_data roleid[%] ItemTab tid[%]", actorbase()->id_guid(), data.const_mm_tid());
					continue;
				}
				if (m_itemindex.size() <= data.const_mm_index())
				{
					LogLocalError("bag::init_data roleid[%] lmaxindex[%] <= index[%]", actorbase()->id_guid(), lmaxindex, data.const_mm_index());
					continue;
				}
				m_itemindex[data.const_mm_index()] = &data;
				m_itemtid[data.const_mm_tid()].push_back(&data);
				if (m_maxitemid < id)
					m_maxitemid = id;
			}
		}

		// ��ȡ����λ��
		int freeindex()
		{
			for (int i = 0; i < db()->const_mm_maxitemindex(); ++i)
			{
				if (m_itemindex[i] == nullptr)
					return i;
			}
			return -1;
		}

		// ��ȡָ�������Ŀ���λ��
		bool freeindex(int acount, std::vector<int>& avec)
		{
			if (acount <= 0)
				return false;
			std::vector<int> lvec;
			for (int i = 0; i < db()->const_mm_maxitemindex(); ++i)
			{
				if (m_itemindex[i] == nullptr)
				{
					lvec.push_back(i);
					if (lvec.size() >= acount)
						return true;
				}
			}
			return false;
		}

		// ��ȡ�ѵ�����(�жѵ�������)
		int stackcount(int tid, int acount)
		{
			ItemTab* lptab = allcsv::tab<ItemTab>(tid);
			if (lptab == nullptr)
				return -1;
			if (lptab->stack <= 0)
				return -1;
			int lstackcount = 0;
			while (acount > 0)
			{
				acount -= lptab->stack;
				++lstackcount;
			}
			return lstackcount;
		}


		// ����ָ��λ�û�ȡ��Ʒ
		Item* getitembyindex(int aindex)
		{
			if (aindex < 0 || aindex >= db()->const_mm_maxitemindex())
				return nullptr;
			if(m_itemindex[aindex] == nullptr)
				return nullptr;
			return m_itemindex[aindex];
		}
		// ��չ����
		void extend(int aadd) 
		{ 
			db()->mm_maxitemindex() += aadd;
			m_itemindex.resize(m_itemindex.size()+aadd);
		}

		// �ɶѵ���Ʒ ���ȶѵ�
		int stack_item(int atid, int acout, bool abool);

		void delayfun()
		{
			auto& lmap = m_ichange.change_map();
			auto& llist = m_ichange.remove_list();

			LogLocalInfo("bag::delayfun m_src[%]m_consume[%] change_map[%] remove_list[%]", m_src, m_consume, lmap, llist);
			// sync to client

			m_ichange.clear();
		}

		// ������Ʒ��Դ
		delay_function::tdelay set_itemsrc(EItemSrc asrc, EItemConsume aconsume)
		{
			m_src = asrc;
			m_consume = aconsume;
			return delay_function::fun([this]() 
				{
					delayfun();
					clear_itemsrc();
				});
		}

		void clear_itemsrc()
		{
			m_src = EItemSrcNoraml;
			m_consume = EItemConsumeNoraml;
		}

	private:
		bool private_additem(int tid, int count);
		Item* copyitem(Item& aitem, int aindex);
	public:
		void bagfull(std::vector<Item>& aitem);
		bool additem(int tid, int count);
		bool additem(std::map<int, int>& amap);
		bool additem(Item& aitem);
		bool additem(std::vector<Item>& aitem);

		bool removeitem(Item* aitem);
		bool delitem(int aid, int count);
		bool delitembytid(int tid, int count);
		bool delitembyindex(int aindex, int count);

		bool check(int aid, int count);
		bool checkbytid(int tid, int count);
		bool checkbyindex(int aindex, int count);
	};

}

