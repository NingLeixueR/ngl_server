#include "drop.h"
#include "bag.h"
#include "actor_role.h"
#include "tDropTab.h"

namespace ngl
{
	bool drop::probability(int aid, std::map<int, int>& amap)
	{
		tDrop* tab = tDropTab::tab(aid);
		if (tab == nullptr)
			return false;
		// ��ֱȸ���
		int lcount = tab->m_tab->m_probabilitynum;
		std::set<int> lset;
		for (int i = 0; i < lcount; ++i)
		{
			for (int j = 0; j < tab->m_dataprobability.size(); ++j)
			{
				if (lset.find(j) != lset.end())
					continue;
				int lprobabilityval = std::rand() % 10000;
				if (lprobabilityval < tab->m_dataprobability[j].probability)
				{
					tDropProbability& ltemp = tab->m_dataprobability[j];
					int lnum = ltemp.max - ltemp.min;
					if (lnum < 0)
					{
						LogLocalError("drop::probability[%] ltemp.max - ltemp.min = [%]", aid, ltemp.max - ltemp.min);
						return false;
					}
					else if (lnum == 0)
					{
						lnum = ltemp.min;
					}
					else
					{
						lnum = ltemp.min + (std::rand() % lnum);
					}

					if (ltemp.itemid < 0)
						probability(-ltemp.itemid, amap);
					else
						amap[ltemp.itemid] += lnum;
					lset.insert(j);
				}
			}
		}
		return true;
	}

	bool drop::weight(int aid, std::map<int, int>& amap)
	{
		tDrop* tab = tDropTab::tab(aid);
		if (tab == nullptr)
			return false;
		int lweight = 0;
		for (int i = 0; i < tab->m_dataweight.size(); ++i)
			lweight += tab->m_dataweight[i].weight;

		int lcount = tab->m_tab->m_weightnum;
		std::set<int> lset;
		for (int i = 0; i < lcount; ++i)
		{
			for (int j = 0; j < tab->m_dataweight.size(); ++j)
			{
				if (lset.find(j) != lset.end())
					continue;
				int lweightval = std::rand() % lweight;
				if (lweightval < tab->m_dataweight[j].weight)
				{
					tDropProbability& ltemp = tab->m_dataprobability[j];
					int lnum = ltemp.max - ltemp.min;
					if (lnum < 0)
					{
						LogLocalError("drop::weight[%] ltemp.max - ltemp.min = [%]", aid, ltemp.max - ltemp.min);
						return false;
					}
					else if (lnum == 0)
					{
						lnum = ltemp.min;
					}
					else
					{
						lnum = ltemp.min + (std::rand() % lnum);
					}

					if (ltemp.itemid < 0)
						weight(-ltemp.itemid, amap);
					else
						amap[ltemp.itemid] += lnum;
					lset.insert(j);
				}
			}
		}
		return true;
	}


	bool drop::droplist(int aid, int acount, std::map<int, int>& amap)
	{
		for (int i = 0; i < acount; ++i)
			probability(aid, amap);
		for (int i = 0; i < acount; ++i)
			weight(aid, amap);
		return true;
	}

	bool drop::use(actor_role* arole, int aid, int acount, EItemSrc src)
	{
		std::map<int, int> lmap;
		delay_fun ldelay = arole->m_bag.set_itemsrc(src, EItemConsumeNoraml);
		return droplist(aid, acount, lmap) && arole->m_bag.additem(lmap)? true : false;
	}


}