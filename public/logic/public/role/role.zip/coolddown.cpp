#include "coolddown.h"
#include "manage_csv.h"

namespace ngl
{
	coolddown::coolddown() :
		db_modular<ENUM_DB_COOLDDOWN, DB_COOLDDOWN, actor_role>()
	{
		
	}
	void coolddown::init_data()
	{
	}
	
	COOLDDOWN* coolddown::get(int acooldownid)
	{
		auto itor = db()->const_mm_coolddown().find(acooldownid);
		if (itor == db()->const_mm_coolddown().end())
			return nullptr;
		return &db()->mm_coolddown()[acooldownid];
	}

	COOLDDOWN* coolddown::create(int acooldownid)
	{
		return &db()->mm_coolddown()[acooldownid];
	}

	// �����ȴ���� 
	// true ����ȴ false��ȴ��
	bool coolddown::check(COOLDDOWN* lcool)
	{
		if (lcool == nullptr)
			return true;
		time_t lnow = localtime::gettimems();
		if (lnow < lcool->const_mm_releaseinterval_endms())
			return false;
		if (lcool->const_mm_chargingcount() <= 0)
		{
			if (lcool->const_mm_charginginterval_endms() != 0 && lnow > lcool->const_mm_charginginterval_endms())
			{
				CooldDownTab* ltab = tab(lcool->const_mm_coolddownid());
				if (ltab == nullptr)
					return false;
				int32_t linterval = lnow - lcool->const_mm_charginginterval_endms();
				int32_t lcount = linterval / ltab->m_charginginterval;
				if (lcount >= (ltab->m_chargingcount - lcool->const_mm_chargingcount()))
				{
					lcool->mm_chargingcount() = ltab->m_chargingcount;
				}
				else
				{
					lcool->mm_chargingcount() += lcount;
				}
				lcool->mm_charginginterval_endms() = 0;
				return true;
			}
			else
				return false;
		}
		return true;
	}
	bool coolddown::check(int acooldownid)
	{
		return check(get(acooldownid));
	}

	CooldDownTab* coolddown::tab(int aid)
	{
		return allcsv::tab<CooldDownTab>(aid);
	}

	bool coolddown::set_coolddown(int acooldownid)
	{
		CooldDownTab* ltab = tab(acooldownid);
		if (ltab == nullptr)
			return false;
		COOLDDOWN* lcool = create(acooldownid);
		if (check(lcool) == false)
			return false;
		lcool->mm_coolddownid() = acooldownid;
		lcool->mm_releaseinterval_endms() = localtime::gettimems() + ltab->m_releaseinterval;
		lcool->mm_charginginterval_endms() = localtime::gettimems() + ltab->m_charginginterval;
		--lcool->mm_chargingcount();
		return true;
	}
}