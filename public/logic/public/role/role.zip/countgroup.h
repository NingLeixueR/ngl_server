#pragma once

#include "db_modular.h"
#include "manage_csv.h"
#include "tCountGroupTab.h"

namespace ngl
{
	class actor_role;
	
	class countgroup : public db_modular<ENUM_DB_COUNTGROUP, DB_COUNTGROUP, actor_role>
	{
	public:
		countgroup() 
			:db_modular<ENUM_DB_COUNTGROUP, DB_COUNTGROUP, actor_role>() {}

		virtual void init_data() {}

		void init_fun() {}

		actor_role* role() { return actor(); }

		int32_t gettimenode(int32_t acountgroupid)
		{
			tCountGroup* tab = tCountGroupTab::tab(acountgroupid);
			if (tab == nullptr)
				return -1;
			return tab->m_tab->m_triggertimeid;
		}

		// ��ȡ������ û��������
		const COUNTGROUP* get_countgroup(int acountgroupid);

		// ��������
		bool check(int acountgroupid, int acount, bool aconsume = true);

		// ʹ�ô�����
		bool use(int acountgroupid, int acount, bool aconsume = true);

		void reset(int acountgroupid);

		void reset();
	};

}

