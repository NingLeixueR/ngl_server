#pragma once

#include <vector>
#include <map>
#include <string>

#include "actor_role.h"
#include "manage_csv.h"
#include "nlog.h"
#include "tools.h"

namespace ngl
{
	class consume
	{
	public:
		static bool check(actor_role* arole, int aid, int acount);
		static bool use(actor_role* arole, int aid, int acount, EItemConsume src);
	};

}
