#pragma once

#include "db_modular.h"

namespace ngl
{
	class actor_role;
	class coolddown : public db_modular<ENUM_DB_COOLDDOWN, DB_COOLDDOWN, actor_role>
	{
	public:
		coolddown();

		virtual void init_data();
		COOLDDOWN* get(int acooldownid);
		COOLDDOWN* create(int acooldownid);
		// �����ȴ���� 
		// true ����ȴ false��ȴ��
		bool check(COOLDDOWN* lcool);
		bool check(int acooldownid);
		static CooldDownTab* tab(int aid);
		bool set_coolddown(int acooldownid);
	};

}


