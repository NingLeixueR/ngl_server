#include "consume.h"
#include "bag.h"
#include "tConsumeTab.h"

namespace ngl
{
	bool consume::check(actor_role* arole, int aid, int acount)
	{
		tConsume* lptab = tConsumeTab::tab(aid);
		if (lptab == nullptr)
			return false;
		//tab->m_data;
		for (auto& item : lptab->m_data)
		{
			if (!arole->m_bag.checkbytid(item.first, item.second* acount))
			{
				return false;
			}
		}
		return true;		
	}
	bool consume::use(actor_role* arole, int aid, int acount, EItemConsume src)
	{
		if (!check(arole, aid, acount))
			return false;
		tConsume* tab = tConsumeTab::tab(aid);
		if (tab == nullptr)
			return false;
		arole->m_bag.set_itemsrc(EItemSrcNoraml, src);
		for (auto& item : tab->m_data)
		{
			if (!arole->m_bag.delitembytid(item.first, item.second* acount))
			{
				return false;
			}
		}
		return true;
	}
}
