#pragma once 


#include "game_db.h"
#include "actor_protocol.h"
#include "db_modular.h"

namespace ngl
{
	enum EDB_KEYVALUE
	{
		EDB_KV_ID,
	};

	template <typename TACTOR>
	class key_value : public db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>
	{
	public:
		key_value(TACTOR* aactor, EDB_KEYVALUE aenum) 
			:db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>(aactor, aenum)
		{}

		virtual void init_data()
		{
			const std::map<actor_guid, DB_KEYVALUE>& lmap = db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>::data();
			for (auto& [key, value] : lmap)
			{
				LogLocalError("key_value key[%] value[%]", key, value.m_data.get());
			}
		}

		bool value(int64_t akey, std::string& avalues)
		{
			DB_KEYVALUE* lfind = db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>::find(akey);
			if (lfind == nullptr)
				return false;
			avalues = lfind->const_mm_data();
			return true;
		}

		template <typename T>
		bool value(int64_t akey, T& avalues)
		{
			DB_KEYVALUE* lfind = db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>::find(akey);
			if (lfind == nullptr)
				return false;

			avalues = boost::lexical_cast<T>(lfind->const_mm_data());
			return true;
		}

		template <typename T>
		void set(int64_t akey, const T& avalues)
		{
			T* lpdata = db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>::get(akey);
			lpdata->m_id = akey;
			lpdata->m_data = boost::lexical_cast<std::string>(avalues);
		}

	};


}
