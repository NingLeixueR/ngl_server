#include "countgroup.h"
#include "consume.h"
#include "actor_role.h"

namespace ngl
{
	const COUNTGROUP* countgroup::get_countgroup(int acountgroupid)
	{
		const COUNTGROUP* lret = tools::findmap(db()->const_mm_countgroup(), acountgroupid);
		if (lret != nullptr)
			return lret;
		COUNTGROUP& lCOUNTGROUP = db()->mm_countgroup()[acountgroupid];
		lCOUNTGROUP.mm_count() = 0;
		lCOUNTGROUP.mm_countgroupid() = acountgroupid;
		return &lCOUNTGROUP;
	}


	bool countgroup::check(int acountgroupid, int acount, bool aconsume)
	{
		tCountGroup* tab = tCountGroupTab::tab(acountgroupid);
		if (tab == nullptr)
			return false;
		int lsumcount = tab->m_tab->m_usecount + (aconsume ? tab->m_consumeid.size() : 0);
		const COUNTGROUP* lcountgroup = get_countgroup(acountgroupid);
		Assert(lcountgroup != nullptr);
		return lsumcount > lcountgroup->const_mm_count() + acount;
	}

	bool countgroup::use(int acountgroupid, int acount, bool aconsume)
	{
		if (!check(acountgroupid, acount, aconsume))
			return false;
		tCountGroup* tab = tCountGroupTab::tab(acountgroupid);
		if (tab == nullptr)
			return false;
		const COUNTGROUP* lcountgroup = get_countgroup(acountgroupid);
		Assert(lcountgroup != nullptr);
		int lbuycount = lcountgroup->const_mm_count() - tab->m_tab->m_usecount;
		if (lbuycount + acount > tab->m_consumeid.size())
			return false;
		if (lbuycount >= 0)
		{
			// ������Ʒ��ȡ����
			if (consume::use(actor(), lbuycount, acount, EItemConsumeNoraml))
				return false;
		}
		db()->mm_countgroup()[acountgroupid].mm_count() += acount;
		return true;
	}

	void countgroup::reset(int acountgroupid)
	{
		LOGIC_COUNTGROUP_SYNC pro;
		COUNTGROUP ltemp;
		ltemp.mm_count() = 0;
		ltemp.mm_countgroupid() = acountgroupid;
		pro.m_countgroup.push_back(ltemp);
		((actor_role*)m_actor)->send_client(pro);

		db()->mm_countgroup().erase(acountgroupid);
	}

	void countgroup::reset()
	{
		LOGIC_COUNTGROUP_SYNC pro;
		std::map<int32_t, COUNTGROUP>& lmap = db()->mm_countgroup();
		COUNTGROUP ltemp;
		for (auto& item : lmap)
		{
			ltemp.mm_count() = 0;
			ltemp.mm_countgroupid() = item.second.const_mm_countgroupid();
			pro.m_countgroup.push_back(ltemp);
		}
		((actor_role*)m_actor)->send_client(pro);
		lmap.clear();
	}

}