#pragma once

#include <memory>
#include <functional>

namespace ngl
{

	struct delay_null
	{};
	class delay_function
	{
	public:
		using tfun = std::function<void()>;
		using tdelay = std::shared_ptr<delay_null>;
		static tdelay fun(const tfun& afun)
		{
			tdelay lfun(nullptr, [afun](delay_null*) {afun(); });
			return lfun;
		}
	};

	using delay_fun = delay_function::tdelay;
}