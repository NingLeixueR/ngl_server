#include "bag.h"
#include "mail.h"
#include "item.h"
#include "actor_role.h"

namespace ngl
{
	int bag::stack_item(int atid, int acout, bool abool)
	{
		int lcount = acout;
		auto itor = m_itemtid.find(atid);
		if (itor == m_itemtid.end())
			return lcount;
		std::vector<Item*>& lvec = itor->second;
		for (int i = 0; i < lvec.size(); ++i)
		{
			int lret = 0;
			if (abool)
			{
				int ltemp = lvec[i]->const_mm_count();
				lret = item_stack::stack(atid, lcount, ltemp);
			}
			else
			{
				lret = item_stack::stack(atid, lcount, *lvec[i]);
			}
			if (lret >= 0)
				lcount = lret;
			if (lcount <= 0)
				return 0;
		}
		return lcount;
	}

	Item* bag::copyitem(Item& aitem, int aindex)
	{
		std::map<int32_t, Item>& lmap = db()->mm_data();
		aitem.mm_id() = ++m_maxitemid;
		auto pairitor = lmap.insert(std::make_pair(aitem.const_mm_id(), aitem));
		if (pairitor.second == false)
			return nullptr;
		Item& lItem = pairitor.first->second;
		lItem.mm_index() = aindex;
		m_itemindex[aindex] = &lItem;
		m_itemtid[lItem.const_mm_tid()].push_back(&lItem);
		return &lItem;
	}

	bool bag::additem(Item& aitem)
	{
		std::vector<int> lvindex;
		if (freeindex(1, lvindex) == false)
			return false;
		if (lvindex.empty())
			return false;
		Item* lpItem = copyitem(aitem, lvindex[0]);
		if (lpItem != nullptr)
			m_ichange.change(*lpItem);
		return lpItem != nullptr;
	}

	bool bag::private_additem(int tid, int count)
	{
		ItemTab* lptab = allcsv::tab<ItemTab>(tid);
		if (lptab == nullptr)
			return false;

		const std::map<int32_t, Item>& lmap = db()->const_mm_data();
		if (lptab->stack == 1)
		{
			// �������ѵ� ������Ʒ
			std::vector<int> lvindex;
			if (freeindex(count, lvindex) == false)
				return false;

			std::vector<Item> lvitem;
			if (!create_item::create(tid, count, lvitem))
				return false;

			if (lvitem.size() != lvindex.size())
				return false;

			for (int i = 0; i < count; ++i)
			{
				Item* lpItem = copyitem(lvitem[i], lvindex[i]);
				m_ichange.change(*lpItem);
			}

			return true;
		}
		else if (lptab->stack <= 0)
		{
			// ���޶ѵ�
			auto itor = m_itemtid.find(tid);
			if (itor == m_itemtid.end())
			{
				std::vector<Item> lvitem;
				if (!create_item::create(tid, 1, lvitem))
					return false;
				if (lvitem.empty())
					return false;
				additem(lvitem[0]);
				return true;
			}
			itor->second[0]->mm_count() += count;
			m_ichange.change(*itor->second[0]);
			return true;
		}
		else
		{
			// �ѵ�����������
			int lcount = stack_item(tid, count, false);
			bool lbool = lcount < count;
			if (lcount > 0)
			{
				int lstack = stackcount(tid, lcount);
				std::vector<int> lvindex;
				if (freeindex(lstack, lvindex) == false)
					return false;

				std::vector<Item> lvitem;
				if (!create_item::create(tid, lcount, lvitem))
					return false;
				if (lvindex.size() < lvitem.size())
					return false;

				for (int i = 0; i < lvitem.size() && i < lvindex.size();++i )
				{
					copyitem(lvitem[i], lvindex[i]);
				}
			}
			if (lbool)
			{
				stack_item(tid, count, true);
			}
			for (auto& item : m_itemtid[tid])
			{
				m_ichange.change(*item);
			}
			return true;
		}
	}
	
	void bag::bagfull(std::vector<Item>& aitem)
	{
		DB_MAIL lmail;
		lmail.mm_tid() = bag_full;
		
		MAIL_HOLDER lholder;
		lholder.mm_draw() = false;
		lholder.mm_read() = false;
		lholder.mm_holder() = actor()->id_guid();
		lmail.mm_mailholder().insert(std::make_pair(lholder.const_mm_holder(), lholder));
		actor()->send_mail(lmail);
	}

	bool bag::additem(int tid, int count)
	{
		if (private_additem(tid, count) == false)
		{
			std::vector<Item> lvec;
			if (!create_item::create(tid, count, lvec))
				return false;
			bagfull(lvec);
		}
		return true;
	}

	bool bag::additem(std::map<int, int>& amap)
	{
		std::vector<Item> lvec;
		bool lbool = false;
		for (auto [key, value] : amap)
		{
			if (lbool || private_additem(key, value) == false)
			{
				lbool = true;
				if (!create_item::create(key, value, lvec))
					return false;
			}
		}
		bagfull(lvec);
		return true;
	}

	bool bag::additem(std::vector<Item>& aitem)
	{
		std::map<int, int> lmap;
		int lcount = 0;
		for (Item& item : aitem)
		{
			if (item_stack::is_stack(item.const_mm_tid()))
			{
				lmap[item.const_mm_tid()] += item.const_mm_count();
			}
			else
			{
				if (item.const_mm_count() != 1)
					return false;
				++lcount;
			}
		}

		for (auto [tid, count] : lmap)
		{
			auto itor = m_itemtid.find(tid);
			for (Item* item : itor->second)
			{
				int ltemp = item->const_mm_count();
				count = item_stack::stack(tid, count, ltemp);
				if (count <= 0)
				{
					break;
				}
			}
			while (count > 0)
			{
				int ltemp = 0;
				count = item_stack::stack(tid, count, ltemp);
				++lcount;
			}
		}

		std::vector<int> lvindex;
		if (freeindex(lcount, lvindex) == false)
			return false;

		for (auto [tid, count] : lmap)
		{
			auto itor = m_itemtid.find(tid);
			for (Item* item : itor->second)
			{
				count = item_stack::stack(tid, count, item->mm_count());
				if (count <= 0)
					break;
			}
			while (count > 0)
			{
				int ltemp = 0;
				count = item_stack::stack(tid, count, ltemp);
				++lcount;
			}
		}

		return true;

	}

	bool bag::removeitem(Item* aitem)
	{
		m_ichange.remove(aitem->const_mm_id());
		m_itemindex[aitem->const_mm_index()] = nullptr;
		auto itor = m_itemtid.find(aitem->const_mm_tid());
		std::vector<Item*> lvec;
		lvec.swap(itor->second);
		for (int i = 0; i < lvec.size(); ++i)
		{
			if (lvec[i] != aitem)
			{
				itor->second.push_back(lvec[i]);
			}
		}
		db()->mm_data().erase(aitem->const_mm_id());
		return true;
	}

	bool bag::delitem(int aid, int count)
	{
		const std::map<int32_t, Item>& lmap = db()->const_mm_data();
		auto itor = lmap.find(aid);
		if (itor == lmap.end())
		{
			LogLocalError("bag::delitem(%,%) data().find(%) == end()", aid, count, aid);
			return false;
		}
		if (itor->second.const_mm_count() < count)
			return false;
		db()->mm_data()[aid].mm_count() -= count;
		if (itor->second.const_mm_count() <= 0)
		{
			removeitem(&db()->mm_data()[aid]);
		}
		return true;
	}

	bool bag::delitembytid(int tid, int count)
	{
		auto itor = m_itemtid.find(tid);
		if (itor == m_itemtid.end())
			return false;
		for (int i = itor->second.size() - 1; i > 0; --i)
		{
			if (count >= itor->second[i]->const_mm_count())
			{
				count -= itor->second[i]->const_mm_count();
				removeitem(itor->second[i]);
			}
			else
			{
				itor->second[i]->mm_count() -= count;
				m_ichange.change(*itor->second[i]);
				break;
			}
		}
		return count <= 0;
	}

	bool bag::delitembyindex(int aindex, int count)
	{
		int& lcount = m_itemindex[aindex]->mm_count();
		if (lcount < count)
		{
			LogLocalError("bag::delitembyindex index[%] nowcount[%] < count[%]", aindex, lcount, count);
			return false;
		}
		lcount -= count;
		if (lcount <= 0)
		{
			removeitem(m_itemindex[aindex]);
		}
		return true;
	}

	bool bag::check(int aid, int count)
	{
		const std::map<int32_t, Item>& lmap = db()->const_mm_data();
		auto itor = lmap.find(aid);
		if (itor == lmap.end())
			return false;
		return itor->second.const_mm_count() >= count;
	}

	bool bag::checkbytid(int tid, int count)
	{
		auto itor = m_itemtid.find(tid);
		if (itor == m_itemtid.end())
			return false;
		for (Item* item : itor->second)
		{
			if (count > item->const_mm_count())
			{
				count -= item->const_mm_count();
			}
			else
			{
				return true;
			}
		}
		return count > 0;
	}

	bool bag::checkbyindex(int aindex, int count)
	{
		if (aindex >= m_itemindex.size())
			return false;
		Item* lItem = m_itemindex[aindex];
		return lItem->const_mm_count() >= count;
	}


}