#pragma once

#include "game_db.h"
#include "nlog.h"
#include "db_modular.h"
#include "manage_csv.h"
//#include "delay_function.h"
#include "Template.pb.h"
#include "tab_proto.h"

#include <vector>
#include <map>

namespace ngl
{
	class item_change
	{
		// �����仯��Item
		std::map<int, Item> m_changeitem;
		std::list<int>		m_delitem;
	public:
		void change(Item& aitem)
		{
			m_changeitem[aitem.mm_id()] = aitem;
		}

		void remove(int aid)
		{
			m_changeitem.erase(aid);
			m_delitem.push_back(aid);
		}

		const std::map<int, Item>& change_map()
		{
			return m_changeitem;
		}

		const std::list<int>& remove_list()
		{
			return m_delitem;
		}

		void clear()
		{
			m_changeitem.clear();
			m_delitem.clear();
		}
	};


	class actor_role;
	class bag : public db_modular<ENUM_DB_BAG, DB_BAG, actor_role>
	{
		std::map<int, Item*> m_itemtid;		// key tid value item
		int m_maxitemid;

		item_change		m_ichange;
		EItemSrc		m_src;
		EItemConsume	m_consume;

		std::map<int, Template::Item>& table;
		
	public:
		bag() :
			db_modular<ENUM_DB_BAG, DB_BAG, actor_role>()
			, m_maxitemid(0)
			, table(ngl::tab_proto<Template::Item>::table)
		{
		}

		virtual void init_data()
		{
			int lmaxindex = db()->const_mm_maxitemindex();
			std::map<int32_t, Item>& lmap = db()->mm_data();
			for (auto& [id, data] : lmap)
			{
				auto itor = table.find(data.const_mm_tid());
				if (itor == table.end())
				{
					LogLocalError("bag::init_data roleid[%] ItemTab tid[%]", actorbase()->id_guid(), data.const_mm_tid());
					continue;
				}
				m_itemtid[data.const_mm_tid()].push_back(&data);
				if (m_maxitemid < id)
					m_maxitemid = id;
			}
		}

		void delayfun()
		{
			auto& lmap = m_ichange.change_map();
			auto& llist = m_ichange.remove_list();

			LogLocalInfo("bag::delayfun m_src[%]m_consume[%] change_map[%] remove_list[%]", m_src, m_consume, lmap, llist);
			// sync to client

			m_ichange.clear();
		}

		// ������Ʒ��Դ
		delay_function::tdelay set_itemsrc(EItemSrc asrc, EItemConsume aconsume)
		{
			m_src = asrc;
			m_consume = aconsume;
			return delay_function::fun([this]() 
				{
					delayfun();
					clear_itemsrc();
				});
		}

		void clear_itemsrc()
		{
			m_src = EItemSrcNoraml;
			m_consume = EItemConsumeNoraml;
		}

	private:
		bool private_additem(int tid, int count);
		Item* copyitem(Item& aitem, int aindex);
	public:
		void bagfull(std::vector<Item>& aitem);
		bool additem(int tid, int count);
		bool additem(std::map<int, int>& amap);
		bool additem(Item& aitem);
		bool additem(std::vector<Item>& aitem);

		bool removeitem(Item* aitem);
		bool delitem(int aid, int count);
		bool delitembytid(int tid, int count);
		bool delitembyindex(int aindex, int count);

		bool check(int aid, int count);
		bool checkbytid(int tid, int count);
		bool checkbyindex(int aindex, int count);
	};

}

