#pragma once

#include "db_modular.h"

namespace ngl
{
	class actor_notice;
	/*class notice : public db_modular<ENUM_DB_NOTICE, DB_NOTICE, actor_notice>
	{
	public:
		notice() :
			db_modular<ENUM_DB_NOTICE, DB_NOTICE, actor_notice>()
		{
		}

		virtual void set_id()
		{
			m_id = -1;
		}

		virtual void init_data()
		{
			LogLocalError("actor_notice###loaddb_finish");
			i32_actordataid ltemp = 0;
			for (auto&& [id, dbnotice] : data())
			{
				std::string lstart = localtime::time2msstr(dbnotice.const_mm_starttime(), "%y-%m-%d %H:%M:%S");
				std::string lfinish = localtime::time2msstr(dbnotice.const_mm_finishtime(), "%y-%m-%d %H:%M:%S");
				LogLocalError("notice###id:[%] notice:[%] time[%-%]", id, dbnotice.const_mm_notice(), lstart, lfinish);
			}
		}

	};*/
}