#include "mail.h"
#include "actor_mail.h"

//namespace ngl
//{
//	void mail::rollback_drawmail(int64_t aroleid, int amailid)
//	{
//		DB_MAIL* lmail = get_mail(amailid);
//		if (lmail == nullptr)
//			return;
//		MAIL_HOLDER* lpholder = get_mailholder(lmail, aroleid);
//		if (lpholder == nullptr)
//			return;
//		change_holderdraw(lpholder, false);
//	}
//
//	// ��ȡ�����ʼ�
//	bool mail::drawmail(int64_t aid, int64_t aroleid)
//	{
//		//std::shared_ptr<actor_send_item> pro(new actor_send_item());
//		//bool ldraw = drawmail(aid, aroleid, pro->m_item);
//		//if (ldraw == false)
//		//	return false;
//		//
//		//actor()->send_actor(aroleid, pro/*, [this, aid, aroleid]()
//		//	{
//		//		rollback_drawmail(aroleid, aid);
//		//	}*/);
//
//		return true;
//	}
//	bool mail::drawmail(int64_t aroleid)
//	{
//		//std::shared_ptr<actor_send_item> pro(new actor_send_item());
//		//auto itor = m_idrolebymail.find(aroleid);
//		//if (itor == m_idrolebymail.end())
//		//	return false;
//		//std::vector<int> lvecmail;
//		//for (int64_t mailid : itor->second)
//		//{
//		//	if (drawmail(mailid, aroleid, pro->m_item))
//		//	{
//		//		lvecmail.push_back(mailid);
//		//	}
//		//}
//		//actor()->send_actor(aroleid, pro/*, [this, lvecmail, aroleid]()
//		//	{
//		//		for (int mailid : lvecmail)
//		//		{
//		//			rollback_drawmail(aroleid, mailid);
//		//		}
//		//	}*/);
//
//		return true;
//	}
//
//	void mail::getmailbyrole(int64_t aroleid, std::vector<DB_MAIL>& avec)
//	{
//		auto itor = m_idrolebymail.find(aroleid);
//		if (itor == m_idrolebymail.end())
//			return;
//		for (int64_t mailid : itor->second)
//		{
//			DB_MAIL* lpmail = get_mail(mailid);
//			if (lpmail != nullptr)
//			{
//				avec.push_back(*lpmail);
//			}
//		}
//	}
//}