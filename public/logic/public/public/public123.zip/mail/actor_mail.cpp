#include "actor_mail.h"


namespace ngl
{
	void actor_mail::actor_register()
	{
		// Э��ע��
		/*register_actor<EPROTOCOL_TYPE_CUSTOM, actor_mail>(
			true, 
			null<actor_gmother<actor_add_role_mail>>::get(),
			null<actor_gmother<actor_get_role_mail>>::get()
			);*/
	}

}