#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
//#include "actor_protocol_gm.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"

#include "db_modular.h"
#include "mail.h"
//#include "item.h"

namespace ngl
{
	//class actor_mail : public actor<actor_mail>
	//{
	//	mail m_mail;

	//	actor_mail() :
	//		actor<actor_mail>(
	//			actorparm
	//			{
	//				.m_parm{.m_type = ACTOR_MAIL, .m_manage_dbclient = true},
	//				.m_weight = 0x7fffffff,
	//				.m_broadcast = true,
	//			})
	//		//actor<actor_mail>(ACTOR_MAIL, actor_guid::none_area(), actor_guid::none_actordataid(), 0x7fffffff, true, true, true)
	//	{
	//		
	//	}
	//public:
	//	friend class actor_instance<actor_mail>;
	//	static actor_mail& getInstance()
	//	{
	//		return actor_instance<actor_mail>::instance();
	//	}

	//	virtual void init()
	//	{
	//		m_mail.set(this);
	//	}
	//	static void actor_register();

	//	virtual ~actor_mail() {}

	//	virtual void loaddb_finish(bool adbishave) {}

	//	enum { ACTOR_TYPE = ACTOR_MAIL};

	//	bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_addmail& adata)
	//	{

	//		return true;
	//	}

	//	//actor_gm2other<actor_add_role_mail>
	//	//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_add_role_mail>& adata)
	//	//{
	//	//	actor_gmother<actor_add_role_mail_response> pro(adata.m_socket);

	//	//	actor_add_role_mail& recvpro = adata.m_data;

	//	//	std::vector<Item> lvitem;
	//	//	if (!create_item::create(recvpro.m_items, lvitem))
	//	//		return false;

	//	//	std::map<int64_t, MAIL_HOLDER> lmailholder;
	//	//	MAIL_HOLDER& lholder = lmailholder[recvpro.m_roleid];
	//	//	lholder.mm_draw() = false;
	//	//	lholder.mm_holder() = recvpro.m_roleid;
	//	//	lholder.mm_read() = false;

	//	//	m_mail.addmail(-1, lvitem, lmailholder, recvpro.m_content);

	//	//	return true;
	//	//}

	//	////actor_get_role_mail
	//	//bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_get_role_mail>& adata)
	//	//{
	//	//	static int lnum = 0;
	//	//	LogLocalError("####### [actor_get_role_mail] #### [%]", ++lnum);

	//	//	std::shared_ptr<actor_gmother<actor_get_role_mail_response>> pro(new actor_gmother<actor_get_role_mail_response>(adata.m_socket));
	//	//	
	//	//	actor_get_role_mail& recvpro = adata.m_data;

	//	//	m_mail.getmailbyrole(recvpro.m_roleid, pro->m_data.m_mails);

	//	//	send_actor(actor_guid::make(ACTOR_GM), pro);
	//	//	return true;
	//	//}

	//private:
	//};
}