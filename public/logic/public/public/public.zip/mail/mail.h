#pragma once

#include "db_modular.h"
#include "localtime.h"
#include <string>

namespace ngl
{
	//class actor_mail;
	//class mail : public db_modular<ENUM_DB_MAIL, DB_MAIL, actor_mail>
	//{
	//	int64_t m_maxid;
	//	std::map<int64_t, std::set<int64_t>> m_idrolebymail;
	//public:
	//	mail() :
	//		db_modular<ENUM_DB_MAIL, DB_MAIL, actor_mail>()
	//	{
	//	}

	//	virtual void set_id()
	//	{
	//		m_id = -1;
	//	}

	//	virtual void init_data()
	//	{
	//		LogLocalError("actor_mail###loaddb_finish");
	//		i32_actordataid ltemp = 0;
	//		for (auto&& [id, dbmail] : data())
	//		{
	//			for (auto&& [roleid, holder] : dbmail.const_mm_mailholder())
	//			{
	//				m_idrolebymail[roleid].insert(id);
	//			}
	//			if (m_maxid < id)
	//				m_maxid = id;
	//			std::string lcreate = localtime::time2msstr(dbmail.const_mm_createutc(), "%y-%m-%d %H:%M:%S");
	//			LogLocalError("mail###id:[%] tid:[%] create[%] parm[%]", id, dbmail.const_mm_tid(), lcreate, dbmail.const_mm_parm());
	//		}
	//	}


	//	/*DB_MAIL& addmail(int atid, std::vector<Item>& aitem, std::map<int64_t, MAIL_HOLDER>& aholder, MailContent& acontent, const std::string& aparm = "")
	//	{
	//		DB_MAIL* lmail = get(++m_maxid);
	//		lmail->mm_id() = m_maxid;
	//		lmail->mm_createutc() = localtime::gettime();
	//		lmail->mm_parm() = aparm;
	//		lmail->mm_item() = aitem;
	//		lmail->mm_mailholder() = aholder;
	//		for (auto&& [roleid, holder] : lmail->const_mm_mailholder())
	//		{
	//			m_idrolebymail[roleid].insert(lmail->const_mm_id());
	//		}
	//		lmail->mm_content() = acontent;
	//		return *lmail;
	//	}*/

	//	bool readmail(int64_t aid, int64_t aroleid)
	//	{
	//		DB_MAIL* lmail = find(aid);
	//		if (lmail == nullptr)
	//			return false;
	//		if(lmail->const_mm_mailholder().find(aroleid) == lmail->const_mm_mailholder().end())
	//			return false;
	//		lmail->mm_mailholder()[aroleid].mm_read() = true;
	//		return true;
	//	}

	//private:
	//	DB_MAIL* get_mail(int64_t aid)
	//	{
	//		return find(aid);
	//	}

	//	MAIL_HOLDER* get_mailholder(DB_MAIL* amail, int64_t aroleid)
	//	{
	//		if (amail->const_mm_mailholder().find(aroleid) == amail->const_mm_mailholder().end())
	//			return nullptr;
	//		return &amail->mm_mailholder()[aroleid];
	//	}

	//	bool change_holderdraw(MAIL_HOLDER* ahold, bool abool)
	//	{
	//		if (ahold->const_mm_draw() == abool)
	//			return false;
	//		ahold->mm_draw() = abool;
	//		return true;
	//	}

	//public:

	//	/*bool drawmail(int64_t aid, int64_t aroleid, std::vector<Item>& aitem)
	//	{
	//		DB_MAIL* lmail = get_mail(aid);
	//		if (lmail == nullptr)
	//			return false;
	//		MAIL_HOLDER* lpholder = get_mailholder(lmail, aroleid);
	//		if (lpholder == nullptr)
	//			return false;
	//		if (change_holderdraw(lpholder, true) == false)
	//			return false;
	//		for (auto& item : lmail->const_mm_item())
	//		{
	//			aitem.push_back(item);
	//		}
	//		return true;
	//	}*/
	//	void rollback_drawmail(int64_t aroleid, int amailid);
	//	// ��ȡ�����ʼ�
	//	bool drawmail(int64_t aid, int64_t aroleid);
	//	// һ����ȡ�ʼ�
	//	bool drawmail(int64_t aroleid);

	//	void getmailbyrole(int64_t aroleid, std::vector<DB_MAIL>& avec);
	//};
}