#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
//#include "actor_protocol_gm.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"

#include "db_modular.h"
#include "mail.h"
//#include "item.h"

namespace ngl
{
	class actor_chat : public actor<actor_chat>
	{
		actor_chat() :
			actor<actor_chat>(
				actorparm
				{
					.m_parm
						{
							.m_type = ACTOR_CHAT,
							//.m_id = nconfig::m_nodeid,//���ô�ֵ˵��ÿ�����̶���һ������actor
						},
					.m_weight = 0x7fffffff,
				})
		{}

		std::map<int, std::list<chat>> m_chatitem;
		std::map<i64_actorid, roleitem> m_roleitem;
		std::map<int, std::list<chat>> m_updatalist;
	public:
		friend class actor_instance<actor_chat>;
		static actor_chat& getInstance()
		{
			return actor_instance<actor_chat>::instance();
		}

		static void actor_register();

		virtual ~actor_chat() {}

		virtual void loaddb_finish(bool adbishave) {}

		enum { ACTOR_TYPE = ACTOR_CHAT};

		/*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_chatroleinfo& adata)
		{
			m_roleitem[adata.m_roleitem.m_roleid] = adata.m_roleitem;
			return true;
		}*/

		roleitem* get_roleitem(i64_actorid aid)
		{
			auto itor = m_roleitem.find(aid);
			if (itor == m_roleitem.end())
				return nullptr;
			return &itor->second;
		}

		template <typename T>
		void send_gateway(i64_actorid aid, T& adata)
		{
			auto itor = m_roleitem.find(aid);
			if (itor == m_roleitem.end())
				return;
			send_client(itor->second.m_gatewayid, aid, adata);
		}

		////bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_chatspeak& adata)
		////{
		////	LOGIC_CHAT_RESPONSE pro;
		////	pro.m_type = chat_speak;
		////	pro.m_channelid = adata.m_channelid;
		////	pro.m_stat = false;
		////	ChatTab* ltab = allcsv::tab<ChatTab>(adata.m_channelid);
		////	if (ltab == nullptr)
		////	{
		////		send_gateway(adata.m_chatitem.m_roleid, pro);
		////		return true;
		////	}
		////	auto itor = m_roleitem.find(adata.m_chatitem.m_roleid);
		////	if (itor == m_roleitem.end())
		////	{
		////		send_gateway(adata.m_chatitem.m_roleid, pro);
		////		return true;
		////	}
		////	//int ltemputc = localtime::gettime() - itor->second.m_lastspeakutc;
		////	//if (ltemputc < ltab->m_time)
		////	//{
		////	//	send_gateway(adata.m_chatitem.m_roleid, pro);
		////	//	return true;
		////	//}
		////	itor->second.m_lastspeakutc = localtime::gettime();

		////	std::list<chat>& lschat = m_chatitem[adata.m_channelid];
		////	lschat.push_back(adata.m_chatitem);
		////	if (lschat.size() > ltab->m_count)
		////	{
		////		lschat.pop_front();
		////	}
		////	pro.m_stat = true;
		////	send_gateway(adata.m_chatitem.m_roleid, pro);

		////	m_updatalist[adata.m_channelid].push_back(adata.m_chatitem);

		////	/*actor_chatupdataspeak proupdata{ .m_channelid = adata.m_channelid };
		////	proupdata.m_chatitem.m_content = adata.m_chatitem.m_content;

		////	roleitem* lproleitem = get_roleitem(adata.m_chatitem.m_roleid);
		////	if (lproleitem == nullptr)
		////		return true;
		////	proupdata.m_chatitem.m_rolename = lproleitem->m_rolename;
		////	proupdata.m_chatitem.m_utc = adata.m_chatitem.m_utc;

		////	send_actor(ACTOR_ROLE, proupdata, true);*/
		////	return true;
		////}

		////bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_chatget& adata)
		////{
		////	LOGIC_CHAT_RESPONSE pro;
		////	pro.m_type = get_chat_list;
		////	pro.m_channelid = adata.m_channelid;
		////	auto itor = m_chatitem.find(adata.m_channelid);
		////	if (itor == m_chatitem.end())
		////		return true;

		////	std::vector<chatitem>& ls = pro.m_chat_list;
		////	for (auto itemls : itor->second)
		////	{
		////		roleitem* lproleitem = get_roleitem(itemls.m_roleid);
		////		if (lproleitem == nullptr)
		////			continue;

		////		chatitem ltemp;
		////		ltemp.m_rolename = lproleitem->m_rolename;
		////		ltemp.m_content = itemls.m_content;
		////		ltemp.m_utc = itemls.m_utc;
		////		ls.push_back(ltemp);
		////	}
		////	send_gateway(apack->m_head.get_request_actor(), pro);
		////	return true;
		////}

		virtual void init();

		bool timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata);
	private:
	};
}