#include "actor_chat.h"


namespace ngl
{
	void actor_chat::actor_register()
	{
		// ��ʱ��
		actor<actor_chat>::register_timer();
		// Э��ע��
		//register_actor<EPROTOCOL_TYPE_CUSTOM, actor_chat>(
		//	false, 
		//	define_null(actor_chatroleinfo),
		//	define_null(actor_chatspeak),
		//	define_null(actor_chatget)
		//	);
	}

	void actor_chat::init()
	{
		timerparm tparm;
		if(create_timerparm::create_interval(tparm, 1))
			set_timer(tparm);
	}

	bool actor_chat::timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata)
	{
		/*if (adata.m_type != timerparm::ET_INTERVAL_SEC)
			return true;

		for (auto& item : m_updatalist)
		{
			LOGIC_CHAT_RESPONSE pro;
			pro.m_type = updata_speck;
			pro.m_channelid = item.first;
			for (auto& itemchat : item.second)
			{
				roleitem* lproleitem = get_roleitem(itemchat.m_roleid);
				if (lproleitem == nullptr)
					continue;
				chatitem ltemp;
				ltemp.m_rolename = lproleitem->m_rolename;
				ltemp.m_utc = itemchat.m_utc;
				ltemp.m_content = itemchat.m_content;
				pro.m_chat_list.push_back(ltemp);
			}
			send_allclient(pro);
		}

		m_updatalist.clear();*/
		return true;
	}

}