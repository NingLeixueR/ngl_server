#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
//#include "actor_protocol_gm.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"

#include "db_modular.h"
#include "notice.h"
#include "splite.h"
#include "manage_csv.h"
#include "gm.pb.h"
#include "init_protobuf.h"

namespace ngl
{
	class actor_gm : public actor<actor_gm>
	{
		actor_gm() :
			actor<actor_gm>(
				actorparm
				{
					.m_parm{.m_type = ACTOR_GM},
					.m_weight = 0x7fffffff,
				})
		{
		}
	public:
		friend class actor_instance<actor_gm>;
		static actor_gm& getInstance()
		{
			return actor_instance<actor_gm>::instance();
		}

		virtual void init()
		{
		}
		static void actor_register()
		{
			// Э��ע��
			//register_actor<EPROTOCOL_TYPE_CUSTOM, actor_gm>(
			//	false,
			//	);

			register_actor<EPROTOCOL_TYPE_PROTOCOLBUFF, actor_gm>(
				false,
				define_null(Gm::PROBUFF_GM_GET_NOTICE),
				define_null(Gm::PROBUFF_GM_ADD_NOTICE),
				define_null(Gm::PROBUFF_GM_DEL_NOTICE),
				define_null(mforward<Gm::PROBUFF_GM_GET_NOTICE_RESPONSE>),
				define_null(mforward<Gm::PROBUFF_GM_ADD_NOTICE_RESPONSE>),
				define_null(mforward<Gm::PROBUFF_GM_DEL_NOTICE_RESPONSE>)
				);
		}

		virtual ~actor_gm() {}

		virtual void loaddb_finish(bool adbishave) {}

		enum { ACTOR_TYPE = ACTOR_GM};


		template <typename T>
		void sendphpclient(mforward<T>& adata)
		{
			send(adata.identifier(), *adata.data(), actor_guid::make(), actor_guid::make());
		}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, Gm::PROBUFF_GM_GET_NOTICE& adata)
		{
			using type = mforward<Gm::PROBUFF_GM_GET_NOTICE>;
			std::shared_ptr<type> pro(new type(apack->m_id));
			send_actor(actor_guid::make(ACTOR_NOTICE), pro);
			return true;
		}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, mforward<Gm::PROBUFF_GM_GET_NOTICE_RESPONSE>& adata)
		{
			sendphpclient(adata);
			return true;
		}


		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, Gm::PROBUFF_GM_ADD_NOTICE& adata)
		{
			using type = mforward<Gm::PROBUFF_GM_ADD_NOTICE>;
			std::shared_ptr<type> pro(new type(apack->m_id, adata));
			auto item = pro->data();
			std::cout << "item->m_protocol() = " << item->m_protocol() << std::endl;
			std::cout << "item->m_protocoltype() = " << item->m_protocoltype() << std::endl;

			send_actor(actor_guid::make(ACTOR_NOTICE), pro);
			return true;
		}


		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, mforward<Gm::PROBUFF_GM_ADD_NOTICE_RESPONSE>& adata)
		{
			sendphpclient(adata);
			return true;
		}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, Gm::PROBUFF_GM_DEL_NOTICE& adata)
		{
			using type = mforward<Gm::PROBUFF_GM_DEL_NOTICE>;
			std::shared_ptr<type> pro(new type(apack->m_id, adata));
			send_actor(actor_guid::make(ACTOR_NOTICE), pro);
			return true;
		}

		bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, mforward<Gm::PROBUFF_GM_DEL_NOTICE_RESPONSE>& adata)
		{
			sendphpclient(adata);
			return true;
		}

		//////bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, protocol_gm& adata)
		//////{
		//////	static int lnum = 0;
		//////	LogLocalError("###################### [protocol_gm][%]", ++lnum);
		//////	Try
		//////	{
		//////		else if (lprotocol == "del_role_item")
		//////		{
		//////			std::shared_ptr<actor_gmother<actor_del_role_item>> pro(new actor_gmother<actor_del_role_item>(apack->m_id));
		//////			get(adata.m_tree, "roleid", pro->m_data.m_roleid);
		//////			get(adata.m_tree, "itemid", pro->m_data.m_itemid);
		//////			get(adata.m_tree, "itemcount", pro->m_data.m_itemcount);
		//////			actor_guid lguid(pro->m_data.m_roleid);
		//////			send_actor(lguid, pro);
		//////		}
		//////		else if (lprotocol == "add_role_mail")
		//////		{
		//////			std::shared_ptr<actor_gmother<actor_add_role_mail>> pro(new actor_gmother<actor_add_role_mail>(apack->m_id));
		//////			get(adata.m_tree, "roleid", pro->m_data.m_roleid);
		//////			std::string litems;
		//////			get(adata.m_tree, "items", litems);
		//////			if (litems != "")
		//////			{
		//////				std::vector<std::string> lvecstr;
		//////				splite::division(litems.c_str(), "|", lvecstr);
		//////				for (std::string& item : lvecstr)
		//////				{
		//////					std::vector<int> lvecint;
		//////					splite::division(item.c_str(), "*", lvecint);
		//////					if (lvecint.size() >= 2)
		//////					{
		//////						pro->m_data.m_items[lvecint[0]] += lvecint[1];
		//////					}
		//////				}
		//////			}

		//////			get(adata.m_tree, "title", pro->m_data.m_content.mm_title());
		//////			get(adata.m_tree, "author", pro->m_data.m_content.mm_author());
		//////			get(adata.m_tree, "content", pro->m_data.m_content.mm_content());
		//////			send_actor(ngl::actor_guid::make(ACTOR_MAIL), pro);
		//////		}
		//////		else if (lprotocol == "get_role_mail")
		//////		{
		//////			std::shared_ptr<actor_gmother<actor_get_role_mail>> pro(new actor_gmother<actor_get_role_mail>(apack->m_id));
		//////			get(adata.m_tree, "roleid", pro->m_data.m_roleid);
		//////			send_actor(ngl::actor_guid::make(ACTOR_MAIL), pro);
		//////		}
		//////		else if (lprotocol == "activity")
		//////		{
		//////			std::shared_ptr<actor_gmother<actor_operator_activity>> pro(new actor_gmother<actor_operator_activity>(apack->m_id));
		//////			int ltype = 0;
		//////			get(adata.m_tree, "type", ltype);
		//////			pro->m_data.m_type = (actor_operator_activity::eoperator)ltype;
		//////			get(adata.m_tree, "activityid", pro->m_data.m_activityid);
		//////			if (pro->m_data.m_type == actor_operator_activity::open)
		//////			{
		//////				get(adata.m_tree, "startutc", pro->m_data.m_startutc);
		//////				get(adata.m_tree, "endutc", pro->m_data.m_endutc);
		//////			}					
		//////			send_actor(ngl::actor_guid::make(ACTOR_ACTIVITY_MANAGE), pro);
		//////		}
		//////	}Catch;
		//////	
		//////	return true;
		//////}


		//////bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_get_role_item_response>& adata)
		//////{
		//////	protocol_gm pro;
		//////	pro.m_tree["protocol"] = "get_role_item";
		//////	std::vector<Item>& lvecitem = adata.m_data.m_data;
		//////	char lbuff[1024] = { 0 };
		//////	for (int i = 0; i < lvecitem.size(); ++i)
		//////	{
		//////		snprintf(lbuff, 1024, "id[%]tid[%]count[%]<br/>", 
		//////			lvecitem[i].const_mm_id(), lvecitem[i].const_mm_tid(), lvecitem[i].const_mm_count());
		//////		pro.m_tree[boost::lexical_cast<std::string>(i)] = lbuff;
		//////	}
		//////	sendphpclient(adata, pro);
		//////	return true;
		//////}
	
		//////bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_get_role_mail_response>& adata)
		//////{
		//////	static int lnum = 0;
		//////	LogLocalError("####### [actor_get_role_mail_response] #### [%]", ++lnum);
		//////	protocol_gm pro;
		//////	pro.m_tree["protocol"] = "get_role_mail";
		//////	std::vector<DB_MAIL>& lmail = adata.m_data.m_mails;
		//////	//char lbuff[10240] = { 0 };
		//////	std::stringstream m_stream;
		//////	for (int i = 0; i < lmail.size(); ++i)
		//////	{
		//////		DB_MAIL& ldbmail = lmail[i];
		//////		m_stream << "<hr/>id[" << ldbmail.const_mm_id() << "]"
		//////			<< "tid[" << lmail[i].const_mm_tid() << "]"
		//////			<< "title[" << lmail[i].const_mm_content().const_mm_title() << "]"
		//////			<< "author[" << lmail[i].const_mm_content().const_mm_author() << "]"
		//////			<< "content[" << lmail[i].const_mm_content().const_mm_content() << "]<br/>";
		//////		m_stream << "items => ";
		//////		for (auto& item : ldbmail.const_mm_item())
		//////		{
		//////			ItemTab* lptab = allcsv::tab<ItemTab>(item.const_mm_tid());
		//////			if (lptab == nullptr)
		//////				continue;
		//////			m_stream << "[tid:" << item.const_mm_tid() << "|name:"<< lptab->_name << "|count:" << item.const_mm_count() << "]<br/>";
		//////		}
		//////		pro.m_tree[boost::lexical_cast<std::string>(i)] = m_stream.str();
		//////	}
		//////	sendphpclient(adata, pro);
		//////	return true;
		//////}

		private:
	};
}