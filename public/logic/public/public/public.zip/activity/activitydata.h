#pragma once

#include "db_modular.h"
#include "localtime.h"
#include <string>

namespace ngl
{
	/*class actor_activity_manage;
	class activitydata : public db_modular<ENUM_DB_ACTIVITYDATA, DB_ACTIVITYDATA, actor_activity_manage>
	{
	public:
		activitydata() :
			db_modular<ENUM_DB_ACTIVITYDATA, DB_ACTIVITYDATA, actor_activity_manage>()
		{
		}

		virtual void set_id()
		{
			m_id = -1;
		}

		virtual void init_data()
		{
			LogLocalError("activitydata###loaddb_finish");
		}

	};*/
}