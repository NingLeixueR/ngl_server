#include "actor_activity_everydaysign.h"


namespace ngl
{
	//void actor_activity_everydaysign::actor_register()
	//{
	//	activity_base<actor_activity_everydaysign>::actor_register();
	//	// Э��ע��
	//	register_actor<EPROTOCOL_TYPE_CUSTOM, actor_activity_everydaysign>(
	//		true, 
	//		define_null(actor_everydaysign)
	//		);
	//}

	

}