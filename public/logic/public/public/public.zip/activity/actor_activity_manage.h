#pragma once

#include "activity_base.h"
#include "activitydata.h"


namespace ngl
{
	//class actor_activity_manage : public actor<actor_activity_manage>
	//{
	//	activitydata m_activity;

	//	actor_activity_manage() :
	//		actor<actor_activity_manage>(
	//			actorparm
	//			{
	//				.m_parm{.m_type = ACTOR_ACTIVITY_MANAGE, .m_manage_dbclient = true,},
	//				.m_weight = 0x7fffffff,
	//				.m_broadcast = true,
	//			})
	//	{
	//	}
	//public:
	//	friend class actor_instance<actor_activity_manage>;
	//	static actor_activity_manage& getInstance()
	//	{
	//		return actor_instance<actor_activity_manage>::instance();
	//	}

	//	virtual void init()
	//	{
	//		m_activity.set(this);
	//	}
	//	static void actor_register();

	//	virtual ~actor_activity_manage() {}

	//	struct actor_timerparm
	//	{
	//		int m_id = 0;
	//		enum ptype
	//		{
	//			start,
	//		};
	//		ptype m_type = start;
	//	};

	//	void init_activity(DB_ACTIVITYDATA* aactivity)
	//	{
	//		int lnow = localtime::gettime();
	//		int32_t lbeg = aactivity->const_mm_beg();
	//		int32_t lend = aactivity->const_mm_beg();
	//		bool lstart = aactivity->const_mm_isstart();
	//		bool lfinish = aactivity->const_mm_isfinish();
	//		i64_actorid lactorid = aactivity->const_mm_id();

	//		if (lbeg != -1)
	//		{
	//			if (lnow < lbeg)
	//			{
	//				timerparm tparm;
	//				if (create_timerparm::create_interval(tparm, lbeg - lnow, 1))
	//				{
	//					tparm.set_parm(new actor_timerparm
	//						{
	//							.m_id = actor_guid::actordataid(lactorid),
	//							.m_type = actor_timerparm::start,
	//						});
	//					actor<actor_activity_manage>::set_timer(tparm);
	//				}
	//			}
	//			else
	//			{
	//				actor_base::create(ACTOR_ACTIVITY, actor_guid::none_area(), actor_guid::actordataid(lactorid), &lstart);
	//			}
	//		}
	//		else if (lbeg < lnow)
	//		{
	//			if (lend == -1 || lnow > lend)
	//			{
	//				actor_base::create(ACTOR_ACTIVITY, actor_guid::none_area(), actor_guid::actordataid(lactorid), &lstart);
	//			}
	//		}
	//		else
	//		{
	//			if (lfinish == false)
	//			{
	//				actor_base::create(ACTOR_ACTIVITY, actor_guid::none_area(), actor_guid::actordataid(lactorid), &lstart);
	//			}
	//		}
	//	}

	//	virtual void loaddb_finish(bool adbishave) 
	//	{
	//		int lnow = localtime::gettime();
	//		for (auto& item : m_activity.data())
	//		{
	//			init_activity(&item.second);
	//		}

	//		manage_csv<ActivityTab>* lpmanagecsv = allcsv::get<manage_csv<ActivityTab>>();
	//		if (lpmanagecsv == nullptr)
	//			return;
	//		lpmanagecsv->foreach([this](ActivityTab& atab)
	//			{
	//				if (atab.m_ispermanent == true)
	//				{
	//					i64_actorid lactorid = actor_guid::make(ACTOR_ACTIVITY, atab.id);
	//					DB_ACTIVITYDATA* lpactivity = m_activity.find(lactorid);
	//					if (lpactivity != nullptr)
	//						return;
	//					lpactivity = m_activity.get(lactorid);
	//					lpactivity->mm_beg() = localtime::gettime();
	//					lpactivity->mm_end() = -1;
	//					lpactivity->mm_id() = lactorid;
	//					lpactivity->mm_isfinish() = false;
	//					init_activity(lpactivity);
	//				}
	//			});
	//	}

	//	bool timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata)
	//	{
	//		if (adata.m_parm != nullptr)
	//		{
	//			actor_timerparm* lparm = (actor_timerparm*)adata.m_parm.get();
	//			switch (lparm->m_type)
	//			{
	//			case actor_timerparm::start:
	//			{
	//				bool lstatrt = true;
	//				actor_base::create(ACTOR_ACTIVITY, actor_guid::none_area(), lparm->m_id, &lstatrt);
	//			}
	//			break;
	//			}
	//		}

	//		return true;
	//	}


	//	enum { ACTOR_TYPE = ACTOR_ACTIVITY_MANAGE};

	//	bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_activity_operator& adata)
	//	{
	//		DB_ACTIVITYDATA* lpdata = m_activity.find(adata.m_activityid);
	//		if (lpdata == nullptr)
	//		{
	//			LogLocalError("actor_activity_operator activityid=[%]  type=[%] id=[%]", adata.m_activityid, actor_guid::type(adata.m_activityid), actor_guid::actordataid(adata.m_activityid))
	//			return true;
	//		}
	//		if (adata.m_type == actor_activity_operator::finish)
	//		{
	//			lpdata->mm_isfinish() = true;
	//		}
	//		return true;
	//	}

	//	///*bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_gmother<actor_operator_activity>& adata)
	//	//{
	//	//	actor_operator_activity& lrequest = adata.m_data;
	//	//	if (lrequest.m_type == actor_operator_activity::open)
	//	//	{
	//	//		actor_guid lguid = actor_guid::make(ACTOR_ACTIVITY, lrequest.m_activityid);
	//	//		DB_ACTIVITYDATA* lpdata = m_activity.find(lguid);
	//	//		if (lpdata != nullptr)
	//	//		{
	//	//			std::shared_ptr<actor_operator_activity_response> pro(new actor_operator_activity_response
	//	//				{
	//	//					.m_stat = false,
	//	//					.m_activityid = lrequest.m_activityid,
	//	//				});
	//	//			send_actor(actor_guid::make(ACTOR_GM), pro);
	//	//		}
	//	//		lpdata = m_activity.get(lguid);
	//	//		lpdata->mm_beg() = lrequest.m_startutc;
	//	//		lpdata->mm_end() = lrequest.m_endutc;
	//	//		lpdata->mm_id() = lguid;
	//	//		lpdata->mm_isfinish() = false;
	//	//		init_activity(lpdata);
	//	//	}
	//	//	else if (lrequest.m_type == actor_operator_activity::close)
	//	//	{

	//	//	}
	//	//	return true;
	//	//}*/

	//private:
	//};
}