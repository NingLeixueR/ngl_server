#pragma once

#include "activity_base.h"
#include "splite.h"

namespace ngl
{
	// #### ÿ��ǩ��
	//class actor_activity_everydaysign : public activity_base<actor_activity_everydaysign>
	//{
	//	
	//public:
	//	actor_activity_everydaysign(int atabid, bool aisstatrt) :
	//		activity_base<actor_activity_everydaysign>(atabid, aisstatrt)
	//	{
	//	}

	//	static void actor_register();

	//	virtual ~actor_activity_everydaysign() {}

	//	ActivityEveryDaySignTab* m_tabdaysign;
	//	std::vector<int> m_signdroplist;
	//	// #### ������������������ᱻ����
	//	virtual void active_init(ActivityTab* atab)
	//	{
	//		if (atab == nullptr)
	//			return;

	//		manage_csv<ActivityEveryDaySignTab>* lcsv = allcsv::get<manage_csv<ActivityEveryDaySignTab>>();
	//		if (lcsv == nullptr)
	//			return;
	//		m_tabdaysign = lcsv->find(atab->m_tabid);
	//		if (m_tabdaysign == nullptr)
	//			return;
	//		m_signdroplist.clear();
	//		splite::division(m_tabdaysign->m_reward.c_str(), "*", m_signdroplist);
	//	}

	//	void set_today(int32_t& anumtoday, bool abool)
	//	{
	//		int32_t lnum = anumtoday / 10;
	//		int32_t ltoday = 0;
	//		if (abool)
	//		{
	//			ltoday = abool ? 1 : 0;
	//			if (anumtoday % 10 == 0)
	//				++lnum;
	//		}
	//		anumtoday = lnum * 10 + ltoday;
	//	}

	//	bool istoday(int32_t anumtoday)
	//	{
	//		return anumtoday % 10 != 0;
	//	}

	//	bool handle(i32_threadid athread, const std::shared_ptr<pack>& apack, actor_everydaysign& adata)
	//	{
	//		DB_ACTIVITY* lactivity = m_activity.get();
	//		if (lactivity == nullptr)
	//			return true;
	//		i64_actorid lroleid = apack->m_head.get_request_actor();
	//		auto itor = lactivity->const_mm_numtoday().find(lroleid);
	//		if (itor == lactivity->const_mm_numtoday().end())
	//		{
	//			int32_t lnumtoday = 0;
	//			set_today(lnumtoday, true);
	//			lactivity->mm_numtoday().insert(std::make_pair(lroleid, lnumtoday));
	//			LogLocalError("actor_activity_everydaysign [%] ǩ���ɹ� [%]", lroleid, lnumtoday);
	//		}
	//		else
	//		{
	//			if (istoday(itor->second) == true)
	//				return true;
	//			// ### ���ͽ���

	//			// ### end

	//			set_today(lactivity->mm_numtoday()[lroleid], true);
	//			LogLocalError("actor_activity_everydaysign [%] ǩ���ɹ� [%]", lroleid, lactivity->mm_numtoday()[lroleid]);
	//		}
	//		return true;
	//	}
	//private:

	//	virtual void active_start()
	//	{
	//		DB_ACTIVITY* lactivity = m_activity.get();
	//		if (lactivity == nullptr)
	//			return;
	//		lactivity->mm_numtoday().clear();
	//	}
	//	virtual void active_finish()
	//	{

	//	}
	//	// ���Ҫ�����Ķ�ʱ����
	//	virtual void timer_task(const tm& atm)
	//	{
	//		int32_t lhour = localtime::gethour(&atm);
	//		int32_t lmin = localtime::getmin(&atm);
	//		int32_t lsec = localtime::getsec(&atm);
	//		// ÿ��0��0��0�봥��
	//		if (lhour == 0 && lmin == 0 && lsec == 0)
	//		{
	//			LogLocalError("ÿ��%��%��%�봥��", lhour, lmin, lsec);
	//			DB_ACTIVITY* lactivity = m_activity.get();
	//			if (lactivity == nullptr)
	//				return;
	//			for (auto& [_key, _value] : lactivity->mm_numtoday())
	//			{
	//				set_today(_value, false);
	//			}
	//		}
	//		
	//	}
	//};
}