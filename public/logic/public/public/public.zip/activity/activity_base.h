#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
//#include "actor_protocol_gm.h"
#include "actor_timer.h"
#include "actor_switchprocess.h"

#include "db_modular.h"
#include "mail.h"
//#include "item.h"
#include "activity.h"
#include "manage_csv.h"

namespace ngl
{

	//template <typename TACTOR>
	//class activity_base : public actor<activity_base<TACTOR>>
	//{
	//protected:
	//	activity<activity_base<TACTOR>> m_activity;
	//	//enum_activity m_enum;
	//	int32_t m_tabid;
	//	int m_start_timerid;
	//	int m_finish_timerid;
	//	int m_everysec_timerid;

	//	bool m_isstart;
	//public:
	//	activity_base(int32_t atabid, bool aisstatrt) :
	//		m_tabid(atabid),
	//		m_start_timerid(-1),
	//		m_finish_timerid(-1),
	//		m_isstart(aisstatrt),
	//		actor<activity_base<TACTOR>>(
	//			actorparm
	//			{
	//				.m_parm
	//					{
	//						.m_type = ACTOR_ACTIVITY,
	//						.m_id = atabid,
	//						.m_manage_dbclient = true
	//					},
	//				.m_weight = 0x7fffffff,
	//				.m_broadcast = true,
	//			})
	//	{}

	//	enum { ACTOR_TYPE = ACTOR_ACTIVITY };

	//	virtual void loaddb_finish(bool adbishave)
	//	{
	//		ActivityTab* ltab = tab();
	//		if (ltab == nullptr)
	//			return;
	//		LogLocalError("activity_base<TACTOR>::loaddb_finish type=[%]", ltab->m_type);
	//		start(adbishave);
	//	}

	//	// #### ������������������ᱻ����
	//	virtual void active_init(ActivityTab*) = 0;
	//	// #### ������ᱻ����
	//	virtual void active_start() = 0;
	//	// #### ������ᱻ����
	//	virtual void active_finish() = 0;
	//	// ����ʱ��ĺ���
	//	void active_timer(int64_t ams)
	//	{
	//		int32_t ltemp = ams / 1000;

	//		tm ltm;
	//		localtime::gettm(ltemp, ltm);
	//		int32_t lyear = localtime::getyear(&ltm);
	//		int32_t lmoon = localtime::getmoon(&ltm);
	//		int32_t lmoonday = localtime::getmoonday(&ltm);
	//		int32_t lweekday = localtime::getweekday(&ltm);
	//		int32_t lhour = localtime::gethour(&ltm);
	//		int32_t lmin = localtime::getmin(&ltm);
	//		int32_t lsec = localtime::getsec(&ltm);

	//		LogLocalError(
	//			"active_timer [%-%-%] weekday[%] [%:%:%]",
	//			lyear, lmoon, lmoonday,	// y-m-d
	//			lweekday,
	//			lhour, lmin, lsec		// h:m:s
	//		);

	//		timer_task(ltm);
	//	}
	//	// ���Ҫ�����Ķ�ʱ����
	//	virtual void timer_task(const tm& atm)
	//	{
	//		//int32_t lyear = localtime::getyear(&ltm);
	//		//int32_t lmoon = localtime::getmoon(&ltm);
	//		//int32_t lmoonday = localtime::getmoonday(&ltm);
	//		//int32_t lweekday = localtime::getweekday(&ltm);
	//		//int32_t lhour = localtime::gethour(&ltm);
	//		//int32_t lmin = localtime::getmin(&ltm);
	//		//int32_t lsec = localtime::getsec(&ltm);
	//		// ÿ��0��0��0�봥��
	//		//if (lhour == 0 && lmin == 0 && lsec == 0)
	//		//{
	//		//	LogLocalError("ÿ��%��%��%�봥��", lhour, lmin, lsec);
	//		//}
	//		//// ÿ��5��0��0�봥��
	//		//if (lhour == 5 && lmin == 0 && lsec == 0)
	//		//{
	//		//	LogLocalError("ÿ��%��%��%�봥��", lhour, lmin, lsec);
	//		//}
	//		//// ÿ��1�� 0��0��0�봥��
	//		//if (lmoonday == 1 && lhour == 0 && lmin == 0 && lsec == 0)
	//		//{
	//		//	LogLocalError("ÿ��%�� %��%��%�봥��", lmoonday, lhour, lmin, lsec);
	//		//}
	//		//// ÿ��1 0��0��0�봥��
	//		//if (lweekday == 1 && lhour == 0 && lmin == 0 && lsec == 0)
	//		//{
	//		//	LogLocalError("ÿ��% %��%��%�봥��", lweekday, lhour, lmin, lsec);
	//		//}
	//	}

	//	ActivityTab* tab()
	//	{
	//		return allcsv::tab<ActivityTab>(m_tabid);
	//	}

	//	struct actor_timerparm
	//	{
	//		enum ptype
	//		{
	//			eoperatpr_start,			// ���ʼ
	//			eoperatpr_finish,			// �����
	//			eoperatpr_sec,
	//		};
	//		ptype m_type = eoperatpr_start;
	//		int m_sec = 0;
	//	};

	//	void start(bool adbishave)
	//	{
	//		ActivityTab* ltab = tab();
	//		if (ltab == nullptr)
	//			return;

	//		int lnow = localtime::gettime();
	//		DB_ACTIVITY* dbactivity = m_activity.find(actor_base::id_guid());
	//		if (adbishave == false)
	//		{
	//			dbactivity = m_activity.get();
	//			dbactivity->mm_id() = ltab->id;
	//			dbactivity->mm_beg() = lnow;
	//			dbactivity->mm_end() = ltab->m_ispermanent? -1: lnow + ltab->m_ms;
	//			active_init(tab());
	//			if(m_isstart)
	//				active_start();
	//		}
	//		else
	//		{
	//			active_init(tab());
	//		}

	//		if (dbactivity->const_mm_beg() == -1)
	//		{
	//			dbactivity->mm_beg() = lnow;
	//		}

	//		if (dbactivity->const_mm_end() != -1 && lnow < dbactivity->const_mm_end())
	//		{
	//			timerparm tparm;
	//			if (create_timerparm::create_interval(tparm, dbactivity->const_mm_end() - lnow, 1))
	//			{
	//				tparm.set_parm(new actor_timerparm{ .m_type = actor_timerparm::eoperatpr_finish });
	//				m_finish_timerid = actor<activity_base<TACTOR>>::set_timer(tparm);
	//			}
	//			{// #### ÿ���Ӵ���
	//				timerparm tparm;
	//				if (create_timerparm::create_interval(tparm, 1))
	//				{
	//					tparm.set_parm(new actor_timerparm{ .m_type = actor_timerparm::eoperatpr_sec });
	//					m_everysec_timerid = actor<activity_base<TACTOR>>::set_timer(tparm);
	//				}
	//			}
	//		}
	//		else
	//		{
	//			if (dbactivity->const_mm_isfinish() == false)
	//			{
	//				active_finish();
	//			}
	//			std::shared_ptr<actor_activity_operator> pro(new actor_activity_operator
	//				{
	//					.m_type = actor_activity_operator::finish,
	//					.m_activityid = actor_base::id_guid()
	//				});
	//			actor_base::send_actor(actor_guid::make(ACTOR_ACTIVITY_MANAGE), pro);
	//		}

	//		

	//	}

	//	virtual void init()
	//	{
	//		m_activity.set(this);
	//	}

	//	static void actor_register()
	//	{
	//		//actor<activity_base<TACTOR>>::register_timer<activity_base<TACTOR>>();
	//		//actor<activity_base<TACTOR>>::rfun().rfun<activity_base<TACTOR>, timerparm>(&activity_base<TACTOR>::timer_handle, false);
	//		//actor<activity_base<TACTOR>>::rfun().rfun_nonet<activity_base<TACTOR>, timerparm>(&activity_base<TACTOR>::timer_handle, false);
	//		//actor_rfun& lrfun = actor<activity_base<TACTOR>>::rfun(EPROTOCOL_TYPE_CUSTOM);
	//		auto lfun = &activity_base<TACTOR>::timer_handle;
	//		actor<activity_base<TACTOR>>::rfun(EPROTOCOL_TYPE_CUSTOM).rfun_nonet<EPROTOCOL_TYPE_CUSTOM,activity_base<TACTOR>, timerparm>(lfun, false);

	//	}

	//	bool timer_handle(i32_threadid athread, const std::shared_ptr<pack>& apack, timerparm& adata)
	//	{
	//		if (adata.m_parm != nullptr)
	//		{
	//			actor_timerparm* lparm = (actor_timerparm*)adata.m_parm.get();
	//			if (lparm->m_type == actor_timerparm::eoperatpr_start)
	//			{// �����
	//				active_start();
	//			}
	//			else if (lparm->m_type == actor_timerparm::eoperatpr_finish)
	//			{
	//				active_finish();
	//				std::shared_ptr<actor_activity_operator> pro(new actor_activity_operator{
	//					.m_type = actor_activity_operator::finish,
	//					.m_activityid = actor_base::id_guid()
	//					});
	//				actor_base::send_actor(actor_guid::make(ACTOR_ACTIVITY_MANAGE), pro);
	//			}
	//			else if (lparm->m_type == actor_timerparm::eoperatpr_sec)
	//			{
	//				active_timer(adata.m_triggerms);
	//			}
	//		}

	//		return true;
	//	}

	//};
}