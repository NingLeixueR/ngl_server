#pragma once

#include "activity_base.h"
#include "actor_activity_everydaysign.h"

namespace ngl
{
	//class activity_create
	//{
	//public:
	//	// ### bool aisstart �Ƿ���л�����߼�
	//	static actor_base* create(int atabid, bool aisstart)
	//	{
	//		ActivityTab* ltab = allcsv::tab<ActivityTab>(atabid);
	//		if (ltab == nullptr)
	//			return nullptr;

	//		switch (ltab->m_type)
	//		{
	//		case enum_activity_everydaysign:
	//			return new actor_activity_everydaysign(atabid, aisstart);
	//		}
	//		return nullptr;
	//	}
	//};



}