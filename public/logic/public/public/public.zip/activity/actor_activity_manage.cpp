#include "actor_activity_manage.h"


namespace ngl
{
	//void actor_activity_manage::actor_register()
	//{
	//	// ��ʱ��
	//	actor<actor_activity_manage>::register_timer();
	//	// Э��ע��
	//	register_actor<EPROTOCOL_TYPE_CUSTOM, actor_activity_manage>(
	//		true,
	//		define_null(actor_activity_operator)/*,
	//		define_null(actor_gmother<actor_operator_activity>)*/
	//		);
	//}


}