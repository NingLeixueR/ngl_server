#pragma once

#include "db_modular.h"
#include "localtime.h"
#include <string>

namespace ngl
{
	///*template <typename ACTOR>
	//class activity : public db_modular<ENUM_DB_ACTIVITY, DB_ACTIVITY, ACTOR>
	//{
	//public:
	//	activity() :
	//		db_modular<ENUM_DB_ACTIVITY, DB_ACTIVITY, ACTOR>()
	//	{
	//	}

	//	virtual void init_data()
	//	{
	//		LogLocalError("activity###loaddb_finish");
	//	}

	//};*/
}