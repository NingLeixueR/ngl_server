#include "attribute_tools.h"


namespace ngl
{
	std::map<enum_module_attribute, std::vector<enum_module_attribute>> attribute_help::m_fatherlist;
	std::map<enum_module_attribute, std::vector<enum_module_attribute>> attribute_help::m_childrenlist;
	std::map<enum_module_attribute, enum_module_attribute> attribute_help::m_father;
	std::map<enum_module_attribute, enum_module_attribute> attribute_help::m_children;

	void attribute_help::init()
	{
		manage_csv<AttributeModuleTab>::foreach([](AttributeModuleTab& adata)
			{
				Try
				{
					Assert(adata.id > adata.m_father);
					attribute_help::m_father.insert(std::make_pair((enum_module_attribute)adata.id, adata.m_father));
				}
				Catch;
			});

		for (auto&& item : m_father)
		{
			// ### father list
			std::vector<enum_module_attribute>& lvec = m_fatherlist[item.first];
			lvec.push_back(item.first);
			lvec.push_back(item.second);
			enum_module_attribute* lp = &item.second;
			do
			{
				lp = tools::findmap(m_father, *lp);
				if (lp == NULL)
					break;
				lvec.push_back(*lp);
			} while (true);

			// ### children list
			std::vector<enum_module_attribute>& lchildrenvec = m_childrenlist[item.second];
			lchildrenvec.push_back(item.first);
		}
	}
	bool attribute_help::father_list(enum_module_attribute amodule, std::pair<const enum_module_attribute*, int>& apair)
	{
		std::vector<enum_module_attribute>* lp = tools::findmap(m_fatherlist, amodule);
		if (lp == NULL)
			return false;
		apair.first = lp->data();
		apair.second = lp->size();
		return true;
	}
	bool attribute_help::children_list(enum_module_attribute amodule, std::pair<const enum_module_attribute*, int>& apair)
	{
		std::vector<enum_module_attribute>* lp = tools::findmap(m_childrenlist, amodule);
		if (lp == NULL)
			return false;
		apair.first = lp->data();
		apair.second = lp->size();
		return true;
	}

	bool attribute_help::isfatherlist(enum_module_attribute amodule1, enum_module_attribute amodule2)
	{
		std::vector<enum_module_attribute>* lp = tools::findmap(m_fatherlist, amodule1);
		if (lp == NULL)
			return false;
		for (int i = 0; i < lp->size(); ++i)
		{
			if ((*lp)[i] == amodule2)
				return true;
		}
		return false;
	}

	bool attribute_help::isfather(enum_module_attribute amodule1, enum_module_attribute amodule2)
	{
		enum_module_attribute* lp = tools::findmap(m_father, amodule1);
		if (lp == NULL)
			return false;
		return amodule2 == *lp;
	}


	bool attribute_help::ischildrenlist(enum_module_attribute amodule1, enum_module_attribute amodule2)
	{
		std::vector<enum_module_attribute>* lp = tools::findmap(m_childrenlist, amodule1);
		if (lp == NULL)
			return false;
		for (int i = 0; i < lp->size(); ++i)
		{
			if ((*lp)[i] == amodule2)
				return true;
		}
		return false;
	}

	bool attribute_help::ischildren(enum_module_attribute amodule1, enum_module_attribute amodule2)
	{
		enum_module_attribute* lp = tools::findmap(m_children, amodule1);
		if (lp == NULL)
			return false;
		return amodule2 == *lp;
	}

	bool attribute_help::father(enum_module_attribute amodule1, enum_module_attribute& amodule2)
	{
		enum_module_attribute* lp = tools::findmap(m_father, amodule1);
		if (lp == NULL)
			return false;
		amodule2 = *lp;
		return true;
	}

	bool attribute_help::children(enum_module_attribute amodule1, enum_module_attribute& amodule2)
	{
		enum_module_attribute* lp = tools::findmap(m_children, amodule1);
		if (lp == NULL)
			return false;
		amodule2 = *lp;
		return true;
	}

	
}