#pragma once 

#include "attribute_value.h"


namespace ngl
{
	class attribute_module
	{
	public:
		attribute_value m_value_module;
		map_attribute	m_proportion;
		map_attribute	m_global_proportion;
		// ### �ϲ��������
		// ## �ϲ���ľ���ֵ
		map_attribute	m_absolutefightdata;
		map_attribute	m_fightdata;

		// ### ս��
		int64_t m_fightscore;
		enum_module_attribute m_module;

		using foreachfun = std::function<void(enum_attribute, int32_t)>;

		void foreach_map(map_attribute& amap, const foreachfun& afun);

		void printf();

		attribute_module(enum_module_attribute amodule)
			:m_fightscore(0),
			m_module(amodule)
		{
		}

		attribute_module()
			:m_fightscore(0),
			m_module(em_attribute_null)
		{
		}


		// ### ��������
		void set(enum_module_attribute aenum, attribute_value& avaluemodule)
		{
			m_module = aenum;
			for (auto& item : m_value_module.m_attribute)
			{
				m_absolutefightdata[item.first] -= item.second;
			}
			m_value_module.set(avaluemodule);
			if (m_absolutefightdata.empty())
			{
				for (auto& item : m_value_module.m_attribute)
				{
					m_absolutefightdata[item.first] = item.second;
				}
			}
			m_proportion.clear();
			m_global_proportion.clear();
			m_fightdata.clear();
			m_fightscore = 0;
		}

		int64_t update_fight()
		{
			m_fightscore = 0;
			for (auto& item : m_fightdata)
			{
				m_fightscore += item.second * attribute_help::fight(item.first);
			}
			return m_fightscore;
		}

		int32_t ratio_value(int32_t athreshold, int32_t aratio, int32_t avalue)
		{
			double ltemp = avalue * aratio / attribute_ratio_value;
			if (athreshold > 0)
				return ltemp > athreshold ? athreshold : ltemp;
			else
				return ltemp;
		}

		// ### �ڻ�������ֵ���������ӱ���
		void proportion()
		{
			ratio_map& lmap = m_value_module.ratio_attribute(m_module);
			for (auto& item1 : lmap)
			{
				for (auto& item2 : item1.second)
				{
					int32_t* lp = tools::findmap(m_value_module.m_attribute, item1.first);
					if (lp == NULL)
						continue;
					m_proportion[item1.first] += ratio_value(item2.first.threshold(), item2.first.ratio(), *lp);
				}
			}
		}

		// ### ��ȫ�����������ӱ���
		void proportion_global()
		{
			ratio_map& lmap = m_value_module.global_ratio_attribute(m_module);
			for (auto& item1 : lmap)
			{
				for (auto& item2 : item1.second)
				{
					m_global_proportion[item1.first] += ratio_value(item2.first.threshold(), item2.first.ratio(), m_fightdata[item1.first]);
				}
			}
		}

		// ### �ڻ�������ֵ���������ӱ���(�����ṩ�ı���)
		void proportion_children()
		{
			m_value_module.foreach_children_ratio([this](enum_module_attribute aenum, ratio_map& amap)
				{
					for (auto& item1 : amap)
					{
						for (auto& item2 : item1.second)
						{
							int32_t* lp = tools::findmap(m_value_module.m_attribute, item1.first);
							if (lp == NULL)
								continue;
							m_proportion[item1.first] += ratio_value(item2.first.threshold(), item2.first.ratio(), *lp);
						}
					}
				});
		}

		// ### ��ȫ�����������ӱ���(�����ṩ�ı���)
		void proportion_global_children()
		{
			m_value_module.foreach_global_children_ratio([this](enum_module_attribute aenum, ratio_map& amap)
				{
					for (auto& item1 : amap)
					{
						for (auto& item2 : item1.second)
						{
							m_global_proportion[item1.first] += ratio_value(item2.first.threshold(), item2.first.ratio(), m_fightdata[item1.first]);
						}
					}
				});
		}

		// ### ��proportion_global���ӵ�����������
		void add_global_proportion()
		{
			if (!m_global_proportion.empty())
			{
				for (auto& item : m_global_proportion)
				{
					m_fightdata[item.first] += item.second;
				}
			}
		}
		// ### ��proportion���ӵ�����������
		void add_proportion()
		{
			if (!m_proportion.empty())
			{
				for (auto& item : m_proportion)
				{
					m_fightdata[item.first] += item.second;
				}
			}
		}
		// ### ��proportion���ӵ�����������
		void add_absolute()
		{
			if (!m_absolutefightdata.empty())
			{
				for (auto& item : m_absolutefightdata)
				{
					m_fightdata[item.first] += item.second;
				}
			}
		}

		void calculation_fight()
		{
			for (auto& item : m_fightdata)
				m_fightscore += item.second * attribute_help::fight(item.first);
		}

		void update()
		{
			m_fightscore = 0;
			m_proportion.clear();
			m_global_proportion.clear();
			m_fightdata.clear();

			proportion();
			proportion_children();

			add_proportion();
			add_absolute();

			proportion_global();
			proportion_global_children();

			add_global_proportion();

			calculation_fight();
		}

		// ### ��ȡ����ֵ
		int64_t fight()
		{
			return m_fightscore;
		}

		// ### ��ȡ����ֵ
		int32_t fight_attribute(enum_attribute aenum)
		{
			return m_fightdata[aenum];
		}

		// ### ��ȡ��������
		std::map<enum_attribute, int32_t>& fight_all_attribute()
		{
			return m_fightdata;
		}

		void root_add(const attribute_module& amodule)
		{
			if (m_module != em_attribute_root)
				return;
			for (std::pair<const enum_attribute, int32_t>& item : m_absolutefightdata)
			{
				auto itor = amodule.m_fightdata.find(item.first);
				if (itor == amodule.m_fightdata.end())
					continue;
				item.second += itor->second;
			}
		}

		void root_dec(const attribute_module& amodule)
		{
			if (m_module != em_attribute_root)
				return;
			for (std::pair<const enum_attribute, int32_t>& item : m_absolutefightdata)
			{
				auto itor = amodule.m_fightdata.find(item.first);
				if (itor == amodule.m_fightdata.end())
					continue;
				item.second -= itor->second;
			}
		}

		
	};

}