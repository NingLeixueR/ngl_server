#include "attribute.h"


namespace ngl
{
	// #### ��ģ���Ӧ�ٷֱ��������ӵ�������ȥ
	void attribute::insert_father(enum_module_attribute aenum)
	{
		attribute_module& lmodule = m_moduledata[aenum];
		lmodule.m_value_module.foreach_ratio([this, &lmodule](enum_module_attribute aenum, ratio_map& amap)
			{
				if (lmodule.m_module == aenum)
					return;
				attribute_module& lfather = m_moduledata[aenum];
				ratio_map& lchildrenratio = lfather.m_value_module.children_ratio_attribute(lmodule.m_module);
				ratio_map& lratio = lmodule.m_value_module.ratio_attribute(aenum);
				lchildrenratio = lratio;
			});

		lmodule.m_value_module.foreach_global_ratio([this, &lmodule](enum_module_attribute aenum, ratio_map& amap)
			{
				if (lmodule.m_module == aenum)
					return;
				attribute_module& lfather = m_moduledata[aenum];
				ratio_map& lchildrenratio = lfather.m_value_module.global_children_ratio_attribute(lmodule.m_module);
				ratio_map& lratio = lmodule.m_value_module.global_ratio_attribute(aenum);
				lchildrenratio = lratio;
			});
		//enum_module_attribute lenum;
		//if (attribute_module_father::father(aenum, lenum))
		//{
		//	insert_father(lenum);
		//}
	}

	// #### ���Ƴ�ģ��Ը������ӵİٷֱ�����
	void attribute::earse_father(enum_module_attribute aenum)
	{
		attribute_module& lmodule = m_moduledata[aenum];
		lmodule.m_value_module.foreach_ratio([this, aenum](enum_module_attribute aenumfather, ratio_map& amap)
			{
				if (aenum == aenumfather)
					return;
				attribute_module& lfather = m_moduledata[aenumfather];
				lfather.m_value_module.del_children_ratio(aenum);
				lfather.m_value_module.del_global_children_ratio(aenum);
			});
		///*enum_module_attribute lenum;
		//if (attribute_module_father::father(aenum, lenum))
		//{
		//	earse_father(lenum);
		//}*/
	}

	// #### ȥ�����ϵ�����ֵ
	void attribute::earse_root_father(enum_module_attribute aenum)
	{
		if (aenum == em_attribute_root)
			return;
		m_moduledata[em_attribute_root].root_dec(m_moduledata[aenum]);
		enum_module_attribute lenum;
		if (attribute_help::father(aenum, lenum))
		{
			earse_root_father(lenum);
		}
	}

	void attribute::add_root_father(enum_module_attribute aenum)
	{
		if (aenum == em_attribute_root)
			return;
		m_moduledata[em_attribute_root].root_add(m_moduledata[aenum]);
		enum_module_attribute lenum;
		if (attribute_help::father(aenum, lenum))
		{
			add_root_father(lenum);
		}
	}


	void attribute::updata_list(enum_module_attribute aenum)
	{
		if (aenum == em_attribute_root)
			return;
		for (auto& item : m_moduledata[aenum].m_value_module.m_attribute)
		{
			m_moduledata[aenum].m_absolutefightdata[item.first] = item.second;
		}
		m_moduledata[aenum].m_fightdata.clear();
		m_moduledata[aenum].update();
		enum_module_attribute lenum;
		if (attribute_help::father(aenum, lenum))
		{
			updata_list(lenum);
		}
	}

	bool rand_attribute(enum_module_attribute aenum, attribute_value& attribute, bool abool)
	{
		std::pair<const enum_module_attribute*, int> lpair;
		enum_module_attribute lenum = em_attribute_root;
		if (aenum != em_attribute_root)
		{
			if (attribute_help::father_list(aenum, lpair) == false)
				return false;
		}
		else
			lpair = std::pair<const enum_module_attribute*, int>(&lenum, 1);

		for (int i = 0; i < 4; ++i)
		{
			if (abool)
				attribute.m_attribute[(enum_attribute)i] += 100;
			else
				attribute.m_attribute[(enum_attribute)i] += 200;
		}
		for (int i = 1; i < lpair.second; ++i)
		{
			for (int j = 0; j < 4; ++j)
			{
				int64_t lvalue = 0;
				if (abool)
				{
					attribute.insert_ratio(lpair.first[i], (enum_attribute)(j), 1000, 1000);
				}
				else
				{
					attribute.insert_ratio(lpair.first[i], (enum_attribute)(j), 2000, 2000);
				}
			}
		}

		for (int i = 1; i < lpair.second; ++i)
		{
			for (int j = 0; j < 4; ++j)
			{
				int64_t lvalue = 0;
				if (abool)
				{
					attribute.insert_global_ratio(lpair.first[i], (enum_attribute)(j), 1000, 1000);
				}
				else
				{
					attribute.insert_global_ratio(lpair.first[i], (enum_attribute)(j), 2000, 2000);
				}
			}
		}
		return true;
	}

	


	void test_attribute()
	{

		ngl::manage_csv<AttributeTab>::load();
		ngl::manage_csv<AttributeModuleTab>::load();
		attribute_help::init();
		attribute lnow;
		attribute_value lattribute_value[em_attribute_count];
		for (int i = 0; i < em_attribute_count; ++i)
		{
			if (rand_attribute((enum_module_attribute)i, lattribute_value[i], true))
			{
				if (i == em_attribute_pet)
				{
					threshold_ratio_pair lpair;
					lpair.ratio(1000);
					lpair.threshold(1000);
					auto& lmap = lattribute_value[em_attribute_pet].m_global_ratio_attribute[em_attribute_root][attribute_attack];
					lmap.erase(lpair);
					lpair.ratio(2000);
					lpair.threshold(2000);
					lmap.insert(std::make_pair(lpair, 1));
				}
				lnow.init_data((enum_module_attribute)i, lattribute_value[i]);
			}
				
		}
		lnow.init();

		/*threshold_ratio_pair lpair;
		lpair.ratio(1000);
		lpair.threshold(1000);
		auto& lmap = lattribute_value[em_attribute_pet1].m_global_ratio_attribute[em_attribute_root][attribute_attack];
		lmap.erase(lpair);
		lpair.ratio(2000);
		lpair.threshold(2000);
		lmap.insert(std::make_pair(lpair, 1));*/

		threshold_ratio_pair lpair;
		lpair.ratio(1000);
		lpair.threshold(1000);
		auto& lmap = lattribute_value[em_attribute_pet].m_global_ratio_attribute[em_attribute_root][attribute_attack];
		lmap.erase(lpair);
		lpair.ratio(2000);
		lpair.threshold(2000);
		lmap.insert(std::make_pair(lpair, 1));

		lnow.updata(em_attribute_pet, lattribute_value[em_attribute_pet]);

		//if (rand_attribute(em_attribute_pet1, lattribute_value2,false))
		//	lnow.updata(em_attribute_pet1, lattribute_value2);

	}
}


/*//////////////////////////
// ### ���νṹ��ģ��
// ÿ��ģ��ֻ��һ�����ڵ� ��ÿ��ģ������ж���ӽ�� AttributeModuleTab
// ÿ��ģ��ֻ��Ϊ���Լ��������ĸ��ڵ�...�Լ������ϵĽ���ṩ�ٷֱ�����
*//////////////////////////


