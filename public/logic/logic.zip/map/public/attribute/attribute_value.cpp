#include "attribute_value.h"

namespace ngl
{
	void attribute_value::foreach_map(map_ratio_attribute& amap, const foreacfun& afun)
	{
		for (auto itor = amap.begin(); itor != amap.end(); ++itor)
		{
			afun(itor->first, itor->second);
		}
	}

	void attribute_value::printf()
	{
		std::cout << "#######attribute_value start######" << std::endl;
		std::cout << "#######m_attribute" << std::endl;
		for (auto& item : m_attribute)
		{
			std::cout << item.first << "=>" << item.second << std::endl;
		}


		auto lfun = [](enum_module_attribute aenum, ratio_map& amap)
		{
			for (auto& item1 : amap)
			{
				std::cout << "#" << item1.first << std::endl;
				for (auto& item2 : item1.second)
				{
					item2.first.printf();
					std::cout << "count[" << item2.second << "]" << std::endl;
				}
			}
		};
		std::cout << "#######m_ratio_attribute" << std::endl;
		foreach_map(m_ratio_attribute, lfun);
		std::cout << "#######m_global_ratio_attribute" << std::endl;
		foreach_map(m_global_ratio_attribute, lfun);
		std::cout << "#######m_children_ratio_attribute" << std::endl;
		foreach_map(m_children_ratio_attribute, lfun);
		std::cout << "#######m_global_children_ratio_attribute" << std::endl;
		foreach_map(m_global_children_ratio_attribute, lfun);
		std::cout << "#######attribute_value end######" << std::endl;
	}

	void attribute_value::clear()
	{
		m_attribute.clear();
		m_ratio_attribute.clear();
		m_global_ratio_attribute.clear();
		m_children_ratio_attribute.clear();
		m_global_children_ratio_attribute.clear();
	}

	ratio_map& attribute_value::ratio_attribute(enum_module_attribute amodule)
	{
		return m_ratio_attribute[amodule];
	}

	ratio_map& attribute_value::global_ratio_attribute(enum_module_attribute amodule)
	{
		return m_global_ratio_attribute[amodule];
	}

	ratio_map& attribute_value::children_ratio_attribute(enum_module_attribute amodule)
	{
		return m_children_ratio_attribute[amodule];
	}

	ratio_map& attribute_value::global_children_ratio_attribute(enum_module_attribute amodule)
	{
		return m_global_children_ratio_attribute[amodule];
	}

	void attribute_value::del_children_ratio(enum_module_attribute amodule)
	{
		m_children_ratio_attribute.erase(amodule);
	}

	void attribute_value::del_global_children_ratio(enum_module_attribute amodule)
	{
		m_global_children_ratio_attribute.erase(amodule);
	}

	void attribute_value::foreach_children_ratio(const attribute_value::foreacfun& afun)
	{
		foreach_map(m_children_ratio_attribute, afun);
	}

	void attribute_value::foreach_global_ratio(const attribute_value::foreacfun& afun)
	{
		foreach_map(m_global_ratio_attribute, afun);
	}

	void attribute_value::foreach_global_children_ratio(const attribute_value::foreacfun& afun)
	{
		foreach_map(m_global_children_ratio_attribute, afun);
	}

	void attribute_value::foreach_ratio(const attribute_value::foreacfun& afun)
	{
		foreach_map(m_ratio_attribute, afun);
	}

	void attribute_value::insert_ratio(enum_module_attribute amodule, enum_attribute aattribute, int32_t athreshold, int32_t aratio)
	{
		++m_ratio_attribute[amodule][aattribute][threshold_ratio_pair(athreshold, aratio)];
	}

	void attribute_value::insert_global_ratio(enum_module_attribute amodule, enum_attribute aattribute, int32_t athreshold, int32_t aratio)
	{
		++m_global_ratio_attribute[amodule][aattribute][threshold_ratio_pair(athreshold, aratio)];
	}

}