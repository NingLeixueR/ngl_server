#include "attribute_module.h"


namespace ngl
{
	void attribute_module::foreach_map(std::map<enum_attribute, int32_t>& amap, const std::function<void(enum_attribute, int32_t)>& afun)
	{
		for (auto& item : amap)
			afun(item.first, item.second);
	}

	void attribute_module::printf()
	{
		m_value_module.printf();

		std::cout << "#m_proportion" << std::endl;
		foreach_map(m_proportion, [](enum_attribute aenum, int32_t avalue)
			{
				std::cout << aenum << "=>" << avalue << std::endl;
			});
		std::cout << "#m_global_proportion" << std::endl;
		foreach_map(m_global_proportion, [](enum_attribute aenum, int32_t avalue)
			{
				std::cout << aenum << "=>" << avalue << std::endl;
			});
		std::cout << "#m_fightdata" << std::endl;
		foreach_map(m_fightdata, [](enum_attribute aenum, int32_t avalue)
			{
				std::cout << aenum << "=>" << avalue << std::endl;
			});

		std::cout << "#fight ====== " << m_fightscore << std::endl;
	}

}