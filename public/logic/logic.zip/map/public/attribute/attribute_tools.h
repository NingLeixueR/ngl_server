#pragma once 

#include <map>
#include <vector>
#include <array>
#include <functional>
#include "manage_csv.h"
#include "net.h"
#include "game_logic.h"

namespace ngl
{
	// ����ս�� 
	class attribute_help
	{
	public:
		// ### ��������������ȡ[ս��ϵ��]
		static double fight(enum_attribute aindex)
		{
			AttributeTab* tab = manage_csv<AttributeTab>::get(aindex);
			return tab == NULL ? 0 : tab->m_fightcoefficient;
		}
		// ### ��������������ȡ[��ʼֵ]
		static int32_t initvalue(enum_attribute aindex)
		{
			AttributeTab* tab = manage_csv<AttributeTab>::get(aindex);
			return tab == NULL ? -1 : tab->m_initvalue;
		}

	private:
		static std::map<enum_module_attribute, std::vector<enum_module_attribute>> m_fatherlist;
		static std::map<enum_module_attribute, std::vector<enum_module_attribute>> m_childrenlist;
		static std::map<enum_module_attribute, enum_module_attribute> m_father;
		static std::map<enum_module_attribute, enum_module_attribute> m_children;
	public:
		static void init();
		// ### ��ȡ�����б�[amodule, ...root]
		static bool father_list(enum_module_attribute amodule, std::pair<const enum_module_attribute*, int>& apair);
		// ### ��ȡ�����б�(amodule, ...]
		static bool children_list(enum_module_attribute amodule, std::pair<const enum_module_attribute*, int>& apair);
		// ### �ж�amodule2�Ƿ���amodule1�ĸ�����
		static bool isfatherlist(enum_module_attribute amodule1, enum_module_attribute amodule2);
		// ### �ж�amodule2�Ƿ���amodule1�ĸ����
		static bool isfather(enum_module_attribute amodule1, enum_module_attribute amodule2);
		// ### ��ȡamodule1�ĸ��ڵ�
		static bool father(enum_module_attribute amodule1, enum_module_attribute& amodule2);
		// ### ��ȡamodule1���ӽڵ�
		static bool children(enum_module_attribute amodule1, enum_module_attribute& amodule2);
		// ### �ж�amodule2�Ƿ���amodule1�ĸ�����
		static bool ischildrenlist(enum_module_attribute amodule1, enum_module_attribute amodule2);
		// ### �ж�amodule2�Ƿ���amodule1�ĸ����
		static bool ischildren(enum_module_attribute amodule1, enum_module_attribute amodule2);
	};

	// ### ��ֵ_��ֱ�ֵ ����
	union threshold_ratio_pair
	{
		int64_t m_threshold_ratio;
		int32_t m_value[2];

		threshold_ratio_pair() :
			m_threshold_ratio(0)
		{
		}

		threshold_ratio_pair(int32_t athreshold, int32_t aratio) :
			m_threshold_ratio(0)
		{
			threshold(athreshold);
			ratio(aratio);
		}

		threshold_ratio_pair(int64_t athreshold_ratio) :
			m_threshold_ratio(athreshold_ratio)
		{}

		// ### ������ֵ
		void threshold(int32_t athreshold)
		{
			m_value[0] = athreshold;
		}

		// ### ������ֱ�ֵ
		void ratio(int32_t aratio)
		{
			m_value[1] = aratio;
		}

		// ### ��ȡ��ֵ
		int32_t threshold()const
		{
			return m_value[0];
		}

		// ### ��ȡ��ֱ�ֵ
		int32_t ratio()const
		{
			return m_value[1];
		}

		bool operator<(const threshold_ratio_pair& ar)const
		{
			return m_threshold_ratio < ar.m_threshold_ratio;
		}

		void printf()const
		{
			std::cout << "threshold[" << threshold() << "]ratio[" << ratio() << "]";
		}
	};


	




}