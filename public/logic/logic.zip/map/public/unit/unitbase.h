#pragma once

#include "attribute.h"
#include "csvtable.h"
#include "type.h"
#include "actor_base.h"
#include <stdint.h>

namespace ngl
{
	class unitrole;
	class unitmonster;

	class unit
	{
		ENUM_UNIT m_type;
		attribute m_attribute;
	public:
		unit(ENUM_UNIT atype, i64_actorid aentityid, const attribute& m_attribute)
			:m_type(atype), m_entityid(aentityid), m_attribute(m_attribute)
		{}

		i64_actorid m_entityid;
		VECTOR3 m_pos;						// ��ǰλ�� 
		VECTOR3 m_orientation;				// ��ǰ����
		std::string m_name;
		//uint32_t m_x;
		//uint32_t m_y;
		int32_t m_lastmovetime;			// �ϴ�moveʱ��

		void entity(ENTITY& adata)
		{
			adata.m_entityid = m_entityid;
			adata.m_pos = m_pos;
			adata.m_orientation = m_orientation;
			adata.m_movespeed = speed();
			adata.m_name = m_name;
			ATTRIBUTE lATTRIBUTE;
			lATTRIBUTE.m_attribute = m_attribute.fight_all_attribute();
			lATTRIBUTE.m_fight = m_attribute.fight();
			adata.m_attribute = lATTRIBUTE;
		}

		ENUM_UNIT type()
		{
			return m_type;
		}

		i64_actorid id()
		{
			return m_entityid;
		}

		int32_t lastmovetime()
		{
			return m_lastmovetime;
		}

		unitrole* role()
		{
			return m_type == ROLE_UNIT ? (unitrole*)this : NULL;
		}

		unitmonster* monster()
		{
			return m_type == MONSTER_UNIT ? (unitmonster*)this : NULL;
		}

		int32_t module_attribute(enum_attribute aenum, enum_module_attribute amodule = em_attribute_root)
		{
			return m_attribute.fight_attribute(attribute_attack, amodule);
		}

		//### ����
		// [����]
		int32_t attack()
		{
			return module_attribute(attribute_attack);
		}
		// [����]
		int32_t defense()
		{
			return module_attribute(attribute_defense);
		}
		// [Ѫ��]
		int32_t hp()
		{
			return module_attribute(attribute_hp);
		}
		// [ŭ��]
		int32_t anger()
		{
			return module_attribute(attribute_anger);
		}
		// [�ٶ�]
		int32_t speed()
		{
			return module_attribute(attribute_speed);
		}

		
	};
}