#include "unitbase.h"



namespace ngl
{
	// ����
	class unitregion : public unit
	{
	public:

	};
}