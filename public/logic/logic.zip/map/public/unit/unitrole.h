#pragma once

#include "unitbase.h"


namespace ngl
{
	// #### ��ҵ�ս����λ����
	class unitrole : public unit
	{
	public:
		unitrole(i64_actorid aentityid, int32_t agateway, attribute& aattribute) :
			unit(ROLE_UNIT, aentityid, aattribute),
			m_gateway(agateway)
		{}

		i32_gatewayid m_gateway;
		// ��Ұ�������б�
		std::set<i64_actorid> m_carelist;

		const std::set<i64_actorid>& carelist()
		{
			return m_carelist;
		}

		// ### �Ƿ񻹿�����corelist������
		bool ispushcorelist()
		{
			return m_carelist.size() < unit_corelist_maxcount;
		}

		static int32_t corelistmax()
		{
			return unit_corelist_maxcount;
		}

		int32_t corelistcount()
		{
			return m_carelist.size();
		}

		bool push_corelist(i64_actorid acoreid)
		{
			return m_carelist.insert(acoreid).second;
		}

		void remove_corelist(i64_actorid acoreid)
		{
			m_carelist.erase(acoreid);
		}

		void clear_corelist()
		{
			m_carelist.clear();
		}

		i32_gatewayid gateway()
		{
			return m_gateway;
		}

		template <typename T>
		static void send_client(T& adata)
		{
			if (m_gateway != 0)
			{
				actor_forward<T, true, T> pro;
				pro.m_uid.push_back(actor_guid::id(m_entityid));
				pro.m_area.push_back(actor_guid::area(m_entityid));
				pro.set_data(&adata);
				sendtoserver(m_gateway, pro, actor_guid::moreactor(), actor_guid::moreactor());
			}
		}
	};
}