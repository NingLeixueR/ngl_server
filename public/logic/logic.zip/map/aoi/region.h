#pragma once

#include "aoi.h"

namespace ngl
{

	

}