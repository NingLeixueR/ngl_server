#pragma once


#include "unit.h"
#include "aoi.h"
#include <set>
#include <map>
#include <vector>

namespace ngl
{

	class grid
	{
		std::map<ENUM_UNIT, std::set<i64_actorid>> m_unitlist;
	public:
		// ####�������
		bool enter(unit* aunit)
		{
			return m_unitlist[aunit->type()].insert(aunit->id()).second;
		}
		// ####�뿪����
		void leave(unit* aunit)
		{
			m_unitlist[aunit->type()].erase(aunit->id());
		}

		const std::set<i64_actorid>& get_unitlist(ENUM_UNIT aunit)
		{
			return m_unitlist[aunit];
		}
	};


	class grids :public aoi
	{
		std::vector<grid> m_grid;
	public:
		virtual void init(int32_t aw, int32_t al, int32_t anx, int32_t any)
		{
			aoi::init(aw, al, anx, any);
			m_grid.resize(grid_count());
		}

		bool enter(unit* aunit, int32_t ax, int32_t ay)
		{
			return enter(aunit, id(ax, ay));
		}

		bool enter(unit* aunit, int32_t agid)
		{
			if (agid >= m_grid.size())
				return false;
			return m_grid[agid].enter(aunit);
		}

		void leave(unit* aunit, int32_t ax, int32_t ay)
		{
			leave(aunit, id(ax, ay));
		}

		void leave(unit* aunit, int32_t agid)
		{
			if (agid >= m_grid.size())
				return;
			return m_grid[agid].leave(aunit);
		}

		grid* get_grid(int32_t agid)
		{
			if (agid >= m_grid.size())
				return NULL;
			return &m_grid[agid];
		}

		grid* get_grid(int32_t ax, int32_t ay)
		{
			uint32_t agid = id(ax, ay);
			if (agid >= m_grid.size())
				return NULL;
			return &m_grid[agid];
		}
	};
}