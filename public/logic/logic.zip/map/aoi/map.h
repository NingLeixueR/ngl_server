#pragma once

#include "unit.h"
#include "aoi.h"
#include "grid.h"
#include "tools.h"

namespace ngl
{
	class aoimap
	{
		grids m_grids;
		MapTab* m_tab; // ��ͼ������������
		std::map<i64_actorid, unitrole*> m_roleunit;
		std::map<i64_actorid, unitmonster*> m_monsterunit;
	public:
		unitrole* roleunit(i64_actorid aid)
		{
			unitrole** lp = tools::findmap/*<i64_actorid, unit_role*>*/(m_roleunit, aid);
			return lp == NULL ? NULL : *lp;
		}

		unitmonster* monsterunit(i64_actorid aid)
		{
			unitmonster** lp = tools::findmap/*<i64_actorid, unit_monster*>*/(m_monsterunit, aid);
			return lp == NULL ? NULL : *lp;
		}

		unit* find_unit(i64_actorid aid)
		{
			unit* lpunit = roleunit(aid);
			if (lpunit != NULL)
				return lpunit;
			lpunit = monsterunit(aid);
			if (lpunit != NULL)
				return lpunit;
			return NULL;
		}

		bool init_map(int32_t amapid)
		{
			m_tab = manage_csv<MapTab>::get(amapid);
			if (m_tab == NULL)
			{
				LogError("manage_csv<MapTab>::get(%) == NULL", amapid);
				return false;
			}
			m_grids.init(m_tab->m_w, m_tab->m_l, m_tab->m_aoi_x_size, m_tab->m_aoi_y_size);
			return true;
		}

		bool enter(unit* aunit, uint32_t agid)
		{
			if (!m_grids.enter(aunit, agid))
			{
				LogError("aoi_map::enter(tid=%,id=%,agid=%) fail", m_tab->id, aunit->id(), agid);
				return false;
			}

			if (aunit->type() == ROLE_UNIT)
			{
				unitrole* lprole = (unitrole*)aunit;
				// #### 9���� ���������ĸ����в��ҿ�������corelist�Ľ�ɫ
				std::set<int32_t> lset;
				m_grids.idaround_list(agid, lset);
				role_enter(lprole, lset);
			}

			return true;
		}

		bool enter(unit* aunit, uint32_t ax, uint32_t ay)
		{
			return enter(aunit, m_grids.id(ax, ay));
		}

		void leave_map(unit* aunit)
		{
			leave(aunit);
		}

		void leave(unit* aunit)
		{
			int lgrid = m_grids.id(aunit->m_pos.x, aunit->m_pos.y);
			m_grids.leave(aunit, lgrid);

			if (aunit->type() == ROLE_UNIT)
			{
				role_leave(aunit);
			}
		}

		void role_leave(unit* aunit)
		{
			std::map<i32_gatewayid, std::vector<i64_actorid>> lmassset; // key GateWay Id
			unitrole* lprole = (unitrole*)aunit;

			LOGIC_MAP_LEAVE_VIEW pro;
			pro.m_entitylist.push_back(lprole->m_entityid);

			for (i64_actorid id : lprole->carelist())
			{
				unitrole* lpunit = roleunit(id);
				lpunit->remove_corelist(lprole->id());
				lmassset[lpunit->gateway()].push_back(id);
			}

			for (int64_t id : lprole->carelist())
			{
				unitrole* lpunit = roleunit(id);
				enter(lpunit, lpunit->m_pos.x, lpunit->m_pos.y);
			}

			lprole->clear_corelist();

			actor_base::send_client(lmassset, pro);
		}

		bool role_enter(unit* aunit, std::set<int32_t>& agidset)
		{
			unitrole* lprole = (unitrole*)aunit;
			grid* lgrid = NULL;
			std::map<i32_gatewayid, std::vector<i64_actorid>> lmassset; // key GateWay Id

			LOGIC_MAP_ENTITY_VIEW pro;
			ENTITY lentity;
			lprole->entity(lentity);
			pro.m_entitylist.push_back(lentity);

			LOGIC_MAP_ENTITY_VIEW proenterview;
			for (int32_t id : agidset)
			{
				lgrid = m_grids.get_grid(id);
				if (lgrid == NULL)
				{
					LogError("m_grid.get_grid(tid=%,id=%,agid=%) fail", m_tab->id, aunit->id(), id);
					return false;
				}
				const std::set<i64_actorid>& ltempset = lgrid->get_unitlist(ROLE_UNIT);
				for (i64_actorid id : ltempset)
				{
					if (lprole->ispushcorelist() == false)
						return true;
					unitrole* lpunit = roleunit(id);
					if (lpunit == NULL || lpunit->ispushcorelist() == false)
						continue;
					if (lprole->push_corelist(id) && lpunit->push_corelist(id))
					{
						// #### send to client
						lmassset[lpunit->gateway()].push_back(id);

						ENTITY ltempentity;
						lpunit->entity(lentity);
						proenterview.m_entitylist.push_back(lentity);
					}

				}
			}

			actor_base::send_client(lprole->gateway(), lprole->id(), proenterview);
			actor_base::send_client(lmassset, pro);

			return true;
		}

		bool move(unit* aunit, int32_t ax, int32_t ay)
		{
			int32_t ldistance = aoi::distance(ax, ay, aunit->m_pos.x, aunit->m_pos.y);
			int32_t interval = localtime::gettime() - aunit->lastmovetime();
			if (ldistance > interval * aunit->speed())
				return false;
			if (aunit->type() == ROLE_UNIT)
			{
				unitrole* lprole = (unitrole*)aunit;
				int32_t lgid = m_grids.id(ax, ay);
				int32_t loldgid = m_grids.id(aunit->m_pos.x, aunit->m_pos.y);
				lprole->m_pos.x = ax;
				lprole->m_pos.y = ay;

				if (lgid != loldgid)
				{
					std::set<int32_t> lgidset;
					std::set<int32_t> loldgidset;
					m_grids.idaround_list(lgid, lgidset);
					m_grids.idaround_list(loldgid, loldgidset);

					LOGIC_MAP_ENTITY_VIEW pro;
					ENTITY lentity;
					lprole->entity(lentity);
					pro.m_entitylist.push_back(lentity);

					std::map<i32_gatewayid, std::vector<int64_t>> lmassset; // key GateWay Id

					// leave
					std::set<unitrole*> llevelset;
					unitrole* lprole = (unitrole*)aunit;
					for (int64_t id : lprole->m_carelist)
					{
						unitrole* lpunit = roleunit(id);
						uint32_t lgid = m_grids.id(lpunit->m_pos.x, lpunit->m_pos.y);
						if (loldgidset.find(lgid) != loldgidset.end() && lgidset.find(id) == lgidset.end())
						{
							llevelset.insert(lpunit);
							lpunit->remove_corelist(lprole->id());
							lprole->remove_corelist(lpunit->id());
							lmassset[lpunit->gateway()].push_back(id);
						}
					}

					enter(aunit, ax, ay);

					for (unitrole* lunit : llevelset)
					{
						enter(lunit, lunit->m_pos.x, lunit->m_pos.y);
					}

					actor_base::send_client(lmassset, pro);
				}
			}
		}
	};
}