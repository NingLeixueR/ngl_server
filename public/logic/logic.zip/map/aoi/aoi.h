#pragma once

#include <iostream>
#include <cstdint>
#include <set>
#include <vector>
#include <list>
#include <string>
#include <map>
#include <numeric>

namespace ngl
{
	class aoi
	{
	protected:
		int32_t m_nx;  // x���������
		int32_t m_ny;  // y���������
		int32_t m_w;   // x�����
		int32_t m_l;   // y�᳤��
	public:
		virtual void init(int32_t aw, int32_t al, int32_t anx, int32_t any)
		{ 
			m_w = aw; 
			m_l = al;
			m_nx = anx;
			m_ny = any; 
		}

		// ��������
		inline int32_t grid_count() 
		{ 
			return m_nx * m_ny; 
		}

		// ���ӿ���
		inline int32_t grid_w() 
		{ 
			return m_w / m_nx; 
		}

		// ���ӳ���
		inline int32_t grid_l() 
		{ 
			return m_l / m_ny; 
		}

		// ͨ�����ӱ�Ż�ȡ idx
		inline int32_t idx(uint32_t aid) 
		{ 
			return aid % m_nx; 
		}

		// ͨ�����ӱ�Ż�ȡ idy
		inline int32_t idy(uint32_t aid) 
		{ 
			return aid / m_nx; 
		}

		// ͨ��idx,idy��ȡ ���ӱ��
		inline int32_t id(uint32_t aidx, uint32_t aidy) 
		{ 
			return aidy * m_nx + aidx; 
		}

		// ͨ��x y�����������ӱ��
		inline int32_t idbyxy(float ax, float ay) 
		{ 
			return id(std::ceil(ax / grid_w()), std::ceil(ay / grid_l())); 
		}

		inline void idaround_list(int32_t aid, std::set<int32_t>& avec)
		{
			int lx = idx(aid);
			int ly = idy(aid);
			//���Ͻ�
			int ltx = lx - 1;
			int lty = ly - 1;

			avec.insert(aid);

			for (int i = 0; i < 3; ++i)
			{
				int ltempx = ltx + i;
				if (ltempx < 0 && ltempx >= m_nx)
				{
					continue;
				}
				for (int j = 0; j < 3; ++j)
				{
					int ltempy = lty + j;
					if (ltempy >= 0 && ltempy < m_ny)
					{
						if (ltempx != lx && ltempy != ly)
						{
							avec.insert(id(ltempx, ltempy));
						}
					}
				}
			}
		}

		// ���ݸ��ӱ�ż�����Χ�Ź�����
		inline void idaround_foreach(int32_t aid, const std::function<bool(int32_t)>& afun)
		{
			int lx = idx(aid);
			int ly = idy(aid);
			//���Ͻ�
			int ltx = lx - 1;
			int lty = ly - 1;

			if (!afun(aid))
				return;

			for (int i = 0; i < 3; ++i)
			{
				int ltempx = ltx + i;
				if (ltempx < 0 && ltempx >= m_nx)
				{
					continue;
				}
				for (int j = 0; j < 3; ++j)
				{
					int ltempy = lty + j;
					if (ltempy >= 0 && ltempy < m_ny)
					{
						if (ltempx != lx && ltempy != ly)
							if (!afun(id(ltempx, ltempy)))
								return;
					}
				}
			}
		}


		static float distance(float ax1, float ay1, float ax2, float ay2)
		{
			float lx = ax2 - ax1;
			float ly = ay2 - ay1;
			return std::sqrt(lx * lx + ly * ly);
		}

		static float distance(const VECTOR2& apos1, const VECTOR2& apos2)
		{
			return distance(apos1.x.get(), apos1.y.get(), apos2.x.get(), apos2.y.get());
		}
	};


	enum enum_region
	{
		eregion_circular,	// ����:Բ��
		eregion_rect,		// ����:����
		eregion_annular,	// ����:����
	};
	// ����
	class region
	{
		enum_region m_region;
		bool m_activation; // �Ƿ񼤻�
	public:
		region(enum_region eregion) :
			m_region(eregion),
			m_activation(false)
		{}

		void set_activation(bool aactivation)
		{
			m_activation = aactivation;
		}

		static bool check(region* areg, const VECTOR2& apos)
		{
			if (areg->m_activation == false)
				return false;
			return areg->check(apos);
		}

	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR2&) = 0;
	};
	
	// ����:Բ��
	class region_circular : public region
	{
		VECTOR2 m_core; // ����
		float m_radius; // �뾶

		region_circular() :
			region(eregion_circular),
			m_radius(0.0f)
		{
		}

	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR2& apos)
		{
			return !(m_radius < aoi::distance(m_core, apos));
		}
	};

	// ����:����
	class region_rect : public region
	{
		VECTOR2 m_lefttop;		// ����
		VECTOR2 m_rightdown;	// ����

		region_rect() :
			region(eregion_rect)
		{
		}

	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR2& apos)
		{
			if (apos.x.get() < m_lefttop.x)
				return false;
			if (apos.y.get() > m_lefttop.y)
				return false;
			if (apos.x.get() > m_rightdown.x)
				return false;
			if (apos.y.get() < m_rightdown.y)
				return false;
			return true;
		}
	};


	// ����:����
	class region_annular
		: public region
	{
		VECTOR2 m_core; // ����
		float m_inner_circle_radius; // ��Ȧ�뾶
		float m_outer_ring_radius; // ��Ȧ�뾶

		region_annular() :
			region(eregion_annular),
			m_inner_circle_radius(0.0f),
			m_outer_ring_radius(0.0f)
		{
		}

	private:
		// ## �����Ƿ���������
		virtual bool check(const VECTOR2& apos)
		{
			float ldistance = aoi::distance(m_core, apos);
			if (ldistance < m_inner_circle_radius)
				return false;
			if (ldistance > m_outer_ring_radius)
				return false;
			return true;
		}
	};

}
