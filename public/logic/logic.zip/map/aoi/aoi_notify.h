#pragma once

#include "notify.h"


namespace ngl
{
	// ��������
	struct notify_parm_enter_region : public notify_parm<notify_parm_enter_region>
	{
		DEF_CONSTRUCTION(notify_parm_enter_region, m_region(0), m_actor(0));

		int m_region;
		i64_actorid m_actor;
	};

	// �뿪����
	struct notify_parm_leave_region : public notify_parm<notify_parm_leave_region>
	{
		DEF_CONSTRUCTION(notify_parm_leave_region, m_region(0), m_actor(0));

		int m_region;
		i64_actorid m_actor;

	};


	class aoi_notify
	{
		aoi_notify() {}
	public:
		aoi_notify& GetInstance()
		{
			static aoi_notify ltemp;
			return ltemp;
		}
		void init()
		{
			notify_parm<notify_parm_enter_region>::rfun(&aoi_notify::enter_region, this);
			notify_parm<notify_parm_leave_region>::rfun(&aoi_notify::leave_region, this);
		}

		bool enter_region(notify_parm_enter_region* anotify)
		{
			std::cout << "enter_region:" << anotify->m_region << std::endl;
			return true;
		}

		bool leave_region(notify_parm_leave_region* anotify)
		{
			std::cout << "leave_region:" << anotify->m_region << std::endl;
			return true;
		}
	};
}