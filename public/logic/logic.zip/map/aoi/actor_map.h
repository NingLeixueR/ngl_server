#pragma once

#include "actor_manage.h"
#include "net.h"
#include "game_logic.h"
#include "game_worldgame.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
#include "actor_timer.h"

#include "map.h"

namespace ngl
{
	class actor_map : public actor<actor_map>
	{
		static uint32_t makeid(uint16_t amaptid, uint16_t aid)
		{
			uint32_t ltemp;
			((uint16_t*)(&ltemp))[0] = amaptid;
			((uint16_t*)(&ltemp))[1] = aid;
			return ltemp;
		}
		static uint16_t maptid(uint32_t aid)
		{
			return ((uint16_t*)(&aid))[0];
		}
		static uint16_t tid(uint32_t aid)
		{
			return ((uint16_t*)(&aid))[1];
		}

		map m_map;
	public:
		actor_map(i16_area aarea, int16_t amaptid, int16_t amapnumber, void* adata) :
			actor<actor_map>(ACTOR_MAP, aarea, makeid(amaptid, amapnumber), 0x7fffffff, false, 1024, 0x7fffffff)
		{
			if (m_map.init_map(amaptid) == false)
			{
				LogError("m_map.init_map(%)", amaptid);
			}
		}

		virtual void init() {}

		static void actor_register();

		virtual void actor_loaddb() {}
		virtual ~actor_map() {}
		virtual void loaddb_finish() {}

		enum { ACTOR_TYPE = ACTOR_MAP };

		virtual bool isactivity()
		{
			return actor<actor_map>::isactivity();
		}
		// ��ʱ��
		bool timer_handle(int athread, pack* apack, timerparm& adata)
		{
			return true;
		}
	};

}