#include "bag.h"
#include "mail.h"
#include "item.h"
#include "actor_role.h"

namespace ngl
{
	bag::bag():
		db_modular<ENUM_DB_BAG, DB_BAG, actor_role>()
		, m_maxitemid(0)
		, m_sync(false)
	{ 
		//Assert(arole != NULL); 
	}

	/*void bag::set(const bag& adata)
	{
		m_itemindex = adata.m_itemindex;
		m_maxitemid = adata.m_maxitemid;
		m_sync = adata.m_sync;
	}*/

	ngl::map<int32_t, Item>& bag::data() { return db()->m_data; }

	void bag::init_data()
	{
		manage_csv<ItemTab>::load();
		ngl::map<int32_t, Item>& lmap = data();
		for (auto& item : lmap)
		{
			ItemTab* tab = manage_csv<ItemTab>::get(item.second.m_tid);
			if (tab == NULL)
				continue;
			m_itemindex[item.second.m_index] = item.first;
		}
		if (!lmap.empty())
			m_maxitemid = lmap.rbegin()->first;
	}

	bool bag::freeindex(std::pair<int, map_itor>& apair)
	{
		if (apair.first == 0)
			apair.second = m_itemindex.begin();
		auto itor = apair.second;
		int i = apair.first;
		for (; i < db()->m_maxitemindex &&
			itor != m_itemindex.end(); ++i, ++itor)
		{
			if (itor->first != i)
			{
				apair.first = i;
				apair.second = itor;
				return true;
			}
		}
		if (i < db()->m_maxitemindex)
		{
			apair.first = i;
			apair.second = itor;
			return true;
		}
		return false;
	}

	Item* bag::indexitem(int aindex)
	{
		if (aindex < 0 || aindex >= db()->m_maxitemindex)
			return NULL;
		auto itor = m_itemindex.find(aindex);
		if (itor == m_itemindex.end())
			return NULL;
		int itemid = itor->second;
		ngl::map<int32_t, Item>& lmap = data();
		auto itemitor = lmap.find(itemid);
		if (itemitor == lmap.end())
			return NULL;
		return &itemitor->second;
	}

	bool bag::additem(int tid, int count, std::vector<Item>* avecitem/* = NULL*/)
	{
		LOGIC_BAG_ADDITEM_SYNC pro;

		std::vector<Item> lmailitem;

		ItemTab* tab = manage_csv<ItemTab>::get(tid);
		if (tab == NULL)
			return false;
		if (tab->stack == 0 || tab->stack == 1)
		{
			// �������ѵ� ������Ʒ
			std::pair<int, map_itor> lpair;
			ngl::map<int32_t, Item>& lmap = data();
			Item* lpitem = nullptr;
			bool bfree = false;
			for (int i = 0; i < count; ++i)
			{
				bfree = freeindex(lpair);
				if (bfree)
				{// �п�λ
					lpitem = &lmap[++m_maxitemid];
					std::vector<Item> lv;
					if (!create_item::create(tid, 1, lv))
						return false;
					*lpitem = *lv.begin();
				}
				else
				{// û��λ �ʼ���
					std::vector<Item> lv;
					if (!create_item::create(tid, 1, lv))
						return false;
					lmailitem.insert(lmailitem.end(), lv.begin(), lv.end());
				}				
				if (m_sync && bfree)
					pro.m_addlist[m_maxitemid] = *lpitem;
				if (avecitem != NULL)
					avecitem->push_back(*lpitem);
			}
			if (m_sync && !pro.m_addlist.empty())
				actor()->send_client(pro);
			if (!lmailitem.empty())
				actor()->m_mail.addmail(1, NULL, lmailitem);
			return true;
		}
		else if (tab->stack < 0)
		{
			// ���޶ѵ�
			ngl::map<int32_t, Item>& lmap = data();
			for (auto& item : lmap)
			{
				if (item.second.m_tid == tid)
				{
					item.second.m_count += count;
					if (m_sync)
					{
						pro.m_addlist[item.first] = item.second;
						((actor_role*)m_actor)->send_client(pro);
					}
					if (avecitem != NULL)
						avecitem->push_back(item.second);
					return true;
				}
			}
			std::pair<int, map_itor> lpair;
			if (freeindex(lpair))
			{// �п�λ
				Item& litem = lmap[++m_maxitemid];
				litem.m_id = m_maxitemid;
				litem.m_tid = tid;
				litem.m_count = count;
				if (m_sync)
				{
					pro.m_addlist[m_maxitemid] = litem;
					((actor_role*)m_actor)->send_client(pro);
				}
				if (avecitem != NULL)
					avecitem->push_back(litem);
			}
			else
			{//û��λ �ʼ���
				std::vector<Item> lv;
				if (!create_item::create(tid, count, lv))
					return false;
				lmailitem.insert(lmailitem.end(), lv.begin(), lv.end());
				actor()->m_mail.addmail(1, NULL, lmailitem);
				if (avecitem != NULL)
					avecitem->insert(avecitem->end(), lv.begin(), lv.end());
			}
			return true;
		}
		else
		{
			ngl::map<int32_t, Item>& lmap = data();
			for (auto& item : lmap)
			{
				if (item.second.m_tid == tid)
				{
					if (item.second.m_count < tab->stack)
					{
						int lcount = tab->stack - item.second.m_count;
						if (count > lcount)
						{
							item.second.m_count += lcount;
							count -= lcount;
							if (m_sync)
								pro.m_addlist[item.first] = item.second;
							if (avecitem != NULL)
								avecitem->push_back(item.second);
						}
						else
						{
							item.second.m_count += count;
							if (m_sync)
							{
								pro.m_addlist[item.first] = item.second;
								((actor_role*)m_actor)->send_client(pro);
							}
							if (avecitem != NULL)
								avecitem->push_back(item.second);
							return true;
						}
					}

				}
			}
			while (count > 0)
			{
				std::pair<int, map_itor> lpair;
				if (freeindex(lpair))
				{// �п�λ
					Item& litem = lmap[++m_maxitemid];
					litem.m_id = m_maxitemid;
					litem.m_tid = tid;
					if (count > tab->stack)
					{
						count -= tab->stack;
						litem.m_count = tab->stack;
						if (m_sync)
							pro.m_addlist[m_maxitemid] = litem;
						if (avecitem != NULL)
							avecitem->push_back(litem);
					}
					else
					{
						litem.m_count = count;
						if (m_sync)
						{
							pro.m_addlist[m_maxitemid] = litem;
							((actor_role*)m_actor)->send_client(pro);
						}
						if (avecitem != NULL)
							avecitem->push_back(litem);
						break;
					}
				}
				else
				{//û��λ �ʼ���
					lmailitem.push_back(Item());
					Item& litem = *lmailitem.rbegin();
					std::vector<Item> lv;
					if (!create_item::create(tid, count, lv))
						return false;
					for (Item& item : lv)
						lmailitem.push_back(item);
					if (avecitem != NULL)
						avecitem->push_back(litem);
				}
			}

			if(!lmailitem.empty())
				actor()->m_mail.addmail(1, NULL, lmailitem);
			return true;
		}
	}

	bool bag::delitem(int aid, int count, EItemConsume src)
	{
		ngl::map<int32_t, Item>& lmap = data();
		auto itor = lmap.find(aid);
		if (itor == lmap.end())
			return false;
		if (itor->second.m_count < count)
			return false;
		itor->second.m_count -= count;
		if (itor->second.m_count <= 0)
		{
			m_itemindex.erase(itor->second.m_index);
			lmap.erase(itor);
			if (!lmap.empty())
				m_maxitemid = lmap.rbegin()->first;
		}

		if (m_sync)
		{
			LOGIC_BAG_DELITEM_SYNC pro;
			BAG_DEL_ITEM ltemp;
			ltemp.m_itemid = aid;
			ltemp.m_itemcount = count;
			pro.m_dellist.push_back(ltemp);
			((actor_role*)m_actor)->send_client(pro);
		}

		return true;
	}

	bool bag::delitembytid(int tid, int count, EItemConsume src)
	{
		LOGIC_BAG_DELITEM_SYNC pro;
		ItemTab* tab = manage_csv<ItemTab>::get(tid);
		if (tab == NULL)
			return false;
		ngl::map<int32_t, Item>& lmap = data();
		for (auto itor = lmap.begin(); itor != lmap.end();)
		{
			if (itor->second.m_tid == tid)
			{
				if (count < itor->second.m_count)
				{
					itor->second.m_count -= count;
					count = 0;
					if (m_sync)
					{
						BAG_DEL_ITEM ltemp;
						ltemp.m_itemid = itor->first;
						ltemp.m_itemcount = count;
						pro.m_dellist.push_back(ltemp);
					}
					break;
				}
				else
				{
					if (m_sync)
					{
						BAG_DEL_ITEM ltemp;
						ltemp.m_itemid = itor->first;
						ltemp.m_itemcount = itor->second.m_count;
						pro.m_dellist.push_back(ltemp);
					}
					count -= itor->second.m_count;
					m_itemindex.erase(itor->second.m_index);
					itor = lmap.erase(itor);
					if (!lmap.empty())
						m_maxitemid = lmap.rbegin()->first;
					continue;
				}
			}
			++itor;
		}
		if (m_sync)
			((actor_role*)m_actor)->send_client(pro);
		return count <= 0;
	}

	bool bag::delitembyindex(int aindex, int count, EItemConsume src)
	{
		auto itorindex = m_itemindex.find(aindex);
		if (itorindex == m_itemindex.end())
			return false;
		return delitem(itorindex->second, count, src);
	}

	bool bag::check(int aid, int count)
	{
		ngl::map<int32_t, Item>& lmap = data();
		auto itor = lmap.find(aid);
		if (itor == lmap.end())
			return false;
		if (itor->second.m_count < count)
			return false;
		return true;
	}

	bool bag::checkbytid(int tid, int count)
	{
		ItemTab* tab = manage_csv<ItemTab>::get(tid);
		if (tab == NULL)
			return false;
		ngl::map<int32_t, Item>& lmap = data();
		for (auto& item : lmap)
		{
			if (item.second.m_tid == tid)
			{
				if (count < item.second.m_count)
				{
					return true;
				}
				else
				{
					count -= item.second.m_count;
				}
			}
		}
		return count <= 0;
	}

	bool bag::checkbyindex(int aindex, int count)
	{
		auto itorindex = m_itemindex.find(aindex);
		if (itorindex == m_itemindex.end())
			return false;
		return check(itorindex->second, count);
	}

	bool bag::additem(std::map<int, int>& amap, EItemSrc src/* = EItemSrcNoraml*/, std::vector<Item>* avecitem /*= NULL*/)
	{
		for (auto& item : amap)
			additem(item.first, item.second, src, avecitem);
		return true;
	}

	bool bag::additem(int tid, int count, EItemSrc src/* = EItemSrcNoraml*/, std::vector<Item>* avecitem /*= NULL*/)
	{
		LogLocalInfo("AddItem Start RoleId[%] Tid[%] Count[%] Src[%]", m_actor->id(), tid, count, (int)src);
		bool ret = additem(tid, count, avecitem);
		LogLocalInfo("AddItem Finish RoleId[%] Tid[%] Count[%] Src[%] [%]", m_actor->id(), tid, count, (int)src, ret ? "success" : "fail");
		return ret;
	}
}