#pragma once

#include <vector>
#include <map>
#include <string>

#include "manage_csv.h"
#include "nlog.h"
#include "tools.h"
#include "game_db.h"
#include "splite.h"

namespace ngl
{
	struct tDropTab_weight
	{
		int itemid;
		int min;
		int max;
		int weight;
		tDropTab_weight():itemid(0), min(0), max(0), weight(0) {}
		tDropTab_weight(int aitemid, int amin, int amax, int aweight) :itemid(aitemid), min(amin), max(amax), weight(aweight) {}
	};

	struct tDropTab_probability
	{
		int itemid;
		int min;
		int max;
		int probability;
		tDropTab_probability() :itemid(0), min(0), max(0), probability(0) {}
		tDropTab_probability(int aitemid, int amin, int amax, int aprobability) :itemid(aitemid), min(amin), max(amax), probability(aprobability) {}
	};

	struct tDropTab
	{
		DropTab* m_tab;

		std::vector<tDropTab_weight>		m_dataweight;				// Ȩ�� tuple:itemid*min*max*weight
		std::vector<tDropTab_probability>	m_dataprobability;			// ���� tuple:itemid*min*max*probability
		tDropTab() :m_tab(NULL) {}
	};

	class tDrop
	{
		static std::map<int, tDropTab> m_data;
	public:
		static void init()
		{
			manage_csv<DropTab>::load();
			for (auto& item : manage_csv<DropTab>::tablecsv)
			{
				tDropTab ltDropTab;
				{//Ȩ��
					std::vector<std::string> ltemp;
					splite::division(item.second.m_dataweight.c_str(), "#", ltemp);
					for (std::string& litem : ltemp)
					{
						std::vector<int> lv;
						splite::division(litem.c_str(), "*", lv);
						ltDropTab.m_dataweight.push_back(tDropTab_weight(lv[0], lv[1], lv[2], lv[3]));
					}
				}

				{//����
					std::vector<int> lv;
					std::vector<std::string> ltemp;
					splite::division(item.second.m_dataprobability.c_str(), "#", ltemp);
					for (std::string& litem : ltemp)
					{
						std::vector<int> lv;
						splite::division(litem.c_str(), "*", lv);
						ltDropTab.m_dataprobability.push_back(tDropTab_probability(lv[0], lv[1], lv[2], lv[3]));
					}
				}
				m_data[item.first] = ltDropTab;
			}
		}
		static tDropTab* tab(int aid)
		{
			return tools::findmap<int, tDropTab>(m_data, aid);
		}
	};

	class actor_role;

	class drop
	{
	public:
		static void init()
		{
			tdrop:init();
		}

		//bool check(int aid, int acount);
		static bool probability(int aid, std::map<int, int>& amap);
		static bool weight(int aid, std::map<int, int>& amap);
		static bool droplist(int aid, int acount, std::map<int, int>& amap);
		static bool use(actor_role* arole, int aid, int acount, EItemSrc src, std::vector<Item>* avecitem = NULL);
	};

}

