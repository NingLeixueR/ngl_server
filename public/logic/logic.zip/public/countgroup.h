#pragma once

#include "db_modular.h"
#include "manage_csv.h"
#include "triggertime.h"

namespace ngl
{
	class actor_role;
	struct tCountGroupTab
	{
		CountGroupTab* m_tab;
		std::vector<int> m_consumeid;
	};


	class tCountGroup
	{
		static std::map<int, tCountGroupTab> m_data;
	public:
		static void init()
		{
			if (m_data.empty())
			{
				manage_csv<CountGroupTab>::load();
				for (auto& item : manage_csv<CountGroupTab>::tablecsv)
				{
					tCountGroupTab ltemp;
					splite::division(item.second.m_consumeid.c_str(), "*", ltemp.m_consumeid);
					Try
					{
						Assert(ltemp.m_consumeid.size() == 2);

					}Catch;
				}
			}
		}

		static tCountGroupTab* tab(int32_t acountgroupid)
		{
			auto itor = m_data.find(acountgroupid);
			if (itor == m_data.end())
				return NULL;
			return &itor->second;
		}
	};

	struct countgroup_parm : public triggertime_base_parm
	{
		int m_id;
		countgroup_parm(int aperiodtimeid, int atid) :
			triggertime_base_parm(aperiodtimeid), m_id(atid)
		{}
	};

	class countgroup : public db_modular<ENUM_DB_COUNTGROUP, DB_COUNTGROUP, actor_role>
	{
	public:
		countgroup() 
			:db_modular<ENUM_DB_COUNTGROUP, DB_COUNTGROUP, actor_role>() {}

		virtual void init_data();

		void init_fun();

		ngl::map<int32_t, COUNTGROUP>& get()
		{
			return db()->m_countgroup;
		}
		actor_role* role() { return actor(); }

		int32_t gettimenode(int32_t acountgroupid)
		{
			tCountGroupTab* tab = tCountGroup::tab(acountgroupid);
			if (tab == NULL)
				return -1;
			return tab->m_tab->m_triggertimeid;
		}

		// ��ȡ������ û��������
		COUNTGROUP* get_countgroup(int acountgroupid);

		// ��������
		bool check(int acountgroupid, int acount, bool aconsume = true);

		// ʹ�ô�����
		bool use(int acountgroupid, int acount, bool aconsume = true);

		void reset(int acountgroupid);

		void reset();
	};

}

