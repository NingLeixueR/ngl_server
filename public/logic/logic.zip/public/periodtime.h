#pragma once

#include <map>
#include <list>
#include <boost/function.hpp>

#include "manage_csv.h"
#include "nlog.h"
#include "db_modular.h"
#include "triggertime.h"

namespace ngl
{
	// ʱ��� ������ʼ  �������� �ж��Ƿ��ڿ�ʼ��
	//manage_csv<PeriodTimeNodeTab>::load();

	struct periodtime_parm : public triggertime_base_parm
	{
		int m_id;
		bool m_start;
		periodtime_parm(int aperiodtimeid, int atid, bool astart) :
			triggertime_base_parm(aperiodtimeid),m_id(atid), m_start(astart)
		{}
	};

	// ʱ��δ���
	class periodtime : public db_modular<ENUM_DB_PERIOD_TIMENODE, DB_PERIOD_TIMENODE, actor_role>
	{
	public:
		periodtime() :db_modular<ENUM_DB_PERIOD_TIMENODE, DB_PERIOD_TIMENODE, actor_role>() {}

		virtual void init_data()
		{
			manage_csv<PeriodTimeNodeTab>::load();
			init_fun();
		}

		ngl::map<int32_t, PERIOD_TIMENODE>& get()
		{
			return db()->m_periodtimenode;
		}

		actor_role* role() { return actor(); }


		void init_fun();

		void periodtimefun(PeriodTimeNodeTab* atab, periodtime_parm* aparm);
		
		void init_fun(PeriodTimeNodeTab& atab);

	};
}