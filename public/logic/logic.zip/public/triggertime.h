#pragma once

#include <map>
#include <list>
#include <boost/function.hpp>

#include "manage_csv.h"
#include "nlog.h"
#include "db_modular.h"
#include "actor_timer.h"
#include "splite.h"

namespace ngl
{
	class actor_role;

	struct tTimeNodeTab
	{
		TimeNodeTab* m_tab;
		int m_week;
		int m_hour;
		int m_minute;
		tTimeNodeTab() :m_tab(NULL), m_week(-1), m_hour(-1), m_minute(-1) {}
	};

	class tTimeNode
	{
		static std::map<int, tTimeNodeTab> m_data;
	public:
		static void init()
		{
			if (!m_data.empty())
				return;
			manage_csv<TimeNodeTab>::load();
			for (auto& item : manage_csv<TimeNodeTab>::tablecsv)
			{
				tTimeNodeTab ltemp;
				ltemp.m_tab = &item.second;
				std::vector<int> lv;
				splite::division(item.second.m_data.c_str(), ":", lv);
				Try
				{
					Assert(lv.size() >= 2);
					ltemp.m_tab = &item.second;
					if (lv.size() == 2 && item.second.m_type == ETIMENODE_EVERYDAY)
					{
						ltemp.m_hour = lv[0];
						ltemp.m_minute = lv[1];
					}
					else if (lv.size() == 3 && item.second.m_type == ETIMENODE_EVERYWEEK)
					{
						ltemp.m_week = lv[0];
						ltemp.m_hour = lv[1];
						ltemp.m_minute = lv[2];
					}
					else if (lv.size() == 3 && item.second.m_type == ETIMENODE_SPECIFIDE_TIME_PERIOD)
					{
						ltemp.m_week = lv[0];
						ltemp.m_hour = lv[1];
						ltemp.m_minute = lv[2];
					}
					else continue;
					m_data[item.first] = ltemp;
				}Catch;
			}
		}

		// ����ʱ����id������´δ�����ʱ��
		static bool trigger_time(int aid, time_t& atime)
		{
			auto itor = m_data.find(aid);
			if (itor == m_data.end())
				return false;

			if (itor->second.m_tab->m_type == ETIMENODE_EVERYDAY)
			{
				int lnow = localtime::gettime();
				atime = localtime::getsecond2time(itor->second.m_hour, itor->second.m_minute);
				if (lnow >= atime)
					atime += localtime::DAY_SECOND;
				//ת��Ϊ����
				atime *= 1000;
				return true;
			}
			else if (itor->second.m_tab->m_type == ETIMENODE_EVERYWEEK)
			{
				int lnow = localtime::gettime();
				atime = localtime::getweekday(itor->second.m_week, itor->second.m_hour, itor->second.m_minute);
				if (lnow >= atime)
					atime += localtime::WEEK_SECOND;
				//ת��Ϊ����
				atime *= 1000;
				return true;
			}
			return false;
		}

	};

	class tTriggerTimeNode
	{
	public:
		static void init()
		{
			manage_csv<TriggerTimeNodeTab>::load();
		}

		// ����ʱ����id������´δ�����ʱ��
		static bool trigger_time(int aid, time_t& atime)
		{
			return tTimeNode::trigger_time(aid, atime);
		}
	};

	struct triggertime_base_parm
	{
		int m_triggertimeid;
		triggertime_base_parm(int atriggertimeid) :m_triggertimeid(atriggertimeid) {}
	};

	// �ɴ���n�εĴ���ʱ���
	class triggertime : public db_modular<ENUM_DB_TRIGGER_TIMENODE, DB_TRIGGER_TIMENODE, actor_role>
	{
	public:
	private:
		std::map<ENUM_TRIGGER_TIME, std::function<void(void*)>> m_fundata;
		std::map<int, std::set<int>> m_utcid;
		//std::function<bool(int, pack*, const triggertime_parm&)> m_triggerfun;
	public:
		triggertime();

		ngl::object_map<int32_t, TRIGGER_TIMENODE>& get() { return db()->m_triggertimenode; }
		actor_role* role() { return actor(); }

		// ע�ᴥ���ص�
		void register_fun(int atype, const std::function<void(void*)>& afun);
		TRIGGER_TIMENODE* get(int atriggerid);
		std::function<void(void*)> getfun(int atriggerid);
		bool triggerfun(const timerparm& aparm);
		bool triggertime_start(int atid, void* adata);
	};

}
