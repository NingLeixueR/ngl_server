#include "consume.h"
#include "bag.h"

namespace ngl
{
	std::map<int, tConsumeTab> tConsume::m_data;

	void tConsume::init()
	{
		manage_csv<ConsumeTab>::load();
		for (auto& item : manage_csv<ConsumeTab>::tablecsv)
		{
			tConsumeTab ltemp;
			std::vector<std::string> lvstr;
			splite::division(item.second.m_data.c_str(), "#", lvstr);
			for (std::string& itemstr : lvstr)
			{
				std::vector<int> lv;
				splite::division(itemstr.c_str(), "*", lv);
				Try
				{
					Assert(lv.size() >= 2);
					ltemp.m_data[lv[0]] += lv[1];
				}Catch;
			}
			m_data.insert(std::make_pair(item.first, ltemp));
		}
	}

	tConsumeTab* tConsume::tab(int aid)
	{
		return tools::findmap<int, tConsumeTab>(m_data, aid);
	}

	bool consume::check(actor_role* arole, int aid, int acount)
	{
		tConsumeTab* tab = tConsume::tab(aid);
		if (tab == NULL)
			return false;
		//tab->m_data;
		for (auto& item : tab->m_data)
		{
			if (!arole->m_bag.checkbytid(item.first, item.second* acount))
			{
				return false;
			}
		}
		return true;		
	}
	bool consume::use(actor_role* arole, int aid, int acount, EItemConsume src)
	{
		if (!check(arole, aid, acount))
			return false;
		tConsumeTab* tab = tConsume::tab(aid);
		if (tab == NULL)
			return false;
		for (auto& item : tab->m_data)
		{
			if (!arole->m_bag.delitembytid(item.first, item.second* acount, src))
			{
				return false;
			}
		}
		return true;
	}
}
