#include "periodtime.h"
#include "actor_role.h"

namespace ngl
{
	void periodtime::init_fun()
	{
		role()->m_triggertime.register_fun(ENUM_TRIGGER_TIME_PERIODTIME, [this](void* aparm)
			{
				periodtime_parm* lparm = (periodtime_parm*)aparm;
				if (lparm->m_start == false)
					return;
				PeriodTimeNodeTab* tab = manage_csv<PeriodTimeNodeTab>::get(lparm->m_id);
				if (tab == NULL)
					return;
				periodtimefun(tab, lparm);
			});
		// ## ������
		manage_csv<PeriodTimeNodeTab>::foreach([this](PeriodTimeNodeTab& atab)
			{
				init_fun(atab);
			});
	}
	void periodtime::init_fun(PeriodTimeNodeTab& atab)
	{
		TriggerTimeNodeTab* tabstart = ngl::manage_csv<TriggerTimeNodeTab>::get(atab.m_triggertimeidstart);
		TriggerTimeNodeTab* tabfinish = ngl::manage_csv<TriggerTimeNodeTab>::get(atab.m_triggertimeidfinish);
		if (tabstart == NULL || tabfinish == NULL)
			return;
		role()->m_triggertime.triggertime_start(atab.m_triggertimeidstart, new periodtime_parm(atab.m_triggertimeidstart, atab.id, true));
		role()->m_triggertime.triggertime_start(atab.m_triggertimeidfinish, new periodtime_parm(atab.m_triggertimeidfinish, atab.id, false));
	}

	void periodtime::periodtimefun(PeriodTimeNodeTab* atab, periodtime_parm* aparm)
	{
		switch (atab->m_type)
		{
		case ENUM_PERIOD_TIME_TEST:
			//### Test do sth
			break;
		default:
			break;
		}
	}
}