#pragma once

#include "db_modular.h"
#include "manage_csv.h"

namespace ngl
{
	//actor_dbclient<ENUM_DB_ROLE, DB_ROLE> m_role;
	class actor_role;
	class roleinfo : public db_modular<ENUM_DB_ROLE, DB_ROLE, actor_role>
	{
	public:
		roleinfo() 
			:db_modular<ENUM_DB_ROLE, DB_ROLE, actor_role>() 
		{}

		virtual void init_data() {}

		DB_ROLE* get()
		{
			return db();
		}

	};
}