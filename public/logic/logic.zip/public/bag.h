#pragma once

#include "csvtable.h"
#include "game_db.h"
#include "nlog.h"
#include "db_modular.h"

namespace ngl
{
	class actor_role;
	class bag : public db_modular<ENUM_DB_BAG, DB_BAG, actor_role>
	{
		std::map<int, int> m_itemindex;	// key indexid value itemid
		int m_maxitemid;
		bool m_sync;
	public:
		bag();

		//void set(const bag& adata);

		virtual void init_data();

		ngl::map<int32_t, Item>& data();

		// �״λ�ȡ����λ��
		using map_itor = std::map<int, int>::iterator;
		bool freeindex(std::pair<int, map_itor>& apair);
		// ����ָ��λ�û�ȡ��Ʒ
		Item* indexitem(int aindex);
		// ��չ����
		void extend(int aadd) { db()->m_maxitemindex += aadd; }
		// �����Ƿ�ͬ���������ݱ仯
		void set_sync(bool abool) { m_sync = abool; }
		// ͨ��tid������Ʒ Item.m_id == -1 ˵�����ʼ����� 
		bool additem(int tid, int count, std::vector<Item>* avecitem = NULL);

		bool additem(std::map<int, int>& amap, EItemSrc src = EItemSrcNoraml, std::vector<Item>* avecitem = NULL);

		bool additem(int tid, int count, EItemSrc src = EItemSrcNoraml, std::vector<Item>* avecitem = NULL);

		bool delitem(int aid, int count, EItemConsume src);
		bool delitembytid(int tid, int count, EItemConsume src);
		bool delitembyindex(int aindex, int count, EItemConsume src);

		bool check(int aid, int count);
		bool checkbytid(int tid, int count);
		bool checkbyindex(int aindex, int count);
	};

}

