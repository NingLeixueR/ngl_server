#include "coolddown.h"
#include "manage_csv.h"

namespace ngl
{
	coolddown::coolddown() :
		db_modular<ENUM_DB_COOLDDOWN, DB_COOLDDOWN, actor_role>()
	{
		
	}
	void coolddown::init_data()
	{
		manage_csv<CooldDownTab>::load();
	}
	ngl::map<int32_t, COOLDDOWN>& coolddown::data() { return db()->m_coolddown; }

	COOLDDOWN* coolddown::get(int acooldownid)
	{
		auto itor = data().find(acooldownid);
		if (itor == data().end())
			return NULL;
		return &itor->second;
	}

	COOLDDOWN* coolddown::create(int acooldownid)
	{
		return &data()[acooldownid];
	}

	// �����ȴ���� 
	// true ����ȴ false��ȴ��
	bool coolddown::check(COOLDDOWN* lcool)
	{
		if (lcool == NULL)
			return true;
		time_t lnow = localtime::gettimems();
		if (lnow < lcool->m_releaseinterval_endms)
			return false;
		if (lcool->m_chargingcount <= 0)
		{
			if (lcool->m_charginginterval_endms != 0 && lnow > lcool->m_charginginterval_endms)
			{
				CooldDownTab* ltab = tab(lcool->m_coolddownid);
				if (ltab == NULL)
					return false;
				int32_t linterval = lnow - lcool->m_charginginterval_endms;
				int32_t lcount = linterval / ltab->m_charginginterval;
				if (lcount >= (ltab->m_chargingcount - lcool->m_chargingcount))
				{
					lcool->m_chargingcount = ltab->m_chargingcount;
				}
				else
				{
					lcool->m_chargingcount += lcount;
				}
				lcool->m_charginginterval_endms = 0;
				return true;
			}
			else
				return false;
		}
		return true;
	}
	bool coolddown::check(int acooldownid)
	{
		return check(get(acooldownid));
	}

	CooldDownTab* coolddown::tab(int aid)
	{
		return manage_csv<CooldDownTab>::get(aid);
	}

	bool coolddown::set_coolddown(int acooldownid)
	{
		CooldDownTab* ltab = tab(acooldownid);
		if (ltab == NULL)
			return false;
		COOLDDOWN* lcool = create(acooldownid);
		if (!check(lcool))
			return false;
		lcool->m_coolddownid = acooldownid;
		lcool->m_releaseinterval_endms = localtime::gettimems() + ltab->m_releaseinterval;
		lcool->m_charginginterval_endms = localtime::gettimems() + ltab->m_charginginterval;
		--lcool->m_chargingcount.data();
		return true;
	}
}