#include "item.h"

namespace ngl
{
	std::array<create_item*, EItemTypeCount> create_item::m_data;

	item_noraml& g_item_noraml = item_noraml::getInstance();
}