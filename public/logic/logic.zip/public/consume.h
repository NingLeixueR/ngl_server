#pragma once

#include <vector>
#include <map>
#include <string>

#include "actor_role.h"
#include "manage_csv.h"
#include "nlog.h"
#include "tools.h"

namespace ngl
{
	struct tConsumeTab
	{
		ConsumeTab* m_tab;
		std::map<int, int> m_data;
		tConsumeTab() :m_tab(NULL) {}
	};

	class tConsume
	{
		static std::map<int, tConsumeTab> m_data;
	public:
		static void init();
		static tConsumeTab* tab(int aid);
	};

	class consume
	{
	public:
		static void init() { tConsume::init(); }
		static bool check(actor_role* arole, int aid, int acount);
		static bool use(actor_role* arole, int aid, int acount, EItemConsume src);
	};

}
