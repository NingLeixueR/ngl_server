#pragma once

#include "csvtable.h"
#include "manage_csv.h"
#include "game_db.h"
#include <array>

namespace ngl
{

	class create_item
	{
		static std::array<create_item*, EItemTypeCount> m_data;
		virtual bool made(int tid, int count, std::vector<Item>& aitem) = 0;
	protected:
		create_item(EItemType atype) { m_data[atype] = this; }
	public:
		static bool create(int tid, int count, std::vector<Item>& aitem)
		{
			ItemTab* tab = manage_csv<ItemTab>::get(tid);
			if (tab == NULL)
				return false;
			int lindex = (int)tab->type;
			return m_data[lindex]->made(tid, count, aitem);
		}
	};


	class item_noraml : public create_item
	{
		item_noraml() :
			create_item(ENoramlItem)
		{}
	public:
		static item_noraml& getInstance()
		{
			static item_noraml ltemp;
			return ltemp;
		}

		virtual bool made(int tid, int count, std::vector<Item>& aitem)
		{
			Item lItem;
			lItem.m_id = -1;
			lItem.m_tid = tid;
			lItem.m_count = count;
			aitem.push_back(lItem);	
			return true;
		}
	};

}
