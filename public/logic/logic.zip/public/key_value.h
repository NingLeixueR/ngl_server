#pragma once 


#include "game_db.h"
#include "actor_protocol.h"
#include "db_modular.h"

namespace ngl
{
	enum EDB_KEYVALUE
	{
		EDB_KV_ID,
	};

	template <typename TACTOR>
	class key_value : public db_modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>
	{
	public:
		key_value(TACTOR* aactor, EDB_KEYVALUE aenum) :modular<ENUM_DB_KEYVALUE, DB_KEYVALUE, TACTOR>(aactor, aenum){}

		bool get(std::string& astr)
		{
			DB_KEYVALUE* ret = db();
			if (ret == NULL)
				return false;

			astr = ret->m_data;
			return true;
		}

		bool get(int& astr)
		{
			DB_KEYVALUE* ret = m_data.m_dbdata;
			if (ret == NULL)
				return false;

			astr = boost::lexical_cast<int>(ret->m_data);
			return true;
		}

		void set(std::string& astr)
		{
			DB_KEYVALUE*& ret = m_data.m_dbdata;
			if (ret == NULL)
			{
				m_data.add(m_actor, EKEY);
			}
			ret->m_data = astr;
			m_data.savedb();
			return true;
		}

		void set(int astr)
		{
			DB_KEYVALUE*& ret = m_data.m_dbdata;
			if (ret == NULL)
			{
				DB_KEYVALUE ltemp;
				ltemp.m_data = boost::lexical_cast<std::string>(astr);
				m_data.add(id(), ltemp);
			}
			else
			{
				ret->m_data = boost::lexical_cast<std::string>(astr);
				m_data.savedb();
			}		
			return;
		}

	};


}
