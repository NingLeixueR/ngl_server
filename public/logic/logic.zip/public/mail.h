#pragma once 

#include "db_modular.h"
#include <cstdint>

namespace ngl
{
	template <typename ACTOR_T>
	class mail : public db_modular<ENUM_DB_MAIL, DB_MAIL, ACTOR_T>
	{
		int m_maxid;
	public:
		mail() 
			: db_modular<ENUM_DB_MAIL, DB_MAIL, ACTOR_T>(), m_maxid(0)
		{}
		
		virtual void init_data()
		{
			ngl::map<int32_t, MAIL_DATA>& lmap = get_mail();
			if(!lmap.empty())
				m_maxid = lmap.rbegin()->first;
		}

		ngl::map<int32_t, MAIL_DATA>& get_mail()
		{
			return db()->m_mail;
		}

		bool addmail(int atid, const char* aparm, std::vector<Item>& aitem)
		{
			ngl::map<int32_t, MAIL_DATA>& lmap = get_mail();
			MAIL_DATA& ldata = lmap[++m_maxid];
			ldata.m_createutc = localtime::gettime();
			if (aparm != NULL)
				ldata.m_parm = aparm;
			ldata.m_tid = atid;
			ldata.m_item = aitem;
			return true;
		}

		bool addmail(int atid, const char* aparm, int adropid)
		{
			std::map<int, int> litem;
			drop::droplist(adropid, 1, litem);
			std::vector<Item> lv;
			for (auto& item : litem)
			{
				if (!create_item::create(item.first, item.second, lv))
					return false;
			}
			return addmail(atid, aparm, lv);
		}
	};
}
