#include "triggertime.h"
#include "actor_role.h"


namespace ngl
{
	std::map<int, tTimeNodeTab> tTimeNode::m_data;

	bool triggertime::triggertime_start(int atid, void* adata)
	{
		TriggerTimeNodeTab* tab = manage_csv<TriggerTimeNodeTab>::get(atid);
		if (tab == NULL)
			return false;
		auto itorfun = m_fundata.find(tab->m_type);
		if (itorfun == m_fundata.end())
			return false;//û��ע��ص����账��
		ngl::map<int32_t, TRIGGER_TIMENODE>& lmap = get();
		TRIGGER_TIMENODE* lptemp = NULL;
		auto itor = lmap.find(tab->id);
		if (itor == lmap.end())
		{
			lptemp = &(itor->second);
			lptemp->m_triggerid = tab->id;
			if (!tTriggerTimeNode::trigger_time(tab->id, lptemp->m_next_trigger_time.data()))
				lptemp->m_next_trigger_time = -1;
		}
		else
			lptemp = &lmap[tab->id];

		if (lptemp->m_next_trigger_time == -1)
			return true;

		// ### ���Ӷ�ʱ��
		timerparm lparm;
		lparm.m_type = timerparm::ET_ROLE_TRIGGERTIME;
		lparm.m_timerid = 0;
		lparm.m_ms = lptemp->m_next_trigger_time - (localtime::gettime() * 1000);
		lparm.m_intervalms = 0;
		lparm.m_count = 1;
		lparm.set_parm(adata);
		actor()->set_timer(lparm);
		return false;
	}

	

	triggertime::triggertime() :db_modular<ENUM_DB_TRIGGER_TIMENODE, DB_TRIGGER_TIMENODE, actor_role>()
	{
	}
	void triggertime::register_fun(int atype, const std::function<void(void*)>& afun)
	{
		m_fundata[(ENUM_TRIGGER_TIME)atype] = afun;
	}

	TRIGGER_TIMENODE* triggertime::get(int atriggerid)
	{
		ngl::map<int32_t, TRIGGER_TIMENODE>& lamp = get();
		auto itor = lamp.find(atriggerid);
		if (itor == lamp.end())
			return NULL;
		return &itor->second;
	}
	std::function<void(void*)> triggertime::getfun(int atriggerid)
	{
		TriggerTimeNodeTab* tab = manage_csv<TriggerTimeNodeTab>::get(atriggerid);
		if (tab == NULL)
			return NULL;
		auto itor = m_fundata.find(tab->m_type);
		if (itor == m_fundata.end())
			return NULL;
		return itor->second;
	}

	bool triggertime::triggerfun(const timerparm& aparm)
	{
		if (aparm.m_parm == NULL)
			return false;
		triggertime_base_parm* lparm = (triggertime_base_parm*)aparm.m_parm.get();
		TriggerTimeNodeTab* tab = manage_csv<TriggerTimeNodeTab>::get(lparm->m_triggertimeid);
		if (tab == NULL)
			return true;
		TRIGGER_TIMENODE* lpttimenode = get(lparm->m_triggertimeid);
		if (lpttimenode == NULL)
			return true;
		// ### ������������
		++lpttimenode->m_trigger_count.data();

		auto lfun = getfun(lparm->m_triggertimeid);
		if (lfun != NULL)
			lfun(lparm);

		return true;
	}

	//void triggertime::init_fun()
	//{
	//	// ## ������
	//	//role()->m_countgroup.
	//	// ## ������
	//	manage_csv<TriggerTimeNodeTab>::foreach([this](TriggerTimeNodeTab& atab)
	//		{
	//			init_fun(atab);
	//		});
	//}
}