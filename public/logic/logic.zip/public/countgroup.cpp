#include "countgroup.h"
#include "consume.h"
#include "actor_role.h"

namespace ngl
{
	std::map<int, tCountGroupTab> tCountGroup::m_data;

	COUNTGROUP* countgroup::get_countgroup(int acountgroupid)
	{
		ngl::map<int32_t, COUNTGROUP>& lmap = get();
		auto itor = lmap.find(acountgroupid);
		if (itor == lmap.end())
		{
			COUNTGROUP& lret = lmap[acountgroupid];
			lret.m_count = 0;
			lret.m_countgroupid = acountgroupid;
			return &lret;
		}
		return &itor->second;
	}

	void countgroup::init_data()
	{
		tCountGroup::init();
		init_fun();
	}

	void countgroup::init_fun()
	{
		role()->m_triggertime.register_fun(ENUM_TRIGGER_TIME_COUNTGROUP, [this](void* apram)
			{
				countgroup_parm* lparm = (countgroup_parm*)apram;
				tCountGroupTab* tab = tCountGroup::tab(lparm->m_id);
				if (tab != NULL)
					reset(tab->m_tab->id);
			});
		// ## ������
		manage_csv<CountGroupTab>::foreach([this](CountGroupTab& atab)
			{
				role()->m_triggertime.triggertime_start(atab.m_triggertimeid, new countgroup_parm(atab.m_triggertimeid, atab.id));
			});
	}

	bool countgroup::check(int acountgroupid, int acount, bool aconsume)
	{
		CountGroupTab* tab = manage_csv<CountGroupTab>::get(acountgroupid);
		if (tab == NULL)
			return false;
		int lsumcount = tab->m_usecount + (aconsume ? tab->m_consumeid.size() : 0);
		COUNTGROUP* lcountgroup = get_countgroup(acountgroupid);
		Assert(lcountgroup != NULL);
		return lsumcount > lcountgroup->m_count + acount;
	}

	bool countgroup::use(int acountgroupid, int acount, bool aconsume)
	{
		if (!check(acountgroupid, acount, aconsume))
			return false;
		tCountGroupTab* tab = tCountGroup::tab(acountgroupid);
		if (tab == NULL)
			return false;
		COUNTGROUP* lcountgroup = get_countgroup(acountgroupid);
		Assert(lcountgroup != NULL);
		int lbuycount = lcountgroup->m_count - tab->m_tab->m_usecount;
		if (lbuycount + acount > tab->m_consumeid.size())
			return false;
		if (lbuycount >= 0)
		{
			// ������Ʒ��ȡ����
			if (consume::use(actor(), lbuycount, acount, EItemConsumeNoraml))
				return false;
		}
		lcountgroup->m_count += acount;
		return true;
	}

	void countgroup::reset(int acountgroupid)
	{
		LOGIC_COUNTGROUP_SYNC pro;
		COUNTGROUP ltemp;
		ltemp.m_count = 0;
		ltemp.m_countgroupid = acountgroupid;
		pro.m_countgroup.push_back(ltemp);
		((actor_role*)m_actor)->send_client(pro);

		get().erase(acountgroupid);
	}

	void countgroup::reset()
	{
		LOGIC_COUNTGROUP_SYNC pro;
		ngl::map<int32_t, COUNTGROUP>& lmap = get();
		COUNTGROUP ltemp;
		for (auto& item : lmap)
		{
			ltemp.m_count = 0;
			ltemp.m_countgroupid = item.second.m_countgroupid;
			pro.m_countgroup.push_back(ltemp);
		}
		((actor_role*)m_actor)->send_client(pro);
		lmap.clear();
	}

}