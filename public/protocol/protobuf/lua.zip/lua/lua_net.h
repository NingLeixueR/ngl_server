#pragma once
#include "net.pb.h"
#include "actor_db_client.h"
#include <sol/sol.hpp>
#include "lua_db.h"
namespace ngl{

    class PROBUFF_LOGIC_ERROR
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ERROR* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ERROR*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {




            alua->new_usertype<PROBUFF_LOGIC_ERROR>(
			"PROBUFF_LOGIC_ERROR"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ERROR& temp) { temp.~PROBUFF_LOGIC_ERROR(); })
			, sol::base_classes, sol::bases<>()
            , "m_errnum", &PROBUFF_LOGIC_ERROR::m_errnum
            , "set_m_errnum", &PROBUFF_LOGIC_ERROR::set_m_errnum

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ERROR>("PROBUFF_LOGIC_ERROR");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ERROR";
        }

        PROBUFF_LOGIC_ERROR(PB::PROBUFF_LOGIC_ERROR* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ERROR(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ERROR() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ERROR() :
		    PROBUFF_LOGIC_ERROR(true)
	    {
	    }

        ~PROBUFF_LOGIC_ERROR()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ERROR& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ERROR& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_errnum()
	        {
		        return getconst().m_errnum();
	        }

	        inline void set_m_errnum(const int32_t& avalue)
	        {
		        get().set_m_errnum(avalue);
	        }


};

    class PROBUFF_LOGIC_ERROR_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ERROR_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ERROR_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ERROR_RESPONSE>(
			"PROBUFF_LOGIC_ERROR_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ERROR_RESPONSE& temp) { temp.~PROBUFF_LOGIC_ERROR_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_errnum", &PROBUFF_LOGIC_ERROR_RESPONSE::m_errnum
            , "set_m_errnum", &PROBUFF_LOGIC_ERROR_RESPONSE::set_m_errnum
            , "m_errmessage", &PROBUFF_LOGIC_ERROR_RESPONSE::m_errmessage
            , "set_m_errmessage", &PROBUFF_LOGIC_ERROR_RESPONSE::set_m_errmessage

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ERROR_RESPONSE>("PROBUFF_LOGIC_ERROR_RESPONSE");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ERROR_RESPONSE";
        }

        PROBUFF_LOGIC_ERROR_RESPONSE(PB::PROBUFF_LOGIC_ERROR_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ERROR_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ERROR_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ERROR_RESPONSE() :
		    PROBUFF_LOGIC_ERROR_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_ERROR_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ERROR_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ERROR_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_errnum()
	        {
		        return getconst().m_errnum();
	        }

	        inline void set_m_errnum(const int32_t& avalue)
	        {
		        get().set_m_errnum(avalue);
	        }


            inline const std::string m_errmessage()
	        {
		        return getconst().m_errmessage();
	        }

	        inline void set_m_errmessage(const std::string& avalue)
	        {
		        get().set_m_errmessage(avalue);
	        }


};

    class PROBUFF_LOGIC_GET_TIME
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_GET_TIME* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_GET_TIME*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_TIME>(
			"PROBUFF_LOGIC_GET_TIME"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_GET_TIME& temp) { temp.~PROBUFF_LOGIC_GET_TIME(); })
			, sol::base_classes, sol::bases<>()

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_TIME>("PROBUFF_LOGIC_GET_TIME");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_GET_TIME";
        }

        PROBUFF_LOGIC_GET_TIME(PB::PROBUFF_LOGIC_GET_TIME* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_GET_TIME(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_GET_TIME() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_GET_TIME() :
		    PROBUFF_LOGIC_GET_TIME(true)
	    {
	    }

        ~PROBUFF_LOGIC_GET_TIME()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_GET_TIME& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_GET_TIME& getconst()const
	    {
		    return *m_data;
	    }
        

};

    class PROBUFF_LOGIC_GET_TIME_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_GET_TIME_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_GET_TIME_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_TIME_RESPONSE>(
			"PROBUFF_LOGIC_GET_TIME_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_GET_TIME_RESPONSE& temp) { temp.~PROBUFF_LOGIC_GET_TIME_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_utc", &PROBUFF_LOGIC_GET_TIME_RESPONSE::m_utc
            , "set_m_utc", &PROBUFF_LOGIC_GET_TIME_RESPONSE::set_m_utc

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_TIME_RESPONSE>("PROBUFF_LOGIC_GET_TIME_RESPONSE");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_GET_TIME_RESPONSE";
        }

        PROBUFF_LOGIC_GET_TIME_RESPONSE(PB::PROBUFF_LOGIC_GET_TIME_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_GET_TIME_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_GET_TIME_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_GET_TIME_RESPONSE() :
		    PROBUFF_LOGIC_GET_TIME_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_GET_TIME_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_GET_TIME_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_GET_TIME_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_utc()
	        {
		        return getconst().m_utc();
	        }

	        inline void set_m_utc(const int32_t& avalue)
	        {
		        get().set_m_utc(avalue);
	        }


};

    class PROBUFF_LOGIC_GET_NOTICE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_GET_NOTICE* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_GET_NOTICE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_NOTICE>(
			"PROBUFF_LOGIC_GET_NOTICE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_GET_NOTICE& temp) { temp.~PROBUFF_LOGIC_GET_NOTICE(); })
			, sol::base_classes, sol::bases<>()

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_NOTICE>("PROBUFF_LOGIC_GET_NOTICE");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_GET_NOTICE";
        }

        PROBUFF_LOGIC_GET_NOTICE(PB::PROBUFF_LOGIC_GET_NOTICE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_GET_NOTICE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_GET_NOTICE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_GET_NOTICE() :
		    PROBUFF_LOGIC_GET_NOTICE(true)
	    {
	    }

        ~PROBUFF_LOGIC_GET_NOTICE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_GET_NOTICE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_GET_NOTICE& getconst()const
	    {
		    return *m_data;
	    }
        

};

    class PROBUFF_LOGIC_GET_NOTICE_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;
		std::vector<db_notice> _db_notice;

    public:
        PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_NOTICE_RESPONSE>(
			"PROBUFF_LOGIC_GET_NOTICE_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_GET_NOTICE_RESPONSE& temp) { temp.~PROBUFF_LOGIC_GET_NOTICE_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "add_m_notices", &PROBUFF_LOGIC_GET_NOTICE_RESPONSE::add_m_notices
            , "m_notices", &PROBUFF_LOGIC_GET_NOTICE_RESPONSE::m_notices
            , "m_notices_size", &PROBUFF_LOGIC_GET_NOTICE_RESPONSE::m_notices_size
            , "clear_m_notices", &PROBUFF_LOGIC_GET_NOTICE_RESPONSE::clear_m_notices


			);
			db_notice::init(alua);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_GET_NOTICE_RESPONSE>("PROBUFF_LOGIC_GET_NOTICE_RESPONSE");
			db_notice::release(alua);

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_GET_NOTICE_RESPONSE";
        }

        PROBUFF_LOGIC_GET_NOTICE_RESPONSE(PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_GET_NOTICE_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_GET_NOTICE_RESPONSE() :
		    PROBUFF_LOGIC_GET_NOTICE_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_GET_NOTICE_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_GET_NOTICE_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline db_notice& add_m_notices()
            {
                _db_notice.push_back(db_notice(get().add_m_notices(), modified()));
                return *_db_notice.rbegin();
            }

            inline std::tuple<bool,db_notice> m_notices(int32_t aindex)
            {
                if(aindex >= 0 && aindex < _db_notice.size())
                {
                    return std::make_tuple(true, _db_notice[aindex]);
                }
                else
                {
                    static db_notice ltemp;
                    return std::make_tuple(false, ltemp);
                }
            }

            inline int32_t m_notices_size()
            {
                return getconst().m_notices_size();
            }

            inline void clear_m_notices()
            {
                return get().clear_m_notices();
            }
    

};

    class PROBUFF_LOGIC_ACOUNT_LOGIN
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ACOUNT_LOGIN* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ACOUNT_LOGIN*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ACOUNT_LOGIN>(
			"PROBUFF_LOGIC_ACOUNT_LOGIN"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ACOUNT_LOGIN& temp) { temp.~PROBUFF_LOGIC_ACOUNT_LOGIN(); })
			, sol::base_classes, sol::bases<>()
            , "m_account", &PROBUFF_LOGIC_ACOUNT_LOGIN::m_account
            , "set_m_account", &PROBUFF_LOGIC_ACOUNT_LOGIN::set_m_account
            , "m_password", &PROBUFF_LOGIC_ACOUNT_LOGIN::m_password
            , "set_m_password", &PROBUFF_LOGIC_ACOUNT_LOGIN::set_m_password

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ACOUNT_LOGIN>("PROBUFF_LOGIC_ACOUNT_LOGIN");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ACOUNT_LOGIN";
        }

        PROBUFF_LOGIC_ACOUNT_LOGIN(PB::PROBUFF_LOGIC_ACOUNT_LOGIN* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ACOUNT_LOGIN(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ACOUNT_LOGIN() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ACOUNT_LOGIN() :
		    PROBUFF_LOGIC_ACOUNT_LOGIN(true)
	    {
	    }

        ~PROBUFF_LOGIC_ACOUNT_LOGIN()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ACOUNT_LOGIN& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ACOUNT_LOGIN& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const std::string m_account()
	        {
		        return getconst().m_account();
	        }

	        inline void set_m_account(const std::string& avalue)
	        {
		        get().set_m_account(avalue);
	        }


            inline const std::string m_password()
	        {
		        return getconst().m_password();
	        }

	        inline void set_m_password(const std::string& avalue)
	        {
		        get().set_m_password(avalue);
	        }


};

    class PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE>(
			"PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE& temp) { temp.~PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_roleid", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::m_roleid
            , "set_m_roleid", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::set_m_roleid
            , "m_session", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::m_session
            , "set_m_session", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::set_m_session
            , "m_account", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::m_account
            , "set_m_account", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::set_m_account
            , "m_gatewayid", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::m_gatewayid
            , "set_m_gatewayid", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::set_m_gatewayid
            , "m_area", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::m_area
            , "set_m_area", &PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE::set_m_area

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE>("PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE";
        }

        PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE(PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE() :
		    PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int64_t m_roleid()
	        {
		        return getconst().m_roleid();
	        }

	        inline void set_m_roleid(const int64_t& avalue)
	        {
		        get().set_m_roleid(avalue);
	        }


            inline const std::string m_session()
	        {
		        return getconst().m_session();
	        }

	        inline void set_m_session(const std::string& avalue)
	        {
		        get().set_m_session(avalue);
	        }


            inline const std::string m_account()
	        {
		        return getconst().m_account();
	        }

	        inline void set_m_account(const std::string& avalue)
	        {
		        get().set_m_account(avalue);
	        }


            inline const int32_t m_gatewayid()
	        {
		        return getconst().m_gatewayid();
	        }

	        inline void set_m_gatewayid(const int32_t& avalue)
	        {
		        get().set_m_gatewayid(avalue);
	        }


            inline const int32_t m_area()
	        {
		        return getconst().m_area();
	        }

	        inline void set_m_area(const int32_t& avalue)
	        {
		        get().set_m_area(avalue);
	        }


};

    class PROBUFF_LOGIC_ROLE_LOGIN
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ROLE_LOGIN* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ROLE_LOGIN*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_LOGIN>(
			"PROBUFF_LOGIC_ROLE_LOGIN"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ROLE_LOGIN& temp) { temp.~PROBUFF_LOGIC_ROLE_LOGIN(); })
			, sol::base_classes, sol::bases<>()
            , "m_roleid", &PROBUFF_LOGIC_ROLE_LOGIN::m_roleid
            , "set_m_roleid", &PROBUFF_LOGIC_ROLE_LOGIN::set_m_roleid
            , "m_session", &PROBUFF_LOGIC_ROLE_LOGIN::m_session
            , "set_m_session", &PROBUFF_LOGIC_ROLE_LOGIN::set_m_session
            , "m_iscreate", &PROBUFF_LOGIC_ROLE_LOGIN::m_iscreate
            , "set_m_iscreate", &PROBUFF_LOGIC_ROLE_LOGIN::set_m_iscreate
            , "m_area", &PROBUFF_LOGIC_ROLE_LOGIN::m_area
            , "set_m_area", &PROBUFF_LOGIC_ROLE_LOGIN::set_m_area
            , "m_gatewayid", &PROBUFF_LOGIC_ROLE_LOGIN::m_gatewayid
            , "set_m_gatewayid", &PROBUFF_LOGIC_ROLE_LOGIN::set_m_gatewayid

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_LOGIN>("PROBUFF_LOGIC_ROLE_LOGIN");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ROLE_LOGIN";
        }

        PROBUFF_LOGIC_ROLE_LOGIN(PB::PROBUFF_LOGIC_ROLE_LOGIN* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ROLE_LOGIN(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ROLE_LOGIN() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ROLE_LOGIN() :
		    PROBUFF_LOGIC_ROLE_LOGIN(true)
	    {
	    }

        ~PROBUFF_LOGIC_ROLE_LOGIN()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ROLE_LOGIN& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ROLE_LOGIN& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int64_t m_roleid()
	        {
		        return getconst().m_roleid();
	        }

	        inline void set_m_roleid(const int64_t& avalue)
	        {
		        get().set_m_roleid(avalue);
	        }


            inline const std::string m_session()
	        {
		        return getconst().m_session();
	        }

	        inline void set_m_session(const std::string& avalue)
	        {
		        get().set_m_session(avalue);
	        }


            inline const bool m_iscreate()
	        {
		        return getconst().m_iscreate();
	        }

	        inline void set_m_iscreate(const bool& avalue)
	        {
		        get().set_m_iscreate(avalue);
	        }


            inline const int32_t m_area()
	        {
		        return getconst().m_area();
	        }

	        inline void set_m_area(const int32_t& avalue)
	        {
		        get().set_m_area(avalue);
	        }


            inline const int32_t m_gatewayid()
	        {
		        return getconst().m_gatewayid();
	        }

	        inline void set_m_gatewayid(const int32_t& avalue)
	        {
		        get().set_m_gatewayid(avalue);
	        }


};

    class PROBUFF_LOGIC_ROLE_SYNC
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ROLE_SYNC* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_ROLE_SYNC*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_SYNC>(
			"PROBUFF_LOGIC_ROLE_SYNC"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ROLE_SYNC& temp) { temp.~PROBUFF_LOGIC_ROLE_SYNC(); })
			, sol::base_classes, sol::bases<>()

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_SYNC>("PROBUFF_LOGIC_ROLE_SYNC");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ROLE_SYNC";
        }

        PROBUFF_LOGIC_ROLE_SYNC(PB::PROBUFF_LOGIC_ROLE_SYNC* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_ROLE_SYNC(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ROLE_SYNC() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ROLE_SYNC() :
		    PROBUFF_LOGIC_ROLE_SYNC(true)
	    {
	    }

        ~PROBUFF_LOGIC_ROLE_SYNC()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ROLE_SYNC& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ROLE_SYNC& getconst()const
	    {
		    return *m_data;
	    }
        

};

    class PROBUFF_LOGIC_ROLE_SYNC_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;
		db_role _db_role;
		db_bag _db_bag;

    public:
        PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_SYNC_RESPONSE>(
			"PROBUFF_LOGIC_ROLE_SYNC_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_ROLE_SYNC_RESPONSE& temp) { temp.~PROBUFF_LOGIC_ROLE_SYNC_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_role", &PROBUFF_LOGIC_ROLE_SYNC_RESPONSE::m_role
            , "m_bag", &PROBUFF_LOGIC_ROLE_SYNC_RESPONSE::m_bag

			);
			db_role::init(alua);
			db_bag::init(alua);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_ROLE_SYNC_RESPONSE>("PROBUFF_LOGIC_ROLE_SYNC_RESPONSE");
			db_role::release(alua);
			db_bag::release(alua);

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_ROLE_SYNC_RESPONSE";
        }

        PROBUFF_LOGIC_ROLE_SYNC_RESPONSE(PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)
			, _db_role(get().mutable_m_role(), modified())
			, _db_bag(get().mutable_m_bag(), modified())

	    {
	    }
        PROBUFF_LOGIC_ROLE_SYNC_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_ROLE_SYNC_RESPONSE() :
		    PROBUFF_LOGIC_ROLE_SYNC_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_ROLE_SYNC_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

	        inline db_role& m_role()
	        {
		        return _db_role;
	        }

	        inline db_bag& m_bag()
	        {
		        return _db_bag;
	        }

};

    class PROBUFF_LOGIC_BAG_SYNC
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_BAG_SYNC* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_BAG_SYNC*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_SYNC>(
			"PROBUFF_LOGIC_BAG_SYNC"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_BAG_SYNC& temp) { temp.~PROBUFF_LOGIC_BAG_SYNC(); })
			, sol::base_classes, sol::bases<>()

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_SYNC>("PROBUFF_LOGIC_BAG_SYNC");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_BAG_SYNC";
        }

        PROBUFF_LOGIC_BAG_SYNC(PB::PROBUFF_LOGIC_BAG_SYNC* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_BAG_SYNC(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_BAG_SYNC() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_BAG_SYNC() :
		    PROBUFF_LOGIC_BAG_SYNC(true)
	    {
	    }

        ~PROBUFF_LOGIC_BAG_SYNC()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_BAG_SYNC& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_BAG_SYNC& getconst()const
	    {
		    return *m_data;
	    }
        

};

    class PROBUFF_LOGIC_BAG_SYNC_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;
		db_bag _db_bag;

    public:
        PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_SYNC_RESPONSE>(
			"PROBUFF_LOGIC_BAG_SYNC_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_BAG_SYNC_RESPONSE& temp) { temp.~PROBUFF_LOGIC_BAG_SYNC_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_bag", &PROBUFF_LOGIC_BAG_SYNC_RESPONSE::m_bag

			);
			db_bag::init(alua);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_SYNC_RESPONSE>("PROBUFF_LOGIC_BAG_SYNC_RESPONSE");
			db_bag::release(alua);

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_BAG_SYNC_RESPONSE";
        }

        PROBUFF_LOGIC_BAG_SYNC_RESPONSE(PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)
			, _db_bag(get().mutable_m_bag(), modified())

	    {
	    }
        PROBUFF_LOGIC_BAG_SYNC_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_BAG_SYNC_RESPONSE() :
		    PROBUFF_LOGIC_BAG_SYNC_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_BAG_SYNC_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_BAG_SYNC_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

	        inline db_bag& m_bag()
	        {
		        return _db_bag;
	        }

};

    class PROBUFF_LOGIC_BAG_UPDATE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_BAG_UPDATE* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_BAG_UPDATE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_UPDATE>(
			"PROBUFF_LOGIC_BAG_UPDATE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_BAG_UPDATE& temp) { temp.~PROBUFF_LOGIC_BAG_UPDATE(); })
			, sol::base_classes, sol::bases<>()

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_UPDATE>("PROBUFF_LOGIC_BAG_UPDATE");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_BAG_UPDATE";
        }

        PROBUFF_LOGIC_BAG_UPDATE(PB::PROBUFF_LOGIC_BAG_UPDATE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_BAG_UPDATE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_BAG_UPDATE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_BAG_UPDATE() :
		    PROBUFF_LOGIC_BAG_UPDATE(true)
	    {
	    }

        ~PROBUFF_LOGIC_BAG_UPDATE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_BAG_UPDATE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_BAG_UPDATE& getconst()const
	    {
		    return *m_data;
	    }
        

};

    class PROBUFF_LOGIC_BAG_UPDATE_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;
		std::vector<item_material> _item_material;
		std::vector<item_card> _item_card;

    public:
        PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_UPDATE_RESPONSE>(
			"PROBUFF_LOGIC_BAG_UPDATE_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_BAG_UPDATE_RESPONSE& temp) { temp.~PROBUFF_LOGIC_BAG_UPDATE_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "add_m_materials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::add_m_materials
            , "m_materials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_materials
            , "m_materials_size", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_materials_size
            , "clear_m_materials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::clear_m_materials

            , "add_m_cards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::add_m_cards
            , "m_cards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_cards
            , "m_cards_size", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_cards_size
            , "clear_m_cards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::clear_m_cards

            , "add_m_delmaterials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::add_m_delmaterials
            , "clear_m_delmaterials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::clear_m_delmaterials
            , "set_m_delmaterials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::set_m_delmaterials
            , "m_delmaterials", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_delmaterials
            , "m_delmaterials_size", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_delmaterials_size
            , "add_m_delcards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::add_m_delcards
            , "clear_m_delcards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::clear_m_delcards
            , "set_m_delcards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::set_m_delcards
            , "m_delcards", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_delcards
            , "m_delcards_size", &PROBUFF_LOGIC_BAG_UPDATE_RESPONSE::m_delcards_size

			);
			item_material::init(alua);
			item_card::init(alua);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_BAG_UPDATE_RESPONSE>("PROBUFF_LOGIC_BAG_UPDATE_RESPONSE");
			item_material::release(alua);
			item_card::release(alua);

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_BAG_UPDATE_RESPONSE";
        }

        PROBUFF_LOGIC_BAG_UPDATE_RESPONSE(PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_BAG_UPDATE_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_BAG_UPDATE_RESPONSE() :
		    PROBUFF_LOGIC_BAG_UPDATE_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_BAG_UPDATE_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline item_material& add_m_materials()
            {
                _item_material.push_back(item_material(get().add_m_materials(), modified()));
                return *_item_material.rbegin();
            }

            inline std::tuple<bool,item_material> m_materials(int32_t aindex)
            {
                if(aindex >= 0 && aindex < _item_material.size())
                {
                    return std::make_tuple(true, _item_material[aindex]);
                }
                else
                {
                    static item_material ltemp;
                    return std::make_tuple(false, ltemp);
                }
            }

            inline int32_t m_materials_size()
            {
                return getconst().m_materials_size();
            }

            inline void clear_m_materials()
            {
                return get().clear_m_materials();
            }
    

            inline item_card& add_m_cards()
            {
                _item_card.push_back(item_card(get().add_m_cards(), modified()));
                return *_item_card.rbegin();
            }

            inline std::tuple<bool,item_card> m_cards(int32_t aindex)
            {
                if(aindex >= 0 && aindex < _item_card.size())
                {
                    return std::make_tuple(true, _item_card[aindex]);
                }
                else
                {
                    static item_card ltemp;
                    return std::make_tuple(false, ltemp);
                }
            }

            inline int32_t m_cards_size()
            {
                return getconst().m_cards_size();
            }

            inline void clear_m_cards()
            {
                return get().clear_m_cards();
            }
    

            inline void add_m_delmaterials(int32_t avalues)
	        {
		       get().add_m_delmaterials(avalues);
	        }

	        inline void clear_m_delmaterials()
	        {
		        get().clear_m_delmaterials();
	        }

	        inline bool set_m_delmaterials(int32_t aindex, const int32_t& avalues)
	        {
		        if (aindex >= 0 || aindex < getconst().m_delmaterials_size())
		        {
			        get().set_m_delmaterials(aindex, avalues);
			        return true;
		        }
		        return false;
	        }

	        inline std::tuple<bool,int32_t> m_delmaterials(int32_t aindex)
	        {
		        if (aindex >= 0 || aindex < m_delmaterials_size())
                {
                    return std::make_tuple(true, getconst().m_delmaterials()[aindex]);
                }
		        static int32_t ltemp;	
                return std::make_tuple(false, ltemp);
	        }

	        inline int32_t m_delmaterials_size()
	        {
		        return getconst().m_delmaterials_size();
	        }


            inline void add_m_delcards(int32_t avalues)
	        {
		       get().add_m_delcards(avalues);
	        }

	        inline void clear_m_delcards()
	        {
		        get().clear_m_delcards();
	        }

	        inline bool set_m_delcards(int32_t aindex, const int32_t& avalues)
	        {
		        if (aindex >= 0 || aindex < getconst().m_delcards_size())
		        {
			        get().set_m_delcards(aindex, avalues);
			        return true;
		        }
		        return false;
	        }

	        inline std::tuple<bool,int32_t> m_delcards(int32_t aindex)
	        {
		        if (aindex >= 0 || aindex < m_delcards_size())
                {
                    return std::make_tuple(true, getconst().m_delcards()[aindex]);
                }
		        static int32_t ltemp;	
                return std::make_tuple(false, ltemp);
	        }

	        inline int32_t m_delcards_size()
	        {
		        return getconst().m_delcards_size();
	        }


};

    class PROBUFF_LOGIC_CMD
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_CMD* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_CMD*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CMD>(
			"PROBUFF_LOGIC_CMD"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_CMD& temp) { temp.~PROBUFF_LOGIC_CMD(); })
			, sol::base_classes, sol::bases<>()
            , "m_cmdnum", &PROBUFF_LOGIC_CMD::m_cmdnum
            , "set_m_cmdnum", &PROBUFF_LOGIC_CMD::set_m_cmdnum
            , "add_m_parmstr", &PROBUFF_LOGIC_CMD::add_m_parmstr
            , "clear_m_parmstr", &PROBUFF_LOGIC_CMD::clear_m_parmstr
            , "set_m_parmstr", &PROBUFF_LOGIC_CMD::set_m_parmstr
            , "m_parmstr", &PROBUFF_LOGIC_CMD::m_parmstr
            , "m_parmstr_size", &PROBUFF_LOGIC_CMD::m_parmstr_size

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CMD>("PROBUFF_LOGIC_CMD");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_CMD";
        }

        PROBUFF_LOGIC_CMD(PB::PROBUFF_LOGIC_CMD* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_CMD(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_CMD() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_CMD() :
		    PROBUFF_LOGIC_CMD(true)
	    {
	    }

        ~PROBUFF_LOGIC_CMD()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_CMD& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_CMD& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_cmdnum()
	        {
		        return getconst().m_cmdnum();
	        }

	        inline void set_m_cmdnum(const int32_t& avalue)
	        {
		        get().set_m_cmdnum(avalue);
	        }


            inline void add_m_parmstr(std::string avalues)
	        {
		       get().add_m_parmstr(avalues);
	        }

	        inline void clear_m_parmstr()
	        {
		        get().clear_m_parmstr();
	        }

	        inline bool set_m_parmstr(int32_t aindex, const std::string& avalues)
	        {
		        if (aindex >= 0 || aindex < getconst().m_parmstr_size())
		        {
			        get().set_m_parmstr(aindex, avalues);
			        return true;
		        }
		        return false;
	        }

	        inline std::tuple<bool,std::string> m_parmstr(int32_t aindex)
	        {
		        if (aindex >= 0 || aindex < m_parmstr_size())
                {
                    return std::make_tuple(true, getconst().m_parmstr()[aindex]);
                }
		        static std::string ltemp;	
                return std::make_tuple(false, ltemp);
	        }

	        inline int32_t m_parmstr_size()
	        {
		        return getconst().m_parmstr_size();
	        }


};

    class PROBUFF_LOGIC_CHAT
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_CHAT* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::PROBUFF_LOGIC_CHAT*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CHAT>(
			"PROBUFF_LOGIC_CHAT"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_CHAT& temp) { temp.~PROBUFF_LOGIC_CHAT(); })
			, sol::base_classes, sol::bases<>()
            , "m_type", &PROBUFF_LOGIC_CHAT::m_type
            , "set_m_type", &PROBUFF_LOGIC_CHAT::set_m_type
            , "m_channelid", &PROBUFF_LOGIC_CHAT::m_channelid
            , "set_m_channelid", &PROBUFF_LOGIC_CHAT::set_m_channelid

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CHAT>("PROBUFF_LOGIC_CHAT");

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_CHAT";
        }

        PROBUFF_LOGIC_CHAT(PB::PROBUFF_LOGIC_CHAT* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_CHAT(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_CHAT() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_CHAT() :
		    PROBUFF_LOGIC_CHAT(true)
	    {
	    }

        ~PROBUFF_LOGIC_CHAT()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_CHAT& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_CHAT& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_type()
	        {
		        return getconst().m_type();
	        }

	        inline void set_m_type(const int32_t& avalue)
	        {
		        get().set_m_type(avalue);
	        }


            inline const int32_t m_channelid()
	        {
		        return getconst().m_channelid();
	        }

	        inline void set_m_channelid(const int32_t& avalue)
	        {
		        get().set_m_channelid(avalue);
	        }


};

    class chatitem
    {
        bool m_ismalloc;
        PB::chatitem* m_data;
	    ngl::data_modified_base* m_modified;

    public:
        PB::chatitem*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<chatitem>(
			"chatitem"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](chatitem& temp) { temp.~chatitem(); })
			, sol::base_classes, sol::bases<>()
            , "m_rolename", &chatitem::m_rolename
            , "set_m_rolename", &chatitem::set_m_rolename
            , "m_content", &chatitem::m_content
            , "set_m_content", &chatitem::set_m_content
            , "m_utc", &chatitem::m_utc
            , "set_m_utc", &chatitem::set_m_utc

			);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<chatitem>("chatitem");

        }

        static const char* name()
        {
            return "chatitem";
        }

        chatitem(PB::chatitem* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        chatitem(bool amalloc) :
		    m_data(amalloc ? new PB::chatitem() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        chatitem() :
		    chatitem(true)
	    {
	    }

        ~chatitem()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::chatitem& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::chatitem& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const std::string m_rolename()
	        {
		        return getconst().m_rolename();
	        }

	        inline void set_m_rolename(const std::string& avalue)
	        {
		        get().set_m_rolename(avalue);
	        }


            inline const std::string m_content()
	        {
		        return getconst().m_content();
	        }

	        inline void set_m_content(const std::string& avalue)
	        {
		        get().set_m_content(avalue);
	        }


            inline const int32_t m_utc()
	        {
		        return getconst().m_utc();
	        }

	        inline void set_m_utc(const int32_t& avalue)
	        {
		        get().set_m_utc(avalue);
	        }


};

    class PROBUFF_LOGIC_CHAT_RESPONSE
    {
        bool m_ismalloc;
        PB::PROBUFF_LOGIC_CHAT_RESPONSE* m_data;
	    ngl::data_modified_base* m_modified;
		std::vector<chatitem> _chatitem;

    public:
        PB::PROBUFF_LOGIC_CHAT_RESPONSE*& pb()
        {
            return m_data;
        }
        inline ngl::data_modified_base* modified()
	    {
		    return m_modified;
	    }
        static void init(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CHAT_RESPONSE>(
			"PROBUFF_LOGIC_CHAT_RESPONSE"
			//, sol::meta_function::garbage_collect
			//, sol::destructor([](PROBUFF_LOGIC_CHAT_RESPONSE& temp) { temp.~PROBUFF_LOGIC_CHAT_RESPONSE(); })
			, sol::base_classes, sol::bases<>()
            , "m_type", &PROBUFF_LOGIC_CHAT_RESPONSE::m_type
            , "set_m_type", &PROBUFF_LOGIC_CHAT_RESPONSE::set_m_type
            , "m_channelid", &PROBUFF_LOGIC_CHAT_RESPONSE::m_channelid
            , "set_m_channelid", &PROBUFF_LOGIC_CHAT_RESPONSE::set_m_channelid
            , "add_m_chat_list", &PROBUFF_LOGIC_CHAT_RESPONSE::add_m_chat_list
            , "m_chat_list", &PROBUFF_LOGIC_CHAT_RESPONSE::m_chat_list
            , "m_chat_list_size", &PROBUFF_LOGIC_CHAT_RESPONSE::m_chat_list_size
            , "clear_m_chat_list", &PROBUFF_LOGIC_CHAT_RESPONSE::clear_m_chat_list


			);
			chatitem::init(alua);

        }

        static void release(sol::state* alua)
        {
            alua->new_usertype<PROBUFF_LOGIC_CHAT_RESPONSE>("PROBUFF_LOGIC_CHAT_RESPONSE");
			chatitem::release(alua);

        }

        static const char* name()
        {
            return "PROBUFF_LOGIC_CHAT_RESPONSE";
        }

        PROBUFF_LOGIC_CHAT_RESPONSE(PB::PROBUFF_LOGIC_CHAT_RESPONSE* adata, ngl::data_modified_base* amodified = nullptr) :
		    m_data(adata)
            , m_modified(amodified)
            , m_ismalloc(false)

	    {
	    }
        PROBUFF_LOGIC_CHAT_RESPONSE(bool amalloc) :
		    m_data(amalloc ? new PB::PROBUFF_LOGIC_CHAT_RESPONSE() : nullptr)
            , m_modified(nullptr)
            , m_ismalloc(amalloc)
	    {
	    }

        PROBUFF_LOGIC_CHAT_RESPONSE() :
		    PROBUFF_LOGIC_CHAT_RESPONSE(true)
	    {
	    }

        ~PROBUFF_LOGIC_CHAT_RESPONSE()
	    {
            if(m_ismalloc)
                delete m_data;
	    }

        inline PB::PROBUFF_LOGIC_CHAT_RESPONSE& get()
	    {
            if(m_modified != nullptr)
                m_modified->modified();
		    return *m_data;
	    }

	    inline const PB::PROBUFF_LOGIC_CHAT_RESPONSE& getconst()const
	    {
		    return *m_data;
	    }
        

            inline const int32_t m_type()
	        {
		        return getconst().m_type();
	        }

	        inline void set_m_type(const int32_t& avalue)
	        {
		        get().set_m_type(avalue);
	        }


            inline const int32_t m_channelid()
	        {
		        return getconst().m_channelid();
	        }

	        inline void set_m_channelid(const int32_t& avalue)
	        {
		        get().set_m_channelid(avalue);
	        }


            inline chatitem& add_m_chat_list()
            {
                _chatitem.push_back(chatitem(get().add_m_chat_list(), modified()));
                return *_chatitem.rbegin();
            }

            inline std::tuple<bool,chatitem> m_chat_list(int32_t aindex)
            {
                if(aindex >= 0 && aindex < _chatitem.size())
                {
                    return std::make_tuple(true, _chatitem[aindex]);
                }
                else
                {
                    static chatitem ltemp;
                    return std::make_tuple(false, ltemp);
                }
            }

            inline int32_t m_chat_list_size()
            {
                return getconst().m_chat_list_size();
            }

            inline void clear_m_chat_list()
            {
                return get().clear_m_chat_list();
            }
    

};
	class register_lua_net
	{
	public:
		static void register_lua();
	};
}//namespace ngl
