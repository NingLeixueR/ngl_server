#include "lua_net.h"
#include "actor_lua.h"
namespace ngl
{
	void register_lua_net::register_lua()
	{
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ERROR>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ERROR_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_GET_TIME>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_GET_TIME_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_GET_NOTICE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_GET_NOTICE_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ACOUNT_LOGIN>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ACOUNT_LOGIN_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ROLE_LOGIN>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ROLE_SYNC>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_ROLE_SYNC_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_BAG_SYNC>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_BAG_SYNC_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_BAG_UPDATE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_BAG_UPDATE_RESPONSE>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_CMD>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_CHAT>();
		actor_lua::register_map<ngl::PROBUFF_LOGIC_CHAT_RESPONSE>();
	}
}
